# Multiplayer backend (not included yet)

The Android app contains the room model and rules (`multiplayer/Rooms.kt`) but **no network client and no server**.
Firebase Realtime Database alone is not an authoritative low-latency race server, so the recommended design is:

1. **Auth + room metadata:** Firebase Authentication (anonymous) + Firestore/Realtime DB for room list, codes, ready flags.
2. **Race sync:** a small authoritative WebSocket server (Kotlin/Ktor, Go, or Node) that receives player state (position, speed, sequence number) at ~15–20 Hz, drops late packets (`RoomRules.acceptPacket`), and broadcasts snapshots.
3. **Rules to enforce server-side:** capacity 2–4, only the host may start, all others ready, host migration, heartbeat timeout 15 s, room closes when empty.

Deployment (once a server exists): deploy it on your own host, set `NEXUS_BACKEND_URL` at build time. Never put service-account files, private keys or admin credentials in the app or in this repository; use environment variables on the server.
