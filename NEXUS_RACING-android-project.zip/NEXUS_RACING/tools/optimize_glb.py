#!/usr/bin/env python3
"""
Builds app/src/main/assets/models/h2r.glb from the supplied source GLB.

What it does (geometry and materials are NOT altered, only repacked):
  * drops the TANGENT attribute (the shader derives the tangent frame from screen-space derivatives)
  * re-indexes with 16-bit indices (every primitive has <= 65535 vertices)
  * recompresses textures (base colour 1024 px, others 512 px)
  * replaces the root node matrix so that, after all node transforms, the bike is
      - in metres (wheelbase ~1.45 m),
      - facing -Z (the direction the game's bikes face),
      - centred between the wheels, with the tyres touching y = 0.
Usage: python3 tools/optimize_glb.py kawasaki_zx10r.glb app/src/main/assets/models/h2r.glb
Requires: numpy, pillow.
"""
import io, json, struct, sys
import numpy as np
from PIL import Image

SRC, DST = sys.argv[1], sys.argv[2]

# --- values measured from the source model (raw units) ------------------------------------
FRONT_AXLE_Y, REAR_AXLE_Y = -0.7747, 0.7479   # tyre-bottom centroids along the long axis
GROUND_Z = -0.525                              # tyre contact height
TARGET_WHEELBASE_M = 1.45                      # real ZX-10R / H2R wheelbase
S = TARGET_WHEELBASE_M / (REAR_AXLE_Y - FRONT_AXLE_Y)
YC = (FRONT_AXLE_Y + REAR_AXLE_Y) / 2.0

raw = open(SRC, 'rb').read()
jl, _ = struct.unpack('<I4s', raw[12:20])
j = json.loads(raw[20:20 + jl])
bin_ = raw[20 + jl + 8:]
CT = {5121: np.uint8, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}

def acc(i):
    a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
    n = NC[a['type']]; dt = CT[a['componentType']]
    off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    return np.frombuffer(bin_, dtype=dt, count=a['count'] * n, offset=off).reshape(a['count'], n)

out = bytearray()
views, accessors = [], []
def add_view(data, target=None):
    while len(out) % 4: out.append(0)
    v = {'buffer': 0, 'byteOffset': len(out), 'byteLength': len(data)}
    if target: v['target'] = target
    out.extend(data); views.append(v); return len(views) - 1

meshes = []
tri_total = 0
for m in j['meshes']:
    p = m['primitives'][0]; at = p['attributes']
    pos = acc(at['POSITION']).astype('<f4'); nrm = acc(at['NORMAL']).astype('<f4')
    uv = acc(at['TEXCOORD_0']).astype('<f4'); idx = acc(p['indices']).reshape(-1)
    assert idx.max() < 65536, 'primitive too large for 16-bit indices'
    ids = []
    for arr, typ, tgt, mm in ((pos, 'VEC3', 34962, True), (nrm, 'VEC3', 34962, False), (uv, 'VEC2', 34962, False)):
        bv = add_view(arr.tobytes(), tgt)
        a = {'bufferView': bv, 'componentType': 5126, 'count': int(len(arr)), 'type': typ}
        if mm: a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
        accessors.append(a); ids.append(len(accessors) - 1)
    ib = idx.astype('<u2').tobytes()
    bv = add_view(ib, 34963)
    accessors.append({'bufferView': bv, 'componentType': 5123, 'count': int(len(idx)), 'type': 'SCALAR'})
    meshes.append({'name': m.get('name', 'mesh'), 'primitives': [{
        'attributes': {'POSITION': ids[0], 'NORMAL': ids[1], 'TEXCOORD_0': ids[2]},
        'indices': len(accessors) - 1, 'material': p['material'], 'mode': 4}]})
    tri_total += len(idx) // 3

# --- textures: role by material usage ------------------------------------------------------
roles = {}
for mat in j['materials']:
    pbr = mat.get('pbrMetallicRoughness', {})
    for key, role in (('baseColorTexture', 'base'), ('metallicRoughnessTexture', 'orm')):
        if key in pbr: roles[j['textures'][pbr[key]['index']]['source']] = role
    for key, role in (('normalTexture', 'normal'), ('emissiveTexture', 'emissive')):
        if key in mat: roles[j['textures'][mat[key]['index']]['source']] = role

images = []
for i, im in enumerate(j['images']):
    bv = j['bufferViews'][im['bufferView']]
    img = Image.open(io.BytesIO(bin_[bv.get('byteOffset', 0):bv.get('byteOffset', 0) + bv['byteLength']]))
    img.load()
    role = roles.get(i, 'orm')
    size = 1024 if role == 'base' else 512
    if img.size[0] > size: img = img.resize((size, size), Image.LANCZOS)
    buf = io.BytesIO()
    if img.mode in ('RGBA', 'LA') or role == 'emissive':
        img.convert('RGBA' if 'A' in img.mode else 'RGB').save(buf, 'PNG', optimize=True); mime = 'image/png'
    else:
        img.convert('RGB').save(buf, 'JPEG', quality=92 if role == 'normal' else 88, optimize=True); mime = 'image/jpeg'
    images.append({'bufferView': add_view(buf.getvalue()), 'mimeType': mime, 'name': 'tex%d_%s' % (i, role)})

# --- root node: game-space transform -------------------------------------------------------
# Inner nodes map raw (x,y,z) -> 100*(x,y,z). We want game = S*(-x, z - GROUND_Z, y - YC).
k = S / 100.0
nodes = json.loads(json.dumps(j['nodes']))
nodes[0]['matrix'] = [-k, 0, 0, 0,   0, 0, k, 0,   0, k, 0, 0,   0, -S * GROUND_Z, -S * YC, 1]

asset = dict(j['asset'])
asset['generator'] = 'NEXUS RACING tools/optimize_glb.py (repacked from ' + str(asset.get('generator', '?')) + ')'
new = {
    'asset': asset, 'extensionsUsed': j.get('extensionsUsed', []),
    'scene': 0, 'scenes': j['scenes'], 'nodes': nodes, 'meshes': meshes,
    'materials': j['materials'], 'textures': j['textures'], 'samplers': j['samplers'],
    'images': images, 'accessors': accessors, 'bufferViews': views,
    'buffers': [{'byteLength': len(out)}],
}
js = json.dumps(new, separators=(',', ':')).encode()
while len(js) % 4: js += b' '
while len(out) % 4: out.append(0)
total = 12 + 8 + len(js) + 8 + len(out)
with open(DST, 'wb') as f:
    f.write(struct.pack('<4sII', b'glTF', 2, total))
    f.write(struct.pack('<I4s', len(js), b'JSON')); f.write(js)
    f.write(struct.pack('<I4s', len(out), b'BIN\x00')); f.write(out)
print('triangles', tri_total, 'scale', round(S, 4), 'size MB', round(total / 1e6, 2))
