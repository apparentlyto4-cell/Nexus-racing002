# H2R model notes

* Source file: `kawasaki_zx10r.glb` (Sketchfab "Kawasaki zx10r" by FREEZLER, CC-BY 4.0). The geometry is a ZX-10R; it is used as the in-game "Kawasaki Ninja H2R" as requested. Rename or swap it in `assets/config/bikes.json` (`name`, `model.glb`).
* `tools/optimize_glb.py` repacks it into `app/src/main/assets/models/h2r.glb` (23.3 MB -> 11.4 MB): tangents dropped, 16-bit indices, textures resized (base colour 1024 px, others 512 px), root transform baked so the bike is in metres, faces -Z, is centred between the wheels and touches y = 0. Triangles are unchanged (339,936).
* The file has no separate wheel nodes and no animations, so wheels do not spin (nothing was invented).
* Materials: BLEND materials with more than 30,000 indices are drawn opaque (unsorted blending looked wrong); the small glass part is truly blended. Paint customisation does not apply to GLB bikes.
