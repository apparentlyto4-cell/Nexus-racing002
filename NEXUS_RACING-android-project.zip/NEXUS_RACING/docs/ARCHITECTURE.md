# Architecture
- `RaceSim` is pure Kotlin (no Android): fixed 1/60 s steps, deterministic if `RaceConfig.seed != 0`.
- `RaceRenderer` (GL thread) steps the sim and draws via `SceneDrawer` + `Models` using `GlKit` (one shader, three meshes).
- `GameView` draws the HUD and owns multi-touch; `GameActivity` wires lifecycle, sensor, audio, pause/results.
- Rewards are granted only in `Progression.grantRace` (once per race); career repeats pay 20%.
- Save: JSON in SharedPreferences (main + backup slot), schema `version`.
