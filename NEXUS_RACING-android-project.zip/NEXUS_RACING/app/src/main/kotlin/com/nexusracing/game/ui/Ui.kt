package com.nexusracing.game.ui

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.nexusracing.game.audio.Sound
import com.nexusracing.game.persistence.Save
import android.content.res.Configuration
import java.util.Locale

/** Small view-building toolkit: dark racing theme, no XML layouts needed. */
object Ui {
    val BG = 0xFF0B0E14.toInt()
    val PANEL = 0xFF151B26.toInt()
    val PANEL2 = 0xFF1D2535.toInt()
    val ACCENT = 0xFFFF3D2E.toInt()
    val CYAN = 0xFF19D3FF.toInt()
    val TEXT = 0xFFEAF0FA.toInt()
    val DIM = 0xFF8A97AD.toInt()
    val GOLD = 0xFFFFC542.toInt()
    val GREEN = 0xFF3DDC84.toInt()
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    fun round(c: Context, color: Int, r: Float = 12f, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, r).toFloat()
        if (stroke != 0) g.setStroke(dp(c, 1.5f), stroke)
        return g
    }

    fun text(c: Context, s: CharSequence, sp: Float, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.setTextColor(color)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.typeface = Typeface.create("sans-serif-condensed", if (bold) Typeface.BOLD else Typeface.NORMAL)
        t.letterSpacing = 0.03f
        return t
    }

    fun lp(w: Int, h: Int, weight: Float = 0f, m: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(m, m, m, m)
        return p
    }

    fun vbox(c: Context): LinearLayout { val l = LinearLayout(c); l.orientation = LinearLayout.VERTICAL; return l }
    fun hbox(c: Context): LinearLayout { val l = LinearLayout(c); l.orientation = LinearLayout.HORIZONTAL; return l }

    fun card(c: Context): LinearLayout {
        val l = vbox(c)
        l.background = round(c, PANEL, 14f)
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        return l
    }

    fun button(c: Context, s: String, primary: Boolean = false, enabled: Boolean = true, onClick: () -> Unit): TextView {
        val t = text(c, s.uppercase(), if (primary) 20f else 15f, TEXT, true)
        t.gravity = Gravity.CENTER
        val pv = dp(c, if (primary) 16 else 11)
        t.setPadding(dp(c, 14), pv, dp(c, 14), pv)
        val col = if (!enabled) 0xFF222A38.toInt() else if (primary) ACCENT else PANEL2
        t.background = round(c, col, 12f, if (primary || !enabled) 0 else 0xFF2C3850.toInt())
        t.alpha = if (enabled) 1f else 0.6f
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        t.setOnClickListener { Sound.click(); onClick() }
        return t
    }

    fun header(c: Context, title: String, onBack: (() -> Unit)?): View {
        val row = hbox(c)
        row.gravity = Gravity.CENTER_VERTICAL
        if (onBack != null) {
            row.addView(button(c, "<", false, true, onBack), lp(WRAP, WRAP, 0f, dp(c, 4)))
        }
        row.addView(text(c, title.uppercase(), 24f, TEXT, true), lp(0, WRAP, 1f, dp(c, 8)))
        row.addView(text(c, "COINS ${Save.d.coins}", 16f, GOLD, true))
        return row
    }

    fun scroll(c: Context, content: View): ScrollView {
        val sv = ScrollView(c)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(content)
        return sv
    }

    fun chips(c: Context, labels: Array<String>, sel: Int, onSelect: (Int) -> Unit): View {
        val sv = HorizontalScrollView(c)
        sv.isHorizontalScrollBarEnabled = false
        val row = hbox(c)
        val views = ArrayList<TextView>()
        fun paint(i: Int) {
            for ((j, v) in views.withIndex()) {
                v.background = round(c, if (j == i) ACCENT else PANEL2, 10f)
                v.setTextColor(if (j == i) Color.WHITE else DIM)
            }
        }
        for ((i, l) in labels.withIndex()) {
            val t = text(c, l, 14f, DIM, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(c, 12), dp(c, 9), dp(c, 12), dp(c, 9))
            t.setOnClickListener { Sound.click(); paint(i); onSelect(i) }
            views.add(t)
            row.addView(t, lp(WRAP, WRAP, 0f, dp(c, 3)))
        }
        paint(sel)
        sv.addView(row)
        return sv
    }

    fun swatches(c: Context, colors: IntArray, sel: Int, onSelect: (Int) -> Unit): View {
        val sv = HorizontalScrollView(c)
        sv.isHorizontalScrollBarEnabled = false
        val row = hbox(c)
        val views = ArrayList<View>()
        fun paint(i: Int) {
            for ((j, v) in views.withIndex()) v.background = round(c, colors[j], 8f, if (j == i) Color.WHITE else 0xFF2C3850.toInt())
        }
        for ((i, col) in colors.withIndex()) {
            val v = View(c)
            v.setOnClickListener { Sound.click(); paint(i); onSelect(i) }
            views.add(v)
            row.addView(v, lp(dp(c, 34), dp(c, 34), 0f, dp(c, 4)))
        }
        paint(sel)
        sv.addView(row)
        return sv
    }

    fun bar(c: Context, frac: Float, color: Int = CYAN): View {
        val l = hbox(c)
        l.background = round(c, 0xFF222A38.toInt(), 4f)
        val f = frac.coerceIn(0f, 1f)
        val a = View(c)
        a.background = round(c, color, 4f)
        l.addView(a, LinearLayout.LayoutParams(0, MATCH, f))
        l.addView(View(c), LinearLayout.LayoutParams(0, MATCH, 1f - f))
        return l
    }

    fun slider(c: Context, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(c)
        sb.max = max - min
        sb.progress = value - min
        sb.progressTintList = ColorStateList.valueOf(ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onChange(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { Save.commit() }
        })
        return sb
    }

    fun toast(c: Context, s: String) { Toast.makeText(c, s, Toast.LENGTH_SHORT).show() }

    fun framed(c: Context, v: View): FrameLayout {
        val f = FrameLayout(c)
        f.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        return f
    }
}

/** Fullscreen immersive mode + draw into display cut-outs. */
object Immersive {
    @Suppress("DEPRECATION")
    fun apply(a: Activity, keepOn: Boolean = false) {
        a.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = a.window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            a.window.attributes = lp
        }
        if (keepOn) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

/** Language architecture: strings live in res/values-XX; the chosen language is applied here. */
object Locales {
    val codes = arrayOf("en", "bn")
    val names = arrayOf("English", "বাংলা")

    fun wrap(base: Context): Context {
        val lang = try { Save.d.lang } catch (e: Exception) { "en" }
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale(lang))
        return base.createConfigurationContext(cfg)
    }
}
