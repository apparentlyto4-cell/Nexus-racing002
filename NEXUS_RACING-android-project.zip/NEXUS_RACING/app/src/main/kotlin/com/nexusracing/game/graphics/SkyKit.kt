package com.nexusracing.game.graphics

import android.opengl.GLES20
import android.opengl.GLES30
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Full-screen procedural sky: zenith-to-horizon gradient, sun glow (or moon + stars at night) and
 * soft drifting clouds. One triangle, no textures. Clouds cost two noise octaves per sky pixel and are
 * switched off on the LOW preset. Create on the GL thread.
 */
class SkyKit {
    private var prog = 0
    private val loc = IntArray(12)

    companion object {
        private const val VS = """#version 300 es
out vec2 vNdc;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = p * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"""
        private const val FS = """#version 300 es
precision highp float;
uniform vec3 uTop;
uniform vec3 uHorizon;
uniform vec3 uSunDir;
uniform vec3 uSunCol;
uniform vec3 uF;
uniform vec3 uR;
uniform vec3 uU;
uniform vec2 uTan;
uniform vec3 uCloudCol;
uniform vec3 uParams;   // x time, y cloud coverage (0 = none), z night (0/1)
in vec2 vNdc;
out vec4 outColor;
float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
void main() {
    vec3 rd = normalize(uF + uR * (vNdc.x * uTan.x) + uU * (vNdc.y * uTan.y));
    float h = rd.y;
    float k = pow(clamp(1.0 - max(h, 0.0), 0.0, 1.0), 3.5);
    vec3 col = mix(uTop, uHorizon, k);
    float sd = max(dot(rd, uSunDir), 0.0);
    col += uSunCol * (pow(sd, 900.0) * 1.6 + pow(sd, 14.0) * 0.28);
    if (uParams.z > 0.5 && h > 0.0) {
        vec2 sp = floor(rd.xz / (h + 0.25) * 70.0);
        float st = step(0.9975, hash(sp)) * smoothstep(0.05, 0.3, h);
        col += vec3(st);
    }
    if (uParams.y > 0.0 && h > 0.015) {
        vec2 p = rd.xz / (h + 0.18) * 1.7 + vec2(uParams.x * 0.015, 0.0);
        float n = noise(p) * 0.65 + noise(p * 2.37 + 7.3) * 0.35;
        float c = smoothstep(1.0 - uParams.y, 1.0 - uParams.y + 0.26, n) * smoothstep(0.015, 0.2, h);
        vec3 cc = mix(uCloudCol, uCloudCol * 0.72, smoothstep(0.55, 1.0, n));
        col = mix(col, cc, c * 0.92);
    }
    outColor = vec4(col, 1.0);
}
"""
    }

    fun init() {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs)
        if (ok[0] == 0) throw RuntimeException("Sky link error: " + GLES20.glGetProgramInfoLog(prog))
        val names = arrayOf("uTop", "uHorizon", "uSunDir", "uSunCol", "uF", "uR", "uU", "uTan", "uCloudCol", "uParams")
        for (i in names.indices) loc[i] = GLES20.glGetUniformLocation(prog, names[i])
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { val l = GLES20.glGetShaderInfoLog(s); GLES20.glDeleteShader(s); throw RuntimeException("Sky shader: $l") }
        return s
    }

    private fun c3(c: Int, i: Int, a: Float, b: Float, d: Float) {
        GLES20.glUniform3f(loc[i], a, b, d)
    }

    /**
     * Draws the sky behind everything. Depth test/writes are disabled for this pass.
     * top / horizon / sun / cloud are 0xAARRGGBB colours; clouds = coverage 0..1 (0 = off).
     */
    fun draw(
        eye: FloatArray, look: FloatArray, upX: Float, upY: Float, fovDeg: Float, aspect: Float,
        time: Float, top: Int, horizon: Int, sunCol: Int, cloudCol: Int, clouds: Float, night: Boolean
    ) {
        var fx = look[0] - eye[0]; var fy = look[1] - eye[1]; var fz = look[2] - eye[2]
        var l = sqrt(fx * fx + fy * fy + fz * fz); if (l < 1e-6f) l = 1f
        fx /= l; fy /= l; fz /= l
        // right = f x up
        var rx = fy * 0f - fz * upY; var ry = fz * upX - fx * 0f; var rz = fx * upY - fy * upX
        l = sqrt(rx * rx + ry * ry + rz * rz); if (l < 1e-6f) l = 1f
        rx /= l; ry /= l; rz /= l
        // true up = r x f
        val ux = ry * fz - rz * fy; val uy = rz * fx - rx * fz; val uz = rx * fy - ry * fx
        val th = tan(Math.toRadians((fovDeg / 2f).toDouble())).toFloat()

        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(prog)
        fun rgb(c: Int, i: Int) = c3(c, i, ((c shr 16) and 255) / 255f, ((c shr 8) and 255) / 255f, (c and 255) / 255f)
        rgb(top, 0); rgb(horizon, 1)
        // sun (or moon) sits ahead and to the right, low above the horizon
        val sx = 0.38f; val sy = if (night) 0.34f else 0.30f; val sz = -0.87f
        val sl = sqrt(sx * sx + sy * sy + sz * sz)
        GLES20.glUniform3f(loc[2], sx / sl, sy / sl, sz / sl)
        rgb(sunCol, 3)
        GLES20.glUniform3f(loc[4], fx, fy, fz)
        GLES20.glUniform3f(loc[5], rx, ry, rz)
        GLES20.glUniform3f(loc[6], ux, uy, uz)
        GLES20.glUniform2f(loc[7], th * aspect, th)
        rgb(cloudCol, 8)
        GLES20.glUniform3f(loc[9], time, clouds, if (night) 1f else 0f)
        GLES30.glBindVertexArray(0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    fun release() {
        try { if (prog != 0) GLES20.glDeleteProgram(prog) } catch (e: Throwable) { }
        prog = 0
    }
}
