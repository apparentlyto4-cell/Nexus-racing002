package com.nexusracing.game

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import com.nexusracing.game.audio.Music
import com.nexusracing.game.ui.Immersive
import com.nexusracing.game.ui.Locales
import com.nexusracing.game.ui.MainMenuScreen
import com.nexusracing.game.ui.Navigator
import com.nexusracing.game.ui.Ui

/** Hosts all menu screens through the Navigator. The race itself lives in GameActivity. */
class MainActivity : Activity() {
    private lateinit var nav: Navigator
    private var firstResume = true

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(Locales.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Immersive.apply(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        nav = Navigator(this, root)
        nav.push(MainMenuScreen())
    }

    override fun onResume() {
        super.onResume()
        Immersive.apply(this)
        nav.onResume()
        Music.start(this)
        if (firstResume) firstResume = false else nav.refresh()   // pick up coins/XP after a race
    }

    override fun onPause() {
        nav.onPause()
        Music.stop()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Immersive.apply(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!nav.pop()) super.onBackPressed()
    }
}
