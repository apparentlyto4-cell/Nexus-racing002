package com.nexusracing.game.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.opengl.GLSurfaceView
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.nexusracing.game.GameActivity
import com.nexusracing.game.data.RaceConfig

abstract class Screen {
    lateinit var nav: Navigator
    abstract fun create(c: Context): View
}

/** Minimal screen stack with fade/slide transitions. Each screen builds its view from current save data. */
class Navigator(val activity: Activity, private val container: FrameLayout) {
    private val stack = ArrayList<Screen>()

    fun push(s: Screen) { s.nav = this; stack.add(s); show(s, true) }

    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.size - 1)
        show(stack.last(), false)
        return true
    }

    /** Rebuild the current screen (used after buying something, changing a setting, returning from a race). */
    fun refresh() { if (stack.isNotEmpty()) show(stack.last(), null) }

    fun startRace(cfg: RaceConfig) {
        activity.startActivity(Intent(activity, GameActivity::class.java).putExtra(GameActivity.EXTRA_CFG, cfg.toJson()))
    }

    private fun show(s: Screen, forward: Boolean?) {
        val old = if (container.childCount > 0) container.getChildAt(0) else null
        val wrap = FrameLayout(activity)
        wrap.setBackgroundColor(Ui.BG)
        val base = Ui.dp(activity, 14)
        wrap.setPadding(base, base, base, base)
        wrap.setOnApplyWindowInsetsListener { v, ins ->
            var l = 0; var t = 0; var r = 0; var b = 0
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = ins.displayCutout
                if (cut != null) { l = cut.safeInsetLeft; t = cut.safeInsetTop; r = cut.safeInsetRight; b = cut.safeInsetBottom }
            }
            v.setPadding(base + l, base + t, base + r, base + b)
            ins
        }
        wrap.addView(s.create(activity), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        container.addView(wrap, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        wrap.requestApplyInsets()
        if (forward != null) {
            wrap.alpha = 0f
            wrap.translationX = if (forward) 80f else -80f
            wrap.animate().alpha(1f).translationX(0f).setDuration(220).start()
        }
        if (old != null) container.removeView(old)
    }

    // GL views (garage preview) must be paused/resumed with the activity to avoid leaking the GL thread.
    private fun gl(v: View?, out: ArrayList<GLSurfaceView>) {
        if (v is GLSurfaceView) out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) gl(v.getChildAt(i), out)
    }

    fun onPause() { val l = ArrayList<GLSurfaceView>(); gl(container, l); for (g in l) g.onPause() }
    fun onResume() { val l = ArrayList<GLSurfaceView>(); gl(container, l); for (g in l) g.onResume() }
}
