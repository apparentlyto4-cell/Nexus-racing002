package com.nexusracing.game.multiplayer

import com.nexusracing.game.BuildConfig
import java.util.Random

/*
 * MULTIPLAYER STATUS (honest summary):
 *  - Implemented: the room data model and the pure room rules below (validation, host migration,
 *    ready/start conditions, room codes). They are backend-independent and unit-testable.
 *  - NOT implemented: the network client and the authoritative race server. Without a configured
 *    backend the Multiplayer screen explains this. No fake/simulated online players are ever created.
 *  - See backend/README.md for the proposed protocol and deployment steps.
 */

enum class RoomState { LOBBY, COUNTDOWN, RACING, RESULTS, CLOSED }

class RoomPlayer(val id: String, val name: String, var ready: Boolean = false, var connected: Boolean = true, var lastSeenMs: Long = 0L)

class RoomSettings(val env: Int = 0, val night: Boolean = false, val weather: Int = 0, val laps: Int = 1, val traffic: Float = 1f)

class Room(
    val code: String,
    var hostId: String,
    val isPublic: Boolean,
    val capacity: Int = 4,
    val settings: RoomSettings = RoomSettings()
) {
    var state = RoomState.LOBBY
    val players = ArrayList<RoomPlayer>()
}

sealed class RoomResult {
    object Ok : RoomResult()
    class Error(val message: String) : RoomResult()
}

/** Pure room rules. The server must enforce the same rules; the client uses them for early feedback. */
object RoomRules {
    const val MIN_PLAYERS_TO_START = 2
    const val TIMEOUT_MS = 15_000L
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   // no 0/O/1/I confusion

    fun newCode(rnd: Random = Random()): String {
        val sb = StringBuilder()
        for (i in 0 until 5) sb.append(ALPHABET[rnd.nextInt(ALPHABET.length)])
        return sb.toString()
    }

    fun isValidCode(code: String): Boolean = code.length == 5 && code.all { ALPHABET.indexOf(it) >= 0 }

    fun join(room: Room?, player: RoomPlayer): RoomResult {
        if (room == null || room.state == RoomState.CLOSED) return RoomResult.Error("Room not found")
        if (room.state != RoomState.LOBBY) return RoomResult.Error("Race already in progress")
        if (room.players.any { it.id == player.id }) return RoomResult.Error("You are already in this room")
        if (room.players.size >= room.capacity) return RoomResult.Error("Room is full")
        room.players.add(player)
        return RoomResult.Ok
    }

    /** Removes a player; migrates the host; closes the room when empty. */
    fun leave(room: Room, playerId: String) {
        room.players.removeAll { it.id == playerId }
        if (room.players.isEmpty()) { room.state = RoomState.CLOSED; return }
        if (room.hostId == playerId) room.hostId = room.players[0].id
        if (room.state != RoomState.LOBBY && room.players.size < MIN_PLAYERS_TO_START) room.state = RoomState.LOBBY // cancel race
    }

    fun canStart(room: Room, requesterId: String): RoomResult {
        if (room.hostId != requesterId) return RoomResult.Error("Only the host can start the race")
        if (room.state != RoomState.LOBBY) return RoomResult.Error("Room is not in the lobby")
        if (room.players.size < MIN_PLAYERS_TO_START) return RoomResult.Error("At least $MIN_PLAYERS_TO_START players are required")
        if (room.players.any { it.id != room.hostId && !it.ready }) return RoomResult.Error("Not all players are ready")
        return RoomResult.Ok
    }

    /** Mark players that have not sent a heartbeat for TIMEOUT_MS as disconnected. */
    fun applyTimeouts(room: Room, nowMs: Long) {
        for (p in room.players) p.connected = nowMs - p.lastSeenMs <= TIMEOUT_MS
    }

    /** Late or out-of-order packets are dropped by comparing sequence numbers. */
    fun acceptPacket(lastSeq: Long, seq: Long): Boolean = seq > lastSeq
}

interface MultiplayerBackend {
    val configured: Boolean
    val description: String
}

object Backend {
    val current: MultiplayerBackend = object : MultiplayerBackend {
        override val configured: Boolean get() = BuildConfig.BACKEND_URL.isNotBlank()
        override val description: String
            get() = if (configured) "Backend URL: ${BuildConfig.BACKEND_URL}" else "No backend configured"
    }
}
