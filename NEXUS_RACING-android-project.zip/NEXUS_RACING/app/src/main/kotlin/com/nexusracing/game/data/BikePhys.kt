package com.nexusracing.game.data

import org.json.JSONObject

/**
 * Per-bike physics / handling / feel profile. One instance per bike, loaded from the optional
 * "phys" object in assets/config/bikes.json. Every field has a default that reproduces the original
 * (pre-profile) behaviour, so legacy bikes without a "phys" object keep handling exactly as before.
 *
 * Units: speeds m/s, accelerations m/s^2, angles degrees, rates 1/s.
 */
class BikePhys(
    // ---- throttle / brake ----
    val throttleResp: Float = 14f,     // how fast the throttle input ramps to the target (1/s)
    val brakeResp: Float = 16f,        // how fast brake pressure builds (1/s); low = progressive
    val brakeCurve: Float = 1f,        // brake force = braking * pressure^curve (>1 = more progressive)
    // ---- steering ----
    val steerSens: Float = 1f,         // multiplies the lateral speed the bike can reach
    val steerResp: Float = 10f,        // steering input smoothing (1/s)
    val hiSpeedSteerCut: Float = 0.35f,// steering authority removed at top speed (0..1)
    // ---- lean ----
    val maxLeanDeg: Float = 35f,
    val leanGain: Float = 4f,          // degrees of lean per m/s of lateral speed
    val leanResp: Float = 18f,         // lean smoothing (1/s)
    val hiSpeedLeanCut: Float = 0f,    // lean removed at top speed (0..1)
    // ---- traction / stability ----
    val gripLimit: Float = 99f,        // traction-limited drive acceleration (99 = effectively unlimited)
    val tractionControl: Float = 0f,   // 0..1, how much wheelspin loss traction control prevents
    val launchControl: Boolean = false,
    val stability: Float = 0f,         // extra lateral damping at speed
    val suspension: Float = 8f,        // pitch spring rate (1/s)
    val pitchGain: Float = 0f,         // degrees of pitch per m/s^2 of acceleration (0 = no pitch)
    // ---- engine ----
    val engineBrake: Float = 1.5f,     // m/s^2 deceleration with the throttle closed
    val dragK: Float = 0.0008f,        // aerodynamic drag coefficient while coasting
    val nitroTopMul: Float = 1.25f,    // top-speed multiplier while boosting
    val nitroAccelMul: Float = 1.8f,   // acceleration multiplier while boosting
    val speedCapKmh: Float = 0f,       // hard cap that upgrades cannot exceed (0 = none)
    // ---- gearbox (simulated: drives RPM, audio and a short power cut on upshift) ----
    val gearCount: Int = 5,
    val shiftCut: Float = 1f,          // drive multiplier during a shift (1 = none)
    val shiftTime: Float = 0.08f,
    val idleRpm: Float = 0.15f,
    // ---- camera / audio tuning ----
    val fovGain: Float = 14f,          // extra field of view at top speed (degrees)
    val camPullback: Float = 0f,       // chase camera moves back by this many metres at top speed
    val camShake: Float = 1f,
    val camRoll: Float = 0f,           // camera roll as a fraction of bike lean
    val engineHzIdle: Float = 35f,
    val engineHzSpan: Float = 170f,
    val whine: Float = 0f              // supercharger whine level (0 = none)
) {
    companion object {
        val DEFAULT = BikePhys()

        fun fromJson(o: JSONObject?): BikePhys {
            if (o == null) return DEFAULT
            val d = DEFAULT
            fun f(k: String, def: Float): Float = o.optDouble(k, def.toDouble()).toFloat()
            return BikePhys(
                throttleResp = f("throttleResp", d.throttleResp).coerceIn(0.5f, 60f),
                brakeResp = f("brakeResp", d.brakeResp).coerceIn(0.5f, 60f),
                brakeCurve = f("brakeCurve", d.brakeCurve).coerceIn(0.5f, 3f),
                steerSens = f("steerSens", d.steerSens).coerceIn(0.3f, 2f),
                steerResp = f("steerResp", d.steerResp).coerceIn(1f, 40f),
                hiSpeedSteerCut = f("hiSpeedSteerCut", d.hiSpeedSteerCut).coerceIn(0f, 0.9f),
                maxLeanDeg = f("maxLeanDeg", d.maxLeanDeg).coerceIn(10f, 65f),
                leanGain = f("leanGain", d.leanGain).coerceIn(0f, 12f),
                leanResp = f("leanResp", d.leanResp).coerceIn(1f, 40f),
                hiSpeedLeanCut = f("hiSpeedLeanCut", d.hiSpeedLeanCut).coerceIn(0f, 0.9f),
                gripLimit = f("gripLimit", d.gripLimit).coerceIn(4f, 99f),
                tractionControl = f("tractionControl", d.tractionControl).coerceIn(0f, 1f),
                launchControl = o.optBoolean("launchControl", d.launchControl),
                stability = f("stability", d.stability).coerceIn(0f, 2f),
                suspension = f("suspension", d.suspension).coerceIn(1f, 30f),
                pitchGain = f("pitchGain", d.pitchGain).coerceIn(0f, 0.5f),
                engineBrake = f("engineBrake", d.engineBrake).coerceIn(0f, 10f),
                dragK = f("dragK", d.dragK).coerceIn(0f, 0.01f),
                nitroTopMul = f("nitroTopMul", d.nitroTopMul).coerceIn(1f, 1.5f),
                nitroAccelMul = f("nitroAccelMul", d.nitroAccelMul).coerceIn(1f, 3f),
                speedCapKmh = f("speedCapKmh", d.speedCapKmh).coerceAtLeast(0f),
                gearCount = o.optInt("gearCount", d.gearCount).coerceIn(1, 8),
                shiftCut = f("shiftCut", d.shiftCut).coerceIn(0.2f, 1f),
                shiftTime = f("shiftTime", d.shiftTime).coerceIn(0.02f, 0.4f),
                idleRpm = f("idleRpm", d.idleRpm).coerceIn(0.05f, 0.4f),
                fovGain = f("fovGain", d.fovGain).coerceIn(0f, 30f),
                camPullback = f("camPullback", d.camPullback).coerceIn(0f, 4f),
                camShake = f("camShake", d.camShake).coerceIn(0f, 2f),
                camRoll = f("camRoll", d.camRoll).coerceIn(0f, 0.5f),
                engineHzIdle = f("engineHzIdle", d.engineHzIdle).coerceIn(20f, 80f),
                engineHzSpan = f("engineHzSpan", d.engineHzSpan).coerceIn(60f, 400f),
                whine = f("whine", d.whine).coerceIn(0f, 1f)
            )
        }
    }
}
