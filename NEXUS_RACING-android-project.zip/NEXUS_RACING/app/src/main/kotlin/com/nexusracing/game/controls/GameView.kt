package com.nexusracing.game.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.view.WindowInsets
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import com.nexusracing.game.audio.Sound
import com.nexusracing.game.data.GfxPreset
import com.nexusracing.game.data.Gfx
import com.nexusracing.game.data.Mode
import com.nexusracing.game.gameplay.InputState
import com.nexusracing.game.gameplay.RaceSim
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Transparent overlay on top of the GL view: draws the HUD and owns ALL touch controls.
 * Every finger is bound to exactly one control when it touches down (hit-tested against
 * non-overlapping circles), so a finger sliding over another button never triggers it.
 */
class GameView(ctx: Context, private val input: InputState) : View(ctx) {
    var sim: RaceSim? = null
    var scheme = 0                       // 0 buttons, 1 wheel, 2 joystick, 3 tilt
    var gfx: GfxPreset = Gfx.presets[1]
    var debug = false
    var fpsProvider: () -> Float = { 0f }
    var camName: () -> String = { "" }
    var onPause: () -> Unit = {}
    var onCamera: () -> Unit = {}
    var onHaptic: () -> Unit = {}
    /** (rpm 0..1.2, throttle 0..1, wind 0..1) -> engine / wind audio */
    var onEngine: (Float, Float, Float) -> Unit = { _, _, _ -> }
    var sensitivity = 1f

    private companion object {
        const val ACC = 1; const val BRK = 2; const val NIT = 3; const val LEFT = 4
        const val RIGHT = 5; const val WHEEL = 6; const val PAUSE = 7; const val CAM = 8
    }

    private val owners = IntArray(32)
    private var wheelVal = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var u = 1f
    private var w = 0f
    private var h = 0f

    // control geometry (cx, cy, r) in pixels
    private val geo = Array(9) { FloatArray(3) }

    private var lastCd = -1
    private var lastCoins = 0
    private var lastCrash = 0
    private var lastEnded = false
    private var insL = 0f; private var insT = 0f; private var insR = 0f; private var insB = 0f   // display-cutout safe area
    private val path = Path()
    private var lastSpd = -1; private var spdStr = "0"
    private var lastSec = -1; private var timeStr = "0:00"
    private var lastGear = -1; private var gearStr = "G1"

    init {
        tp.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        tp.textAlign = Paint.Align.CENTER
    }

    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        w = nw.toFloat(); h = nh.toFloat(); u = h / 360f
        layoutControls()
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= 28) {
            val cut = insets.displayCutout
            insL = (cut?.safeInsetLeft ?: 0).toFloat(); insT = (cut?.safeInsetTop ?: 0).toFloat()
            insR = (cut?.safeInsetRight ?: 0).toFloat(); insB = (cut?.safeInsetBottom ?: 0).toFloat()
            layoutControls()
        }
        return super.onApplyWindowInsets(insets)
    }

    /**
     * Compact layout: steering pair bottom-left, accelerator bottom-right with the brake to its left and
     * N2O above it. Buttons are small but every hit area stays >= 48 dp at common densities, and the
     * hit circles never overlap (checked: centre distances exceed the sum of the padded radii).
     */
    private fun layoutControls() {
        if (w <= 0f) return
        val m = 14f * u
        val l = insL + m; val r = w - insR - m; val bt = h - insB - m; val tp = insT + m
        set(ACC, r - 52f * u, bt - 52f * u, 52f * u)
        set(BRK, r - 52f * u * 2f - 14f * u - 40f * u, bt - 40f * u, 40f * u)
        set(NIT, r - 28f * u, bt - 52f * u * 2f - 12f * u - 28f * u, 28f * u)
        set(PAUSE, r - 20f * u, tp + 20f * u, 20f * u)
        set(CAM, r - 20f * u * 3.2f, tp + 20f * u, 20f * u)
        set(LEFT, l + 44f * u, bt - 44f * u, 44f * u)
        set(RIGHT, l + 44f * u * 3f + 14f * u, bt - 44f * u, 44f * u)
        set(WHEEL, l + 80f * u, bt - 80f * u, 80f * u)
    }

    private fun set(id: Int, cx: Float, cy: Float, r: Float) { geo[id][0] = cx; geo[id][1] = cy; geo[id][2] = r }

    private fun inside(id: Int, x: Float, y: Float, pad: Float = 1f): Boolean =
        hypot(x - geo[id][0], y - geo[id][1]) <= geo[id][2] * pad

    private fun hit(x: Float, y: Float): Int {
        if (inside(PAUSE, x, y, 1.2f)) return PAUSE
        if (inside(CAM, x, y, 1.2f)) return CAM
        if (inside(ACC, x, y, 1.12f)) return ACC
        if (inside(NIT, x, y, 1.2f)) return NIT
        if (inside(BRK, x, y, 1.12f)) return BRK
        when (scheme) {
            0 -> { if (inside(LEFT, x, y, 1.12f)) return LEFT; if (inside(RIGHT, x, y, 1.12f)) return RIGHT }
            1, 2 -> if (inside(WHEEL, x, y, 1.25f)) return WHEEL
        }
        return 0
    }

    private fun updateWheel(x: Float) {
        val r = geo[WHEEL][2] * 0.85f
        wheelVal = ((x - geo[WHEEL][0]) / r).coerceIn(-1f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                if (id < owners.size) {
                    owners[id] = hit(e.getX(i), e.getY(i))
                    if (owners[id] == WHEEL) updateWheel(e.getX(i))
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val id = e.getPointerId(i)
                if (id >= owners.size) continue
                if (owners[id] == WHEEL) updateWheel(e.getX(i))
                else if (owners[id] == LEFT || owners[id] == RIGHT) {
                    // a thumb may slide from one steering button to the other without lifting
                    val hh = hit(e.getX(i), e.getY(i))
                    if (hh == LEFT || hh == RIGHT) owners[id] = hh
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                if (id < owners.size) {
                    val c = owners[id]
                    if (c == PAUSE && hit(e.getX(i), e.getY(i)) == PAUSE) onPause()
                    if (c == CAM && hit(e.getX(i), e.getY(i)) == CAM) onCamera()
                    if (c == WHEEL) wheelVal = 0f
                    owners[id] = 0
                }
            }
            MotionEvent.ACTION_CANCEL -> { for (i in owners.indices) owners[i] = 0; wheelVal = 0f }
        }
        recompute()
        return true
    }

    private fun held(c: Int): Boolean { for (o in owners) if (o == c) return true; return false }

    private fun recompute() {
        input.accel = held(ACC)
        input.brake = held(BRK)
        input.nitro = held(NIT)
        when (scheme) {
            0 -> input.steer = ((if (held(RIGHT)) 1f else 0f) - (if (held(LEFT)) 1f else 0f)) * sensitivity
            1, 2 -> input.steer = wheelVal * sensitivity
            // scheme 3 (tilt): the sensor callback writes input.steer
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        if (!hasWindowFocus) releaseAll()      // never leave a control stuck when the app loses focus
        super.onWindowFocusChanged(hasWindowFocus)
    }

    override fun onDetachedFromWindow() {
        releaseAll()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        if (visibility != VISIBLE) releaseAll()
        super.onVisibilityChanged(changedView, visibility)
    }

    /** Release everything (used on pause / lifecycle changes). */
    fun releaseAll() {
        for (i in owners.indices) owners[i] = 0
        wheelVal = 0f
        input.accel = false; input.brake = false; input.nitro = false
        if (scheme != 3) input.steer = 0f
    }

    // ------------------------------------------------------------------ drawing
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, align: Paint.Align = Paint.Align.CENTER) {
        tp.textSize = size; tp.color = col; tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    /** Rounded-square button: translucent dark body, soft glow, thin accent border, icon on top. */
    private fun button(c: Canvas, id: Int, col: Int, pressed: Boolean, icon: (Canvas, Float, Float, Float, Int) -> Unit) {
        val cx = geo[id][0]; val cy = geo[id][1]
        val r = geo[id][2] * (if (pressed) 0.94f else 1f)
        val corner = r * 0.46f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        // soft glow (two wide, faint strokes)
        p.style = Paint.Style.STROKE
        p.color = Color.argb(if (pressed) 70 else 34, Color.red(col), Color.green(col), Color.blue(col))
        p.strokeWidth = 7f * u
        c.drawRoundRect(rect, corner, corner, p)
        p.style = Paint.Style.FILL
        p.color = if (pressed) Color.argb(205, Color.red(col), Color.green(col), Color.blue(col)) else Color.argb(120, 14, 18, 28)
        c.drawRoundRect(rect, corner, corner, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * u
        p.color = Color.argb(if (pressed) 255 else 215, Color.red(col), Color.green(col), Color.blue(col))
        c.drawRoundRect(rect, corner, corner, p)
        icon(c, cx, cy, r, if (pressed) 0xFF0B0E14.toInt() else col)
    }

    private fun stroke(width: Float, col: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = width; p.color = col
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    }

    private fun chevron(c: Canvas, cx: Float, cy: Float, w: Float, hgt: Float, dir: Int) {
        // dir: 0 up, 1 left, 2 right
        path.reset()
        when (dir) {
            0 -> { path.moveTo(cx - w, cy + hgt); path.lineTo(cx, cy - hgt); path.lineTo(cx + w, cy + hgt) }
            1 -> { path.moveTo(cx + hgt, cy - w); path.lineTo(cx - hgt, cy); path.lineTo(cx + hgt, cy + w) }
            else -> { path.moveTo(cx - hgt, cy - w); path.lineTo(cx + hgt, cy); path.lineTo(cx - hgt, cy + w) }
        }
        c.drawPath(path, p)
    }

    private val iconAcc: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        stroke(r * 0.15f, col)
        chevron(c, cx, cy + r * 0.2f, r * 0.42f, r * 0.2f, 0)
        chevron(c, cx, cy - r * 0.2f, r * 0.42f, r * 0.2f, 0)
    }
    private val iconBrake: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        stroke(r * 0.12f, col)
        c.drawCircle(cx, cy, r * 0.46f, p)                       // brake disc
        p.style = Paint.Style.FILL; p.color = col
        c.drawCircle(cx, cy, r * 0.1f, p)                        // hub
        for (k in 0 until 4) {                                   // cooling holes
            val a = k * 1.5708f + 0.785f
            c.drawCircle(cx + cos(a) * r * 0.26f, cy + sin(a) * r * 0.26f, r * 0.045f, p)
        }
        stroke(r * 0.12f, col)
        rect2.set(cx - r * 0.64f, cy - r * 0.64f, cx + r * 0.64f, cy + r * 0.64f)
        c.drawArc(rect2, -35f, 70f, false, p)                    // caliper
    }
    private val iconNitro: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        path.reset()
        path.moveTo(cx + r * 0.12f, cy - r * 0.6f)
        path.lineTo(cx - r * 0.34f, cy + r * 0.08f)
        path.lineTo(cx - r * 0.02f, cy + r * 0.08f)
        path.lineTo(cx - r * 0.14f, cy + r * 0.6f)
        path.lineTo(cx + r * 0.36f, cy - r * 0.12f)
        path.lineTo(cx + r * 0.04f, cy - r * 0.12f)
        path.close()
        p.style = Paint.Style.FILL; p.color = col
        c.drawPath(path, p)
    }
    private val iconLeft: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        stroke(r * 0.15f, col); chevron(c, cx, cy, r * 0.42f, r * 0.24f, 1)
    }
    private val iconRight: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        stroke(r * 0.15f, col); chevron(c, cx, cy, r * 0.42f, r * 0.24f, 2)
    }
    private val iconPause: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        p.style = Paint.Style.FILL; p.color = col
        rect2.set(cx - r * 0.34f, cy - r * 0.38f, cx - r * 0.1f, cy + r * 0.38f); c.drawRoundRect(rect2, r * 0.08f, r * 0.08f, p)
        rect2.set(cx + r * 0.1f, cy - r * 0.38f, cx + r * 0.34f, cy + r * 0.38f); c.drawRoundRect(rect2, r * 0.08f, r * 0.08f, p)
    }
    private val iconCam: (Canvas, Float, Float, Float, Int) -> Unit = { c, cx, cy, r, col ->
        stroke(r * 0.12f, col)
        rect2.set(cx - r * 0.5f, cy - r * 0.32f, cx + r * 0.5f, cy + r * 0.38f); c.drawRoundRect(rect2, r * 0.14f, r * 0.14f, p)
        c.drawCircle(cx, cy + r * 0.03f, r * 0.17f, p)
    }
    private val rect2 = RectF()

    override fun onDraw(c: Canvas) {
        val s = sim ?: return
        pumpEvents(s)
        val ratio = (s.speed / s.vmax).coerceIn(0f, 1.3f)
        if (gfx.speedFx && ratio > 0.55f) speedLines(c, ratio)

        // buttons
        button(c, ACC, 0xFF3DDC84.toInt(), held(ACC), iconAcc)
        button(c, BRK, 0xFFFF3D2E.toInt(), held(BRK), iconBrake)
        button(c, NIT, 0xFF19D3FF.toInt(), held(NIT), iconNitro)
        button(c, PAUSE, 0xFFEAF0FA.toInt(), false, iconPause)
        button(c, CAM, 0xFFEAF0FA.toInt(), false, iconCam)
        when (scheme) {
            0 -> { button(c, LEFT, 0xFFFFC542.toInt(), held(LEFT), iconLeft); button(c, RIGHT, 0xFFFFC542.toInt(), held(RIGHT), iconRight) }
            1 -> wheel(c)
            2 -> joystick(c)
        }

        // speed + nitro
        val spd = (s.speed * 3.6f).toInt()
        if (spd != lastSpd) { lastSpd = spd; spdStr = spd.toString() }          // cached: no per-frame string allocation
        txt(c, spdStr, w / 2f, h - 48f * u, 56f * u, Color.WHITE)
        txt(c, "KM/H", w / 2f, h - 22f * u, 14f * u, 0xFF8A97AD.toInt())
        val g = s.gear
        if (g != lastGear) { lastGear = g; gearStr = "G" + (g + 1) }
        txt(c, gearStr, w / 2f + 92f * u, h - 48f * u, 24f * u, 0xFFFFC542.toInt())
        // RPM bar (turns red near the limiter)
        p.style = Paint.Style.FILL; p.color = Color.argb(120, 20, 26, 38)
        rect.set(w / 2f - 90f * u, h - 142f * u, w / 2f + 90f * u, h - 136f * u)
        c.drawRoundRect(rect, 3f * u, 3f * u, p)
        val rp = s.rpm.coerceIn(0f, 1f)
        p.color = if (rp > 0.9f) 0xFFFF3D2E.toInt() else 0xFFFFC542.toInt()
        rect.right = w / 2f - 90f * u + 180f * u * rp
        c.drawRoundRect(rect, 3f * u, 3f * u, p)
        p.style = Paint.Style.FILL; p.color = Color.argb(120, 20, 26, 38)
        rect.set(w / 2f - 90f * u, h - 130f * u, w / 2f + 90f * u, h - 118f * u)
        c.drawRoundRect(rect, 6f * u, 6f * u, p)
        p.color = 0xFF19D3FF.toInt()
        rect.right = w / 2f - 90f * u + 180f * u * (s.nitro / s.perf.nitro).coerceIn(0f, 1f)
        c.drawRoundRect(rect, 6f * u, 6f * u, p)

        // top-left: coins / distance / score
        val hx = insL + 20f * u
        txt(c, "COINS ${s.coins}", hx, insT + 34f * u, 20f * u, 0xFFFFC542.toInt(), Paint.Align.LEFT)
        txt(c, "${s.dist.toInt()} m", hx, insT + 60f * u, 18f * u, Color.WHITE, Paint.Align.LEFT)
        txt(c, "SCORE ${s.liveScore()}", hx, insT + 84f * u, 16f * u, 0xFF8A97AD.toInt(), Paint.Align.LEFT)

        // top-centre: timer / objective
        val t = if (s.cfg.mode == Mode.TIME_ATTACK || s.cfg.timeLimit > 0f) s.timeLeft else s.time
        txt(c, fmtTime(t), w / 2f - 30f * u, 38f * u, 30f * u, if ((s.cfg.mode == Mode.TIME_ATTACK || s.cfg.timeLimit > 0f) && t < 10f) 0xFFFF3D2E.toInt() else Color.WHITE)
        txt(c, s.cfg.objectiveLabel(), w / 2f - 30f * u, 60f * u, 14f * u, 0xFF8A97AD.toInt())
        if (s.cfg.objective.ordinal != 0) {
            p.style = Paint.Style.FILL; p.color = Color.argb(120, 20, 26, 38)
            rect.set(w / 2f - 120f * u, 68f * u, w / 2f + 60f * u, 74f * u); c.drawRoundRect(rect, 3f * u, 3f * u, p)
            p.color = 0xFF3DDC84.toInt(); rect.right = rect.left + rect.width() * s.objectiveFrac(); c.drawRoundRect(rect, 3f * u, 3f * u, p)
        }
        if (s.cfg.mode == Mode.ESCAPE) {
            val danger = s.policeGap < 40f
            txt(c, "POLICE ${s.policeGap.toInt()} m", w / 2f - 30f * u, 92f * u, 16f * u, if (danger) 0xFFFF3D2E.toInt() else 0xFF19D3FF.toInt())
        }
        if (s.checkpointMsg > 0f) txt(c, "CHECKPOINT +12s", w / 2f, h * 0.35f, 28f * u, 0xFF3DDC84.toInt())
        if (s.invuln > 0f) txt(c, "RECOVERING", w / 2f, h * 0.3f, 18f * u, 0xFFFFC542.toInt())

        // centre messages
        when (s.state) {
            RaceSim.State.COUNTDOWN -> {
                val n = Math.ceil(s.countdown.toDouble()).toInt()
                txt(c, n.toString(), w / 2f, h * 0.5f, 110f * u, Color.WHITE)
            }
            RaceSim.State.CRASHED -> txt(c, "CRASH!", w / 2f, h * 0.5f, 90f * u, 0xFFFF3D2E.toInt())
            else -> if (s.time < 1f && s.state == RaceSim.State.RACING) txt(c, "GO!", w / 2f, h * 0.5f, 100f * u, 0xFF3DDC84.toInt())
        }

        if (debug) {
            val lines = arrayOf(
                "FPS ${fpsProvider().toInt()}", "Speed ${(s.speed * 3.6f).toInt()} km/h",
                "Traffic ${s.activeVehicles}", "Mode ${s.cfg.mode.label}",
                "Collision ${if (s.collisionFlash > 0f) "YES" else "no"}", "Graphics ${gfx.name}", "Camera ${camName()}"
            )
            for ((i, l) in lines.withIndex()) txt(c, l, 20f * u, 120f * u + i * 18f * u, 14f * u, 0xFF00FF66.toInt(), Paint.Align.LEFT)
        }
        postInvalidateOnAnimation()
    }

    private fun fmtTime(t: Float): String {
        val s = t.coerceAtLeast(0f).toInt()
        if (s != lastSec) { lastSec = s; timeStr = "%d:%02d".format(s / 60, s % 60) }
        return timeStr
    }

    private fun wheel(c: Canvas) {
        val cx = geo[WHEEL][0]; val cy = geo[WHEEL][1]; val r = geo[WHEEL][2]
        val a = wheelVal * 1.4f
        p.style = Paint.Style.STROKE; p.strokeWidth = 14f * u; p.color = 0xFFFFC542.toInt()
        c.drawCircle(cx, cy, r * 0.85f, p)
        p.strokeWidth = 6f * u
        for (k in 0 until 3) {
            val ang = a + k * 2.094f - 1.5708f
            c.drawLine(cx, cy, cx + cos(ang) * r * 0.85f, cy + sin(ang) * r * 0.85f, p)
        }
    }

    private fun joystick(c: Canvas) {
        val cx = geo[WHEEL][0]; val cy = geo[WHEEL][1]; val r = geo[WHEEL][2]
        p.style = Paint.Style.FILL; p.color = Color.argb(90, 20, 26, 38); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f * u; p.color = 0xFFFFC542.toInt(); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFFFC542.toInt()
        c.drawCircle(cx + wheelVal * r * 0.7f, cy, r * 0.38f, p)
    }

    private fun speedLines(c: Canvas, ratio: Float) {
        val cx = w / 2f; val cy = h * 0.45f
        val alpha = (((ratio - 0.55f) / 0.5f).coerceIn(0f, 1f) * 110f).toInt()
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * u; p.color = Color.argb(alpha, 255, 255, 255)
        val phase = (System.nanoTime() / 40_000_000L % 7L).toFloat()
        for (i in 0 until 16) {
            val ang = i * 0.3927f + (i % 3) * 0.05f
            val r0 = (0.42f + ((i * 37 + phase * 9f) % 30f) / 100f) * w
            val r1 = r0 + 0.12f * w
            c.drawLine(cx + cos(ang) * r0, cy + sin(ang) * r0, cx + cos(ang) * r1, cy + sin(ang) * r1, p)
        }
    }

    /** Sounds / vibration / engine pitch derived from simulation changes (runs on the UI thread). */
    private var lastSim: RaceSim? = null

    private fun pumpEvents(s: RaceSim) {
        if (s !== lastSim) { lastSim = s; lastCd = -1; lastCoins = 0; lastCrash = 0; lastEnded = false }
        if (s.state == RaceSim.State.COUNTDOWN) {
            val n = Math.ceil(s.countdown.toDouble()).toInt()
            if (n != lastCd) { lastCd = n; Sound.countdown() }
        } else if (lastCd != 0) { lastCd = 0; Sound.go() }
        if (s.coins != lastCoins) { lastCoins = s.coins; Sound.coin() }
        if (s.crashCount != lastCrash) { lastCrash = s.crashCount; Sound.crash(); onHaptic() }
        val ended = s.state == RaceSim.State.ENDED
        if (ended && !lastEnded) Sound.finish()
        lastEnded = ended
        val ratio = (s.speed / s.vmax).coerceIn(0f, 1f)
        onEngine(s.rpm.coerceIn(0f, 1.2f), kotlin.math.max(0.15f, s.throttleLevel), ratio)
    }
}
