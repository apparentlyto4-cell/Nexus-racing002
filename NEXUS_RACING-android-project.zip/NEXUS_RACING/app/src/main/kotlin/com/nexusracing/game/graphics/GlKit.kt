package com.nexusracing.game.graphics

import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.sin

/** Interleaved position+normal triangle list stored in a VAO/VBO (OpenGL ES 3.0). */
class Mesh(data: FloatArray) {
    private val vao: Int
    private val count = data.size / 6

    init {
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glBindVertexArray(vao)
        GLES20.glGenBuffers(1, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(data)
        fb.position(0)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 24, 0)
        GLES20.glEnableVertexAttribArray(1)
        GLES20.glVertexAttribPointer(1, 3, GLES20.GL_FLOAT, false, 24, 12)
        GLES30.glBindVertexArray(0)
    }

    fun draw() {
        GLES30.glBindVertexArray(vao)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }
}

/** Procedural unit meshes: every model in the game is built from these three. */
object Meshes {
    private class FB {
        var a = FloatArray(4096)
        var n = 0
        fun v(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
            if (n + 6 > a.size) a = a.copyOf(a.size * 2)
            a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = nx; a[n++] = ny; a[n++] = nz
        }
        fun done(): FloatArray = a.copyOf(n)
    }

    private fun quad(
        f: FB, ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float, dx: Float, dy: Float, dz: Float, nx: Float, ny: Float, nz: Float
    ) {
        f.v(ax, ay, az, nx, ny, nz); f.v(bx, by, bz, nx, ny, nz); f.v(cx, cy, cz, nx, ny, nz)
        f.v(ax, ay, az, nx, ny, nz); f.v(cx, cy, cz, nx, ny, nz); f.v(dx, dy, dz, nx, ny, nz)
    }

    /** 1 x 1 x 1 cube centred on the origin. */
    fun cube(): FloatArray {
        val f = FB()
        quad(f, 0.5f, -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 1f, 0f, 0f)
        quad(f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -1f, 0f, 0f)
        quad(f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, 0f, 1f, 0f)
        quad(f, -0.5f, -0.5f, 0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0f, -1f, 0f)
        quad(f, -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0f, 0f, 1f)
        quad(f, 0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0f, 0f, -1f)
        return f.done()
    }

    /** Cylinder, radius 0.5, height 1, axis = Y. */
    fun cylinder(seg: Int): FloatArray {
        val f = FB()
        for (i in 0 until seg) {
            val a0 = (2.0 * Math.PI * i / seg).toFloat()
            val a1 = (2.0 * Math.PI * (i + 1) / seg).toFloat()
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            val x0 = 0.5f * c0; val z0 = 0.5f * s0; val x1 = 0.5f * c1; val z1 = 0.5f * s1
            f.v(x0, -0.5f, z0, c0, 0f, s0); f.v(x1, -0.5f, z1, c1, 0f, s1); f.v(x1, 0.5f, z1, c1, 0f, s1)
            f.v(x0, -0.5f, z0, c0, 0f, s0); f.v(x1, 0.5f, z1, c1, 0f, s1); f.v(x0, 0.5f, z0, c0, 0f, s0)
            f.v(0f, 0.5f, 0f, 0f, 1f, 0f); f.v(x0, 0.5f, z0, 0f, 1f, 0f); f.v(x1, 0.5f, z1, 0f, 1f, 0f)
            f.v(0f, -0.5f, 0f, 0f, -1f, 0f); f.v(x1, -0.5f, z1, 0f, -1f, 0f); f.v(x0, -0.5f, z0, 0f, -1f, 0f)
        }
        return f.done()
    }

    /** Cone, base radius 0.5 at y=-0.5, apex at y=+0.5. */
    fun cone(seg: Int): FloatArray {
        val f = FB()
        for (i in 0 until seg) {
            val a0 = (2.0 * Math.PI * i / seg).toFloat()
            val a1 = (2.0 * Math.PI * (i + 1) / seg).toFloat()
            val am = (a0 + a1) / 2f
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            f.v(0.5f * c0, -0.5f, 0.5f * s0, c0, 0.6f, s0)
            f.v(0.5f * c1, -0.5f, 0.5f * s1, c1, 0.6f, s1)
            f.v(0f, 0.5f, 0f, cos(am), 0.6f, sin(am))
            f.v(0f, -0.5f, 0f, 0f, -1f, 0f)
            f.v(0.5f * c1, -0.5f, 0.5f * s1, 0f, -1f, 0f)
            f.v(0.5f * c0, -0.5f, 0.5f * s0, 0f, -1f, 0f)
        }
        return f.done()
    }
}

/** Owns the shader program and the shared meshes. Create it on the GL thread (onSurfaceCreated). */
class GlKit {
    private var prog = 0
    private var uMvp = 0
    private var uModel = 0
    private var uColor = 0
    private var uLightDir = 0
    private var uAmbient = 0
    private var uIntensity = 0
    private var uLit = 0
    private var uFogColor = 0
    private var uFogK = 0
    lateinit var cube: Mesh
    lateinit var cyl: Mesh
    lateinit var cone: Mesh
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private var vp = FloatArray(16)

    // frame state, shared with other shaders (the GLB renderer) so lighting and fog always match
    var lightX = 0.45f; var lightY = 1f; var lightZ = 0.55f
    var ambient = 0.55f; var intensity = 1f
    var fogR = 0.5f; var fogG = 0.6f; var fogB = 0.8f
    var fogK = 0f
    var eyeX = 0f; var eyeY = 1.7f; var eyeZ = 4.2f

    fun vpMatrix(): FloatArray = vp
    fun setEye(x: Float, y: Float, z: Float) { eyeX = x; eyeY = y; eyeZ = z }
    /** Re-select this kit's program after another shader drew. */
    fun useProgram() { GLES20.glUseProgram(prog) }

    companion object {
        private const val VS = """#version 300 es
uniform mat4 uMVP;
uniform mat4 uModel;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
out vec3 vN;
out float vDist;
void main() {
    vN = mat3(uModel) * aNormal;
    gl_Position = uMVP * vec4(aPos, 1.0);
    vDist = gl_Position.w;
}
"""
        private const val FS = """#version 300 es
precision highp float;
uniform vec4 uColor;
uniform vec3 uLightDir;
uniform float uAmbient;
uniform float uIntensity;
uniform float uLit;
uniform vec3 uFogColor;
uniform float uFogK;
in vec3 vN;
in float vDist;
out vec4 outColor;
void main() {
    vec3 n = normalize(vN);
    float d = max(dot(n, normalize(uLightDir)), 0.0);
    float l = mix(1.0, uIntensity * (uAmbient + (1.0 - uAmbient) * d), uLit);
    vec3 c = uColor.rgb * l;
    float x = vDist * uFogK;
    float f = 1.0 - exp(-x * x);
    c = mix(c, uFogColor, clamp(f, 0.0, 1.0));
    outColor = vec4(c, 1.0);
}
"""
    }

    fun init() {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Program link error: " + GLES20.glGetProgramInfoLog(prog))
        uMvp = GLES20.glGetUniformLocation(prog, "uMVP")
        uModel = GLES20.glGetUniformLocation(prog, "uModel")
        uColor = GLES20.glGetUniformLocation(prog, "uColor")
        uLightDir = GLES20.glGetUniformLocation(prog, "uLightDir")
        uAmbient = GLES20.glGetUniformLocation(prog, "uAmbient")
        uIntensity = GLES20.glGetUniformLocation(prog, "uIntensity")
        uLit = GLES20.glGetUniformLocation(prog, "uLit")
        uFogColor = GLES20.glGetUniformLocation(prog, "uFogColor")
        uFogK = GLES20.glGetUniformLocation(prog, "uFogK")
        cube = Mesh(Meshes.cube())
        cyl = Mesh(Meshes.cylinder(14))
        cone = Mesh(Meshes.cone(10))
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader compile error: $log")
        }
        return s
    }

    /** Start a frame: view-projection matrix, lighting and fog. */
    fun begin(
        vpMat: FloatArray, lx: Float, ly: Float, lz: Float, ambient: Float, intensity: Float,
        fr: Float, fg: Float, fb: Float, fogK: Float
    ) {
        vp = vpMat
        lightX = lx; lightY = ly; lightZ = lz; this.ambient = ambient; this.intensity = intensity
        fogR = fr; fogG = fg; fogB = fb; this.fogK = fogK
        GLES20.glUseProgram(prog)
        GLES20.glUniform3f(uLightDir, lx, ly, lz)
        GLES20.glUniform1f(uAmbient, ambient)
        GLES20.glUniform1f(uIntensity, intensity)
        GLES20.glUniform3f(uFogColor, fr, fg, fb)
        GLES20.glUniform1f(uFogK, fogK)
    }

    fun setFog(k: Float) { fogK = k; GLES20.glUniform1f(uFogK, k) }

    /**
     * Draw one mesh. Model = base * T(p) * Ry * Rx * Rz * S. Rotations in degrees.
     * No allocations: all temporaries are preallocated.
     */
    fun draw(
        mesh: Mesh, base: FloatArray, px: Float, py: Float, pz: Float,
        rx: Float, ry: Float, rz: Float, sx: Float, sy: Float, sz: Float, color: Int, lit: Boolean
    ) {
        System.arraycopy(base, 0, model, 0, 16)
        Matrix.translateM(model, 0, px, py, pz)
        if (ry != 0f) Matrix.rotateM(model, 0, ry, 0f, 1f, 0f)
        if (rx != 0f) Matrix.rotateM(model, 0, rx, 1f, 0f, 0f)
        if (rz != 0f) Matrix.rotateM(model, 0, rz, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(
            uColor, ((color shr 16) and 255) / 255f, ((color shr 8) and 255) / 255f, (color and 255) / 255f, 1f
        )
        GLES20.glUniform1f(uLit, if (lit) 1f else 0f)
        mesh.draw()
    }
}

fun mixColor(a: Int, b: Int, t: Float): Int {
    val r = (((a shr 16) and 255) * (1f - t) + ((b shr 16) and 255) * t).toInt()
    val g = (((a shr 8) and 255) * (1f - t) + ((b shr 8) and 255) * t).toInt()
    val bl = ((a and 255) * (1f - t) + (b and 255) * t).toInt()
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
}

fun shadeColor(c: Int, f: Float): Int = mixColor(0xFF000000.toInt(), c, f.coerceIn(0f, 1f))
