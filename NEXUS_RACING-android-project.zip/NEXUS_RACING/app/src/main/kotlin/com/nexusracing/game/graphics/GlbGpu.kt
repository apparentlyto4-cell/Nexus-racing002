package com.nexusracing.game.graphics

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log

/**
 * GPU resources and drawing for ONE parsed GlbAsset in ONE GL context. Create it on the GL thread.
 *
 *  - Upload is spread over frames (step() does one primitive or one texture per call), so the render
 *    thread never stalls on a 11 MB upload; until ready() the caller draws the procedural bike.
 *  - Vertex buffers are uploaded straight from the shared file buffer (no CPU copies).
 *  - quality 0/1/2 (LOW/MEDIUM/HIGH): LOW halves texture resolution and skips normal mapping.
 *  - release() deletes every GL object this class created.
 *
 * Shading: base colour * (hemisphere ambient with occlusion + sun diffuse) + Blinn-Phong highlight with
 * Fresnel + a cheap sky/ground environment reflection driven by roughness and metalness + emissive.
 * Fog is identical to the rest of the scene. The tangent frame comes from screen-space derivatives,
 * so no tangent attribute is needed.
 */
class GlbGpu(private val asset: GlbAsset, private val quality: Int) {
    companion object {
        private const val TAG = "GlbGpu"
        private const val BLEND_MAX_INDICES = 30000   // larger BLEND primitives are drawn opaque (unsorted blending looks wrong)

        private const val VS = """#version 300 es
uniform mat4 uMVP;
uniform mat4 uModel;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
out vec3 vWPos;
out vec3 vN;
out vec2 vUV;
out float vDist;
void main() {
    vWPos = (uModel * vec4(aPos, 1.0)).xyz;
    vN = mat3(uModel) * aNormal;
    vUV = aUV;
    gl_Position = uMVP * vec4(aPos, 1.0);
    vDist = gl_Position.w;
}
"""
        private const val FS = """#version 300 es
precision highp float;
uniform sampler2D uBase;
uniform sampler2D uOrm;
uniform sampler2D uNorm;
uniform sampler2D uEmis;
uniform vec4 uBaseFactor;
uniform vec3 uEmisFactor;
uniform vec2 uMR;
uniform vec4 uFlags;
uniform float uBlend;
uniform vec3 uLightDir;
uniform float uAmbient;
uniform float uIntensity;
uniform vec3 uFogColor;
uniform float uFogK;
uniform vec3 uEye;
in vec3 vWPos;
in vec3 vN;
in vec2 vUV;
in float vDist;
out vec4 outColor;
void main() {
    vec4 base = uBaseFactor;
    if (uFlags.x > 0.5) base *= texture(uBase, vUV);
    float occ = 1.0;
    float metal = uMR.x;
    float rough = uMR.y;
    if (uFlags.y > 0.5) {
        vec3 orm = texture(uOrm, vUV).rgb;
        occ = orm.r;
        rough *= orm.g;
        metal *= orm.b;
    }
    rough = clamp(rough, 0.05, 1.0);
    metal = clamp(metal, 0.0, 1.0);
    vec3 n = normalize(vN);
    if (uFlags.z > 0.5) {
        vec3 dpx = dFdx(vWPos);
        vec3 dpy = dFdy(vWPos);
        vec2 dux = dFdx(vUV);
        vec2 duy = dFdy(vUV);
        float den = dux.x * duy.y - duy.x * dux.y;
        if (abs(den) > 1e-12) {
            vec3 t_ = (duy.y * dpx - dux.y * dpy) / den;
            vec3 ng = n;
            vec3 t = normalize(t_ - ng * dot(ng, t_));
            vec3 b = cross(ng, t);
            if (!gl_FrontFacing) { t = -t; b = -b; ng = -ng; }
            vec3 nm = texture(uNorm, vUV).xyz * 2.0 - 1.0;
            n = normalize(mat3(t, b, ng) * nm);
        } else if (!gl_FrontFacing) {
            n = -n;
        }
    } else if (!gl_FrontFacing) {
        n = -n;
    }
    vec3 L = normalize(uLightDir);
    vec3 V = normalize(uEye - vWPos);
    float ndl = max(dot(n, L), 0.0);
    float ndv = max(dot(n, V), 0.0);
    vec3 diffuseCol = base.rgb * (1.0 - metal);
    vec3 f0 = mix(vec3(0.04), base.rgb, metal);
    vec3 F = f0 + (1.0 - f0) * pow(1.0 - ndv, 5.0);
    vec3 skyC = uFogColor;
    vec3 gndC = uFogColor * 0.35;
    vec3 hemi = mix(gndC, skyC, n.y * 0.5 + 0.5);
    vec3 col = diffuseCol * uIntensity * (uAmbient * occ * (0.55 + 0.45 * hemi) + (1.0 - uAmbient) * ndl * mix(0.6, 1.0, occ));
    vec3 H = normalize(L + V);
    float a = rough * rough;
    float shin = clamp(2.0 / (a * a + 0.001) - 2.0, 2.0, 256.0);
    float spec = pow(max(dot(n, H), 0.0), shin) * (shin + 8.0) / 25.13;
    col += F * spec * ndl * uIntensity * occ;
    vec3 R = reflect(-V, n);
    vec3 env = mix(gndC, skyC, clamp(R.y * 0.5 + 0.5, 0.0, 1.0));
    col += F * env * (1.0 - rough) * (0.25 + 0.75 * metal) * occ * uIntensity;
    if (uFlags.w > 0.5) col += uEmisFactor * texture(uEmis, vUV).rgb;
    float x = vDist * uFogK;
    col = mix(col, uFogColor, clamp(1.0 - exp(-x * x), 0.0, 1.0));
    float alpha = mix(1.0, clamp(base.a + F.r * 0.5, 0.0, 1.0), uBlend);
    outColor = vec4(col, alpha);
}
"""
    }

    @Volatile var failed = false
        private set
    var ready = false
        private set

    private var prog = 0
    private var uMvp = 0; private var uModel = 0
    private var uBaseFactor = 0; private var uEmisFactor = 0; private var uMR = 0; private var uFlags = 0; private var uBlend = 0
    private var uLightDir = 0; private var uAmbient = 0; private var uIntensity = 0
    private var uFogColor = 0; private var uFogK = 0; private var uEye = 0
    private var uBaseS = 0; private var uOrmS = 0; private var uNormS = 0; private var uEmisS = 0

    private val prims = asset.prims
    private val vaos = IntArray(prims.size)
    private val bufs = HashMap<Int, Int>()
    private val texIds = IntArray(asset.textureImage.size)
    private val texTasks: IntArray
    private var stage = 0

    private val opaqueOrder: IntArray
    private val blendOrder: IntArray
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    init {
        // textures needed per quality level, most important first
        val want = LinkedHashSet<Int>()
        for (m in asset.materials) if (m.baseTex >= 0) want.add(m.baseTex)
        for (m in asset.materials) if (m.ormTex >= 0) want.add(m.ormTex)
        for (m in asset.materials) if (m.emissiveTex >= 0) want.add(m.emissiveTex)
        if (quality >= 1) for (m in asset.materials) if (m.normalTex >= 0) want.add(m.normalTex)
        texTasks = want.filter { it in texIds.indices }.toIntArray()

        // draw order: opaque primitives grouped by material, then the (few, small) blended ones
        val op = ArrayList<Int>(); val bl = ArrayList<Int>()
        for (i in prims.indices) (if (isBlended(i)) bl else op).add(i)
        opaqueOrder = op.sortedBy { prims[it].material }.toIntArray()
        blendOrder = bl.toIntArray()
    }

    private fun isBlended(i: Int): Boolean {
        val p = prims[i]
        return asset.materials[p.material].blend && (p.indices?.count ?: p.position.count) <= BLEND_MAX_INDICES
    }

    /** Uploads the next piece. Call once per frame until ready. Returns true when everything is uploaded. */
    fun step(): Boolean {
        if (ready) return true
        if (failed) return false
        try {
            if (prog == 0) { buildProgram(); return false }
            if (stage < prims.size) { uploadPrimitive(stage); stage++; return false }
            val ti = stage - prims.size
            if (ti < texTasks.size) { uploadTexture(texTasks[ti]); stage++; return false }
            ready = true
        } catch (t: Throwable) {
            Log.w(TAG, "GPU upload failed, using the procedural bike: ${t.message}")
            failed = true
        }
        return ready
    }

    // ------------------------------------------------------------------ setup
    private fun buildProgram() {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FS)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs); GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs)
        if (ok[0] == 0) { val log = GLES20.glGetProgramInfoLog(p); GLES20.glDeleteProgram(p); throw RuntimeException("GLB program link: $log") }
        prog = p
        fun u(n: String) = GLES20.glGetUniformLocation(p, n)
        uMvp = u("uMVP"); uModel = u("uModel"); uBaseFactor = u("uBaseFactor"); uEmisFactor = u("uEmisFactor")
        uMR = u("uMR"); uFlags = u("uFlags"); uBlend = u("uBlend"); uLightDir = u("uLightDir"); uAmbient = u("uAmbient")
        uIntensity = u("uIntensity"); uFogColor = u("uFogColor"); uFogK = u("uFogK"); uEye = u("uEye")
        uBaseS = u("uBase"); uOrmS = u("uOrm"); uNormS = u("uNorm"); uEmisS = u("uEmis")
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { val log = GLES20.glGetShaderInfoLog(s); GLES20.glDeleteShader(s); throw RuntimeException("GLB shader: $log") }
        return s
    }

    private fun buffer(view: Int, target: Int): Int {
        val key = view * 2 + (if (target == GLES20.GL_ELEMENT_ARRAY_BUFFER) 1 else 0)
        bufs[key]?.let { return it }
        val v = asset.views[view]
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        GLES20.glBindBuffer(target, ids[0])
        val d = asset.data.duplicate()
        d.limit(v.offset + v.length)
        d.position(v.offset)
        GLES20.glBufferData(target, v.length, d, GLES20.GL_STATIC_DRAW)
        bufs[key] = ids[0]
        return ids[0]
    }

    private fun glType(ct: Int): Int = ct   // glTF component type codes are the GL enum values

    private fun attrib(loc: Int, a: GlbAccessor) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer(a.view, GLES20.GL_ARRAY_BUFFER))
        GLES20.glEnableVertexAttribArray(loc)
        GLES20.glVertexAttribPointer(loc, a.comps, glType(a.componentType), a.normalized, asset.views[a.view].stride, a.byteOffset)
    }

    private fun uploadPrimitive(i: Int) {
        val p = prims[i]
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vaos[i] = ids[0]
        GLES30.glBindVertexArray(vaos[i])
        attrib(0, p.position)
        if (p.normal != null) attrib(1, p.normal)
        if (p.uv != null) attrib(2, p.uv)
        if (p.indices != null) GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, buffer(p.indices.view, GLES20.GL_ELEMENT_ARRAY_BUFFER))
        GLES30.glBindVertexArray(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun imageBytes(img: Int): ByteArray? {
        if (img !in asset.images.indices) return null
        val im = asset.images[img]
        if (im.bufferView >= 0) {
            val v = asset.views[im.bufferView]
            val out = ByteArray(v.length)
            val d = asset.data.duplicate()
            d.position(v.offset)
            d.get(out)
            return out
        }
        return im.inline
    }

    private fun uploadTexture(ti: Int) {
        val bytes = imageBytes(asset.textureImage[ti]) ?: return
        val opts = BitmapFactory.Options()
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888
        opts.inPremultiplied = false
        opts.inSampleSize = if (quality == 0) 2 else 1
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        val wrap = when (asset.textureWrapS[ti]) { 33071 -> GLES20.GL_CLAMP_TO_EDGE; 33648 -> GLES20.GL_MIRRORED_REPEAT; else -> GLES20.GL_REPEAT }
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap)
        bmp.recycle()
        texIds[ti] = ids[0]
    }

    // ------------------------------------------------------------------ drawing
    private fun bindTex(unit: Int, ti: Int, sampler: Int): Float {
        val id = if (ti in texIds.indices) texIds[ti] else 0
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glUniform1i(sampler, unit)
        return if (id != 0) 1f else 0f
    }

    /** Draw the whole model with `base` as the bike's world matrix (position / yaw / lean). Restores the kit program. */
    fun draw(kit: GlKit, base: FloatArray) {
        if (!ready) return
        GLES20.glUseProgram(prog)
        GLES20.glUniform3f(uLightDir, kit.lightX, kit.lightY, kit.lightZ)
        GLES20.glUniform1f(uAmbient, kit.ambient)
        GLES20.glUniform1f(uIntensity, kit.intensity)
        GLES20.glUniform3f(uFogColor, kit.fogR, kit.fogG, kit.fogB)
        GLES20.glUniform1f(uFogK, kit.fogK)
        GLES20.glUniform3f(uEye, kit.eyeX, kit.eyeY, kit.eyeZ)
        drawList(opaqueOrder, base, false)
        if (blendOrder.isNotEmpty()) {
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glDepthMask(false)
            drawList(blendOrder, base, true)
            GLES20.glDepthMask(true)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
        GLES30.glBindVertexArray(0)
        kit.useProgram()
    }

    private fun drawList(order: IntArray, base: FloatArray, blend: Boolean) {
        var lastMat = -1
        val vp = kit0Vp
        for (idx in order) {
            val p = prims[idx]
            if (p.material != lastMat) {
                lastMat = p.material
                val m = asset.materials[p.material]
                val hasBase = bindTex(0, m.baseTex, uBaseS)
                val hasOrm = bindTex(1, m.ormTex, uOrmS)
                val hasNrm = if (quality >= 1) bindTex(2, m.normalTex, uNormS) else 0f
                val hasEm = bindTex(3, m.emissiveTex, uEmisS)
                GLES20.glUniform4f(uFlags, hasBase, hasOrm, hasNrm, hasEm)
                GLES20.glUniform4f(uBaseFactor, m.baseColor[0], m.baseColor[1], m.baseColor[2], m.baseColor[3])
                val es = minOf(m.emissiveStrength, 3f)
                GLES20.glUniform3f(uEmisFactor, m.emissiveFactor[0] * es, m.emissiveFactor[1] * es, m.emissiveFactor[2] * es)
                GLES20.glUniform2f(uMR, m.metallic, m.roughness)
                GLES20.glUniform1f(uBlend, if (blend) 1f else 0f)
            }
            Matrix.multiplyMM(model, 0, base, 0, p.world, 0)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
            GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
            if (p.normal == null) GLES20.glVertexAttrib3f(1, 0f, 1f, 0f)
            if (p.uv == null) GLES20.glVertexAttrib2f(2, 0f, 0f)
            GLES30.glBindVertexArray(vaos[idx])
            val ix = p.indices
            if (ix != null) GLES20.glDrawElements(GLES20.GL_TRIANGLES, ix.count, glType(ix.componentType), ix.byteOffset)
            else GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, p.position.count)
        }
    }

    private var kit0Vp: FloatArray = FloatArray(16)

    /** Must be called before draw(): the view-projection matrix of the current frame (from GlKit.begin). */
    fun setViewProjection(vp: FloatArray) { kit0Vp = vp }

    fun release() {
        try {
            if (vaos.isNotEmpty()) GLES30.glDeleteVertexArrays(vaos.size, vaos, 0)
            if (bufs.isNotEmpty()) { val a = bufs.values.toIntArray(); GLES20.glDeleteBuffers(a.size, a, 0) }
            val t = texIds.filter { it != 0 }.toIntArray()
            if (t.isNotEmpty()) GLES20.glDeleteTextures(t.size, t, 0)
            if (prog != 0) GLES20.glDeleteProgram(prog)
        } catch (e: Throwable) {
            // the GL context may already be gone; its objects went with it
        }
        bufs.clear(); java.util.Arrays.fill(vaos, 0); java.util.Arrays.fill(texIds, 0)
        prog = 0; ready = false
    }
}
