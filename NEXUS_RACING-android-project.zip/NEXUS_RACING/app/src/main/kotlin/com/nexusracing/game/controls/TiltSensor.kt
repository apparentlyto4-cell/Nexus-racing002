package com.nexusracing.game.controls

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager

/**
 * Accelerometer based steering for landscape play. `raw` is -1..1 (tilt like a steering wheel,
 * clockwise = positive). start()/stop() must be paired with onResume()/onPause() to avoid leaks.
 */
class TiltSensor(private val ctx: Context, private val onValue: (Float) -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var sign = 1f
    private var lp = 0f
    @Volatile var raw = 0f
    val available: Boolean get() = acc != null

    @Suppress("DEPRECATION")
    fun start() {
        val a = acc ?: return
        val rot = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        sign = if (rot == Surface.ROTATION_270) -1f else 1f
        sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() { sm.unregisterListener(this) }

    override fun onSensorChanged(e: SensorEvent) {
        val g = (e.values[1] * sign / 9.81f).coerceIn(-1f, 1f)
        lp += (g - lp) * 0.25f
        raw = lp
        onValue(lp)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
