package com.nexusracing.game.graphics

import android.content.Context
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.Channels
import kotlin.math.sqrt

/**
 * Minimal glTF 2.0 binary (.glb) reader. No third-party dependency.
 *
 * Supported: triangle meshes (indexed or not), POSITION / NORMAL / TEXCOORD_0 as float or
 * (normalized) integer accessors, strided buffer views, node hierarchies with matrix or TRS,
 * metallic-roughness materials (base colour, packed occlusion/roughness/metal, normal, emissive),
 * KHR_materials_emissive_strength, KHR_mesh_quantization, alphaMode BLEND, embedded (bufferView or data:)
 * images. Anything unsupported that the file declares as *required* (Draco, meshopt, sparse
 * accessors...) makes parse() throw, and the game then falls back to the procedural bike.
 *
 * The parsed asset only holds CPU-side metadata plus the raw file buffer; vertex data is uploaded
 * to the GPU straight from that buffer (no per-vertex copies) by GlbGpu.
 */
class GlbBufferView(val offset: Int, val length: Int, val stride: Int)

class GlbAccessor(
    val view: Int, val byteOffset: Int, val componentType: Int, val count: Int,
    val comps: Int, val normalized: Boolean
)

class GlbPrimitive(
    val position: GlbAccessor, val normal: GlbAccessor?, val uv: GlbAccessor?, val indices: GlbAccessor?,
    val material: Int, val world: FloatArray
)

class GlbMaterial(
    val name: String, val baseColor: FloatArray, val baseTex: Int, val ormTex: Int, val normalTex: Int,
    val emissiveTex: Int, val emissiveFactor: FloatArray, val emissiveStrength: Float,
    val metallic: Float, val roughness: Float, val blend: Boolean
)

/** bufferView >= 0: bytes live in the GLB; otherwise inline holds decoded data-URI bytes (or null = unsupported). */
class GlbImage(val bufferView: Int, val inline: ByteArray?)

class GlbAsset(
    val data: ByteBuffer, val views: List<GlbBufferView>, val prims: List<GlbPrimitive>,
    val materials: List<GlbMaterial>, val textureImage: IntArray, val textureWrapS: IntArray,
    val images: List<GlbImage>
) {
    fun triangleCount(): Int { var n = 0; for (p in prims) n += (p.indices?.count ?: p.position.count) / 3; return n }
}

object GlbParser {
    private const val MAGIC = 0x46546C67      // "glTF"
    private const val CH_JSON = 0x4E4F534A    // "JSON"
    private const val CH_BIN = 0x004E4942     // "BIN\0"
    private val SUPPORTED_EXT = setOf("KHR_materials_emissive_strength", "KHR_mesh_quantization")

    fun parse(buf: ByteBuffer): GlbAsset {
        val b = buf.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        require(b.limit() >= 20) { "GLB too small" }
        require(b.getInt(0) == MAGIC) { "Not a GLB file" }
        require(b.getInt(4) == 2) { "Unsupported glTF version" }
        val total = b.getInt(8)
        require(total in 20..b.limit()) { "Truncated GLB" }
        var off = 12
        var jsonOff = -1; var jsonLen = 0; var binOff = -1
        while (off + 8 <= total) {
            val len = b.getInt(off)
            val type = b.getInt(off + 4)
            if (type == CH_JSON && jsonOff < 0) { jsonOff = off + 8; jsonLen = len }
            else if (type == CH_BIN && binOff < 0) binOff = off + 8
            off += 8 + len
        }
        require(jsonOff >= 0) { "GLB has no JSON chunk" }
        val jb = ByteArray(jsonLen)
        b.position(jsonOff); b.get(jb)
        val j = JSONObject(String(jb, Charsets.UTF_8).trim())

        val req = j.optJSONArray("extensionsRequired")
        if (req != null) for (i in 0 until req.length()) {
            val e = req.getString(i)
            require(e in SUPPORTED_EXT) { "Unsupported required extension: $e" }
        }
        require(binOff >= 0) { "GLB has no BIN chunk" }
        val buffers = j.getJSONArray("buffers")
        require(buffers.length() >= 1 && !buffers.getJSONObject(0).has("uri")) { "External buffers are not supported" }

        // buffer views
        val views = ArrayList<GlbBufferView>()
        val bvs = j.getJSONArray("bufferViews")
        for (i in 0 until bvs.length()) {
            val o = bvs.getJSONObject(i)
            require(o.optInt("buffer", 0) == 0) { "Only buffer 0 is supported" }
            val bo = binOff + o.optInt("byteOffset", 0)
            val bl = o.getInt("byteLength")
            require(bo >= 0 && bo + bl <= total) { "bufferView out of range" }
            views.add(GlbBufferView(bo, bl, o.optInt("byteStride", 0)))
        }

        // accessors
        val accs = ArrayList<GlbAccessor>()
        val aj = j.getJSONArray("accessors")
        for (i in 0 until aj.length()) {
            val o = aj.getJSONObject(i)
            require(!o.has("sparse")) { "Sparse accessors are not supported" }
            val comps = when (o.getString("type")) { "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; else -> 0 }
            accs.add(GlbAccessor(o.optInt("bufferView", -1), o.optInt("byteOffset", 0), o.getInt("componentType"),
                o.getInt("count"), comps, o.optBoolean("normalized", false)))
        }

        // materials
        val mats = ArrayList<GlbMaterial>()
        val mj = j.optJSONArray("materials") ?: JSONArray()
        for (i in 0 until mj.length()) mats.add(parseMaterial(mj.getJSONObject(i)))
        if (mats.isEmpty()) mats.add(GlbMaterial("default", floatArrayOf(1f, 1f, 1f, 1f), -1, -1, -1, -1,
            floatArrayOf(0f, 0f, 0f), 1f, 0f, 0.8f, false))

        // textures / images / samplers
        val tj = j.optJSONArray("textures") ?: JSONArray()
        val sj = j.optJSONArray("samplers") ?: JSONArray()
        val texImg = IntArray(tj.length())
        val texWrap = IntArray(tj.length())
        for (i in 0 until tj.length()) {
            val o = tj.getJSONObject(i)
            texImg[i] = o.optInt("source", -1)
            val si = o.optInt("sampler", -1)
            texWrap[i] = if (si in 0 until sj.length()) sj.getJSONObject(si).optInt("wrapS", 10497) else 10497
        }
        val images = ArrayList<GlbImage>()
        val ij = j.optJSONArray("images") ?: JSONArray()
        for (i in 0 until ij.length()) {
            val o = ij.getJSONObject(i)
            if (o.has("bufferView")) images.add(GlbImage(o.getInt("bufferView"), null))
            else {
                val uri = o.optString("uri", "")
                if (uri.startsWith("data:") && uri.contains(",")) {
                    val bytes = try { Base64.decode(uri.substring(uri.indexOf(',') + 1), Base64.DEFAULT) } catch (e: Exception) { null }
                    images.add(GlbImage(-1, bytes))
                } else images.add(GlbImage(-1, null))     // external image files: not supported, material renders untextured
            }
        }

        // nodes -> world matrices -> primitives
        val nodes = j.getJSONArray("nodes")
        val meshes = j.optJSONArray("meshes") ?: JSONArray()
        val prims = ArrayList<GlbPrimitive>()
        val scenes = j.optJSONArray("scenes")
        val sceneIdx = j.optInt("scene", 0)
        val roots = ArrayList<Int>()
        if (scenes != null && sceneIdx in 0 until scenes.length()) {
            val rn = scenes.getJSONObject(sceneIdx).optJSONArray("nodes")
            if (rn != null) for (i in 0 until rn.length()) roots.add(rn.getInt(i))
        } else for (i in 0 until nodes.length()) roots.add(i)

        fun visit(ni: Int, parent: FloatArray, depth: Int) {
            require(depth < 64) { "Node hierarchy too deep" }
            val n = nodes.getJSONObject(ni)
            val world = mul(parent, nodeMatrix(n))
            if (n.has("mesh")) {
                val mesh = meshes.getJSONObject(n.getInt("mesh"))
                val pa = mesh.getJSONArray("primitives")
                for (k in 0 until pa.length()) {
                    val p = pa.getJSONObject(k)
                    if (p.optInt("mode", 4) != 4) continue                     // triangles only
                    val at = p.getJSONObject("attributes")
                    if (!at.has("POSITION")) continue
                    val pos = accs[at.getInt("POSITION")]
                    require(pos.view >= 0 && pos.comps == 3) { "Bad POSITION accessor" }
                    val nrm = if (at.has("NORMAL")) accs[at.getInt("NORMAL")].takeIf { it.view >= 0 && it.comps == 3 } else null
                    val uv = if (at.has("TEXCOORD_0")) accs[at.getInt("TEXCOORD_0")].takeIf { it.view >= 0 && it.comps == 2 } else null
                    val idx = if (p.has("indices")) accs[p.getInt("indices")].takeIf { it.view >= 0 } else null
                    val mat = p.optInt("material", 0).coerceIn(0, mats.size - 1)
                    prims.add(GlbPrimitive(pos, nrm, uv, idx, mat, world))
                }
            }
            val ch = n.optJSONArray("children")
            if (ch != null) for (i in 0 until ch.length()) visit(ch.getInt(i), world, depth + 1)
        }
        for (r in roots) visit(r, identity(), 0)
        require(prims.isNotEmpty()) { "GLB contains no triangle meshes" }
        return GlbAsset(buf, views, prims, mats, texImg, texWrap, images)
    }

    private fun parseMaterial(m: JSONObject): GlbMaterial {
        val pbr = m.optJSONObject("pbrMetallicRoughness")
        val bc = floatArrayOf(1f, 1f, 1f, 1f)
        pbr?.optJSONArray("baseColorFactor")?.let { for (i in 0 until minOf(4, it.length())) bc[i] = it.getDouble(i).toFloat() }
        val ef = floatArrayOf(0f, 0f, 0f)
        m.optJSONArray("emissiveFactor")?.let { for (i in 0 until minOf(3, it.length())) ef[i] = it.getDouble(i).toFloat() }
        val mrTex = pbr?.optJSONObject("metallicRoughnessTexture")?.optInt("index", -1) ?: -1
        val strength = m.optJSONObject("extensions")?.optJSONObject("KHR_materials_emissive_strength")
            ?.optDouble("emissiveStrength", 1.0)?.toFloat() ?: 1f
        return GlbMaterial(
            m.optString("name", "material"), bc,
            pbr?.optJSONObject("baseColorTexture")?.optInt("index", -1) ?: -1,
            mrTex,                                    // the packed occlusion/roughness/metal texture (occlusion only used when packed with it)
            m.optJSONObject("normalTexture")?.optInt("index", -1) ?: -1,
            m.optJSONObject("emissiveTexture")?.optInt("index", -1) ?: -1,
            ef, strength,
            (pbr?.optDouble("metallicFactor", 1.0) ?: 1.0).toFloat(),
            (pbr?.optDouble("roughnessFactor", 1.0) ?: 1.0).toFloat(),
            m.optString("alphaMode", "OPAQUE") == "BLEND"
        )
    }

    // ---- small column-major 4x4 helpers (no android.opengl dependency, so they are JVM-testable) ----
    fun identity(): FloatArray { val m = FloatArray(16); m[0] = 1f; m[5] = 1f; m[10] = 1f; m[15] = 1f; return m }

    fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(16)
        for (c in 0 until 4) for (rr in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + rr] * b[c * 4 + k]
            r[c * 4 + rr] = s
        }
        return r
    }

    private fun nodeMatrix(n: JSONObject): FloatArray {
        val ma = n.optJSONArray("matrix")
        if (ma != null && ma.length() == 16) return FloatArray(16) { ma.getDouble(it).toFloat() }
        val t = n.optJSONArray("translation"); val r = n.optJSONArray("rotation"); val s = n.optJSONArray("scale")
        val tx = t?.getDouble(0)?.toFloat() ?: 0f; val ty = t?.getDouble(1)?.toFloat() ?: 0f; val tz = t?.getDouble(2)?.toFloat() ?: 0f
        var qx = r?.getDouble(0)?.toFloat() ?: 0f; var qy = r?.getDouble(1)?.toFloat() ?: 0f
        var qz = r?.getDouble(2)?.toFloat() ?: 0f; var qw = r?.getDouble(3)?.toFloat() ?: 1f
        val ql = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
        if (ql > 1e-6f) { qx /= ql; qy /= ql; qz /= ql; qw /= ql }
        val sx = s?.getDouble(0)?.toFloat() ?: 1f; val sy = s?.getDouble(1)?.toFloat() ?: 1f; val sz = s?.getDouble(2)?.toFloat() ?: 1f
        val m = FloatArray(16)
        m[0] = (1f - 2f * (qy * qy + qz * qz)) * sx; m[1] = (2f * (qx * qy + qz * qw)) * sx; m[2] = (2f * (qx * qz - qy * qw)) * sx
        m[4] = (2f * (qx * qy - qz * qw)) * sy; m[5] = (1f - 2f * (qx * qx + qz * qz)) * sy; m[6] = (2f * (qy * qz + qx * qw)) * sy
        m[8] = (2f * (qx * qz + qy * qw)) * sz; m[9] = (2f * (qy * qz - qx * qw)) * sz; m[10] = (1f - 2f * (qx * qx + qy * qy)) * sz
        m[12] = tx; m[13] = ty; m[14] = tz; m[15] = 1f
        return m
    }
}

/**
 * Process-wide cache of parsed models. Files are read and parsed ONCE on a background thread
 * (never on the render thread); every GL context then uploads from the shared, immutable asset.
 */
object GlbAssets {
    private const val TAG = "GlbAssets"
    private val loaded = HashMap<String, GlbAsset>()
    private val failed = HashSet<String>()
    private val loading = HashSet<String>()

    @Synchronized fun get(path: String): GlbAsset? = loaded[path]
    @Synchronized fun hasFailed(path: String): Boolean = failed.contains(path)

    fun preload(ctx: Context, path: String) {
        synchronized(this) {
            if (loaded.containsKey(path) || loading.contains(path) || failed.contains(path)) return
            loading.add(path)
        }
        val app = ctx.applicationContext
        val t = Thread({
            try {
                val asset = GlbParser.parse(readAsset(app, path))
                synchronized(this) { loaded[path] = asset }
                Log.i(TAG, "Loaded $path: ${asset.prims.size} primitives, ${asset.triangleCount()} triangles")
            } catch (e: Throwable) {            // includes OutOfMemoryError: the game falls back to the procedural bike
                Log.w(TAG, "Could not load $path: ${e.message}")
                synchronized(this) { failed.add(path) }
            } finally {
                synchronized(this) { loading.remove(path) }
            }
        }, "glb-loader")
        t.isDaemon = true
        t.priority = Thread.NORM_PRIORITY - 1
        t.start()
    }

    /** Drops the cached CPU copy (e.g. from onTrimMemory); the next preload() reads it again. */
    @Synchronized fun clear() { loaded.clear() }

    private fun readAsset(ctx: Context, path: String): ByteBuffer {
        try {
            ctx.assets.openFd(path).use { fd ->
                val len = fd.length
                if (len <= 0L || len > Int.MAX_VALUE) throw IOException("unknown asset length")
                val bb = ByteBuffer.allocateDirect(len.toInt()).order(ByteOrder.LITTLE_ENDIAN)
                fd.createInputStream().use { ins ->
                    val ch = Channels.newChannel(ins)
                    while (bb.hasRemaining()) { if (ch.read(bb) < 0) break }
                }
                if (bb.hasRemaining()) throw IOException("short read")
                bb.flip()
                return bb
            }
        } catch (e: IOException) {
            // compressed asset (no file descriptor available): stream it instead
        }
        val bytes = ctx.assets.open(path).use { it.readBytes() }
        val bb = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put(bytes)
        bb.flip()
        return bb
    }
}
