package com.nexusracing.game

import android.app.Application
import com.nexusracing.game.data.Bikes
import com.nexusracing.game.persistence.Save

class NexusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Bikes.load(this)   // bikes come from assets/config/bikes.json
        Save.init(this)    // then the save (validated against the bike list)
        // read + parse 3D bike models on a background thread so garage / race never wait for the disk
        for (b in Bikes.all) b.modelPath?.let { com.nexusracing.game.graphics.GlbAssets.preload(this, it) }
    }
}
