package com.nexusracing.game.gameplay

import com.nexusracing.game.data.BikeSpec
import com.nexusracing.game.persistence.Save
import kotlin.math.min

/** Five upgrade categories. Every level changes the real performance numbers used by RaceSim. */
object Upgrades {
    val names = arrayOf("Engine", "Acceleration", "Handling", "Braking", "Boost capacity")
    val descs = arrayOf(
        "+4% top speed per level", "+6% acceleration per level", "+5% steering response per level",
        "+6% braking power per level", "+0.6 s nitro capacity per level"
    )
    val units = arrayOf("km/h", "m/s²", "", "m/s²", "s")
    const val MAX = 5

    class Perf(val topKmh: Float, val accel: Float, val handling: Float, val braking: Float, val nitro: Float) {
        fun of(cat: Int): Float = when (cat) { 0 -> topKmh; 1 -> accel; 2 -> handling; 3 -> braking; else -> nitro }
    }

    fun level(bikeId: String, cat: Int): Int = (Save.d.upgrades["$bikeId:$cat"] ?: 0).coerceIn(0, MAX)
    fun cost(level: Int, cat: Int): Int = 500 * (level + 1) + cat * 100

    private fun build(b: BikeSpec, lv: IntArray) = Perf(
        capTop(b, b.topSpeedKmh * (1f + 0.04f * lv[0])),
        b.accel * (1f + 0.06f * lv[1]),
        min(1.2f, b.handling * (1f + 0.05f * lv[2])),
        b.braking * (1f + 0.06f * lv[3]),
        3f + 0.6f * lv[4]
    )

    /** Some bikes (the H2R) have a hard arcade speed limit that engine upgrades cannot exceed. */
    private fun capTop(b: BikeSpec, v: Float): Float {
        val cap = b.phys.speedCapKmh
        return if (cap > 0f) min(cap, v) else v
    }

    /** Performance with the saved upgrades; `plusOne` >= 0 previews one extra level in that category. */
    fun perfFor(b: BikeSpec, plusOne: Int = -1): Perf {
        val lv = IntArray(5) { level(b.id, it) }
        if (plusOne in 0..4) lv[plusOne] = min(MAX, lv[plusOne] + 1)
        return build(b, lv)
    }

    /** Returns null on success, otherwise a human-readable error. Never lets coins go negative. */
    fun buy(b: BikeSpec, cat: Int): String? {
        if (cat !in 0..4) return "Invalid upgrade"
        if (!Save.d.unlocked.contains(b.id)) return "You do not own this motorcycle"
        val l = level(b.id, cat)
        if (l >= MAX) return "Already at maximum level"
        if (!Progression.spend(cost(l, cat))) return "Not enough coins"
        Save.d.upgrades["${b.id}:$cat"] = l + 1
        Save.commit()
        return null
    }
}
