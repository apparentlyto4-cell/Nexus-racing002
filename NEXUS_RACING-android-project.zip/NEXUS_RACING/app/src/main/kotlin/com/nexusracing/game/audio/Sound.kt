package com.nexusracing.game.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.ToneGenerator
import com.nexusracing.game.persistence.Save
import kotlin.math.max

/** UI / race beeps. Generated with ToneGenerator, so no audio files are needed. Never throws. */
object Sound {
    private var tg: ToneGenerator? = null
    private var vol = -1

    private fun play(tone: Int, ms: Int) {
        val v = Save.d.sfx
        if (v <= 0) return
        try {
            if (tg == null || vol != v) {
                tg?.release()
                tg = ToneGenerator(AudioManager.STREAM_MUSIC, v)
                vol = v
            }
            tg?.startTone(tone, ms)
        } catch (e: Exception) {
            tg = null
        }
    }

    fun click() = play(ToneGenerator.TONE_PROP_BEEP, 40)
    fun countdown() = play(ToneGenerator.TONE_PROP_BEEP, 120)
    fun go() = play(ToneGenerator.TONE_PROP_BEEP2, 300)
    fun coin() = play(ToneGenerator.TONE_PROP_ACK, 60)
    fun crash() = play(ToneGenerator.TONE_CDMA_ABBR_ALERT, 350)
    fun finish() = play(ToneGenerator.TONE_PROP_PROMPT, 500)

    fun release() { tg?.release(); tg = null; vol = -1 }
}

/** Synthesised engine loop (AudioTrack stream, own thread). Pitch follows speed, loudness follows throttle. */
class EngineSynth {
    @Volatile var rpm = 0f
    @Volatile var throttle = 0f
    @Volatile var wind = 0f            // 0..1 fraction of top speed: drives the wind layer
    @Volatile var hzIdle = 35f         // per-bike engine pitch range (BikePhys.engineHzIdle / engineHzSpan)
    @Volatile var hzSpan = 170f
    @Volatile var whine = 0f           // supercharger whine level (0 = none)
    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        try {
            val sr = 22050
            val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            t.play()
            track = t
            running = true
            thread = Thread {
                val buf = ShortArray(512)
                var phase = 0f
                var y = 0f
                var wph = 0f
                var wn = 0f
                var seed = 12345
                while (running) {
                    val vol = Save.d.sfx / 100f
                    val f = hzIdle + rpm * hzSpan
                    val amp = vol * (0.25f + 0.5f * throttle)
                    val wd = wind * wind
                    val wAmp = vol * wd * 0.35f
                    val whAmp = vol * whine * throttle * rpm * 0.18f
                    for (i in buf.indices) {
                        phase += f / sr
                        if (phase >= 1f) phase -= 1f
                        val saw = 2f * phase - 1f
                        val pulse = if (phase < 0.35f) 1f else -1f
                        y += 0.25f * ((saw * 0.6f + pulse * 0.4f) - y)
                        var v = y * amp
                        // supercharger whine: a high sine tracking the engine
                        wph += (f * 7f) / sr
                        if (wph >= 1f) wph -= 1f
                        if (whAmp > 0f) v += kotlin.math.sin(wph * 6.2831855f) * whAmp
                        // wind: low-passed noise whose level rises with speed
                        if (wAmp > 0f) {
                            seed = seed * 1103515245 + 12345
                            val nz = ((seed shr 16) and 0x7fff) / 16384f - 1f
                            wn += 0.12f * (nz - wn)
                            v += wn * wAmp
                        }
                        buf[i] = (v.coerceIn(-1f, 1f) * 9000f).toInt().coerceIn(-32000, 32000).toShort()
                    }
                    try { t.write(buf, 0, buf.size) } catch (e: Exception) { break }
                }
            }.also { it.isDaemon = true; it.start() }
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        running = false
        try { thread?.join(300) } catch (e: Exception) { }
        try { track?.stop(); track?.release() } catch (e: Exception) { }
        track = null
        thread = null
    }
}

/** Optional background music: assets/audio/music.ogg. A missing file is simply ignored. */
object Music {
    private var mp: MediaPlayer? = null

    fun start(ctx: Context) {
        if (mp != null || Save.d.music <= 0) return
        try {
            val fd = ctx.assets.openFd("audio/music.ogg")
            val m = MediaPlayer()
            m.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            fd.close()
            m.isLooping = true
            m.prepare()
            val v = Save.d.music / 100f
            m.setVolume(v, v)
            m.start()
            mp = m
        } catch (e: Exception) {
            mp = null
        }
    }

    fun setVolume() {
        val v = Save.d.music / 100f
        try { mp?.setVolume(v, v) } catch (e: Exception) { }
    }

    fun stop() {
        try { mp?.stop(); mp?.release() } catch (e: Exception) { }
        mp = null
    }
}
