package com.nexusracing.game.gameplay

import com.nexusracing.game.data.BikePhys
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * The motorcycle's longitudinal + lateral dynamics for ONE bike profile. Pure Kotlin (no Android),
 * advanced with a fixed time step by RaceSim, so it is frame-rate independent and unit-testable.
 *
 * All control input arrives through step(): the touch buttons only set InputState flags, they never
 * contain physics. A new RaceSim (and therefore a new BikeDynamics) is built from the currently
 * selected bike every time a race starts, so switching bikes always switches the whole profile.
 */
class BikeDynamics(
    val phys: BikePhys,
    val perf: Upgrades.Perf
) {
    val vmax: Float = perf.topKmh / 3.6f

    var speed = 0f          // m/s
    var vx = 0f             // lateral speed, m/s (right = +)
    var steerS = 0f         // smoothed steering input -1..1
    var throttle = 0f       // smoothed throttle 0..1
    var brakeAmt = 0f       // smoothed brake pressure 0..1
    var gear = 0            // 0-based
    var rpm = phys.idleRpm  // 0..1 (display / audio)
    var leanDeg = 0f        // visual + camera lean (sign matches the old "-vx * 4")
    var pitchDeg = 0f       // visual pitch: + nose up (acceleration), - nose down (braking)
    var accelNow = 0f       // last longitudinal acceleration, m/s^2
    var slipping = false    // traction limit exceeded this step
    private var shiftTimer = 0f

    /** Fraction of top speed, 0..1.3. */
    fun speedRatio(): Float = (speed / vmax).coerceIn(0f, 1.3f)

    /**
     * @param boosting nitro is active this step (already validated by RaceSim)
     * @param steerIn  steering input -1..1 (button, wheel, joystick or tilt)
     */
    fun step(dt: Float, accelIn: Boolean, brakeIn: Boolean, boosting: Boolean, steerIn: Float) {
        val p = phys

        // ---- driver inputs, smoothed with the bike's own response rates ----
        throttle += ((if (accelIn || boosting) 1f else 0f) - throttle) * min(1f, dt * p.throttleResp)
        brakeAmt += ((if (brakeIn) 1f else 0f) - brakeAmt) * min(1f, dt * p.brakeResp)

        // ---- simulated gearbox ----
        val vr = (speed / vmax).coerceIn(0f, 1f)
        if (shiftTimer > 0f) shiftTimer -= dt
        val targetGear = min(p.gearCount - 1, (vr * p.gearCount).toInt())
        if (targetGear > gear) { gear++; shiftTimer = p.shiftTime }
        else if (targetGear < gear && vr < gear.toFloat() / p.gearCount - 0.04f) gear--

        // ---- longitudinal ----
        val cap = if (boosting) vmax * p.nitroTopMul else vmax
        val r = speed / cap
        val room = max(0.05f, 1f - r * r)
        val a: Float
        slipping = false
        if (brakeAmt > 0.01f) {
            // progressive braking: force follows pressure^curve, pressure builds at brakeResp
            a = -perf.braking * brakeAmt.pow(p.brakeCurve)
        } else {
            var drive = perf.accel * (if (boosting) p.nitroAccelMul else 1f) * room * throttle
            var lim = p.gripLimit
            if (p.launchControl && speed < 12f) lim *= 1.15f
            if (drive > lim) {
                // traction limit: traction control keeps most of the power, without it wheelspin wastes some
                drive = lim * (1f - 0.18f * (1f - p.tractionControl))
                slipping = p.tractionControl < 0.5f
            }
            if (shiftTimer > 0f) drive *= p.shiftCut
            val coast = (p.engineBrake + p.dragK * speed * speed) * (1f - throttle)
            a = drive - coast
        }
        accelNow = a
        speed = max(0f, speed + a * dt)
        if (speed > cap) speed = max(cap, speed - 12f * dt)

        // ---- lateral ----
        steerS += (steerIn.coerceIn(-1f, 1f) - steerS) * min(1f, dt * p.steerResp)
        val rr = min(1f, speed / vmax)
        val latMax = (5f + 7f * perf.handling) * min(1f, 0.25f + speed / 10f) *
            (1.15f - p.hiSpeedSteerCut * rr) * p.steerSens
        val rate = (5f + 6f * perf.handling) * (1f + p.stability * 0.8f * rr)
        vx += (steerS * latMax - vx) * min(1f, dt * rate)

        // ---- visuals driven by the physics ----
        val leanTarget = (-vx * p.leanGain * (1f - p.hiSpeedLeanCut * rr)).coerceIn(-p.maxLeanDeg, p.maxLeanDeg)
        leanDeg += (leanTarget - leanDeg) * min(1f, dt * p.leanResp)
        val pitchTarget = (a * p.pitchGain).coerceIn(-4f, 4f)
        pitchDeg += (pitchTarget - pitchDeg) * min(1f, dt * p.suspension)

        // RPM: sawtooth through each gear; a rev-up at standstill when the throttle is open
        val frac = (vr * p.gearCount - gear).coerceIn(0f, 1f)
        val fromSpeed = 0.30f + 0.70f * frac
        val target = max(p.idleRpm + 0.45f * throttle, if (speed > 0.5f) fromSpeed else 0f)
        rpm += (target - rpm) * min(1f, dt * 10f)
    }

    /** Countdown: the engine can be revved before the lights go green, the bike does not move. */
    fun idle(dt: Float, accelIn: Boolean) {
        throttle += ((if (accelIn) 1f else 0f) - throttle) * min(1f, dt * phys.throttleResp)
        rpm += (phys.idleRpm + 0.45f * throttle - rpm) * min(1f, dt * 10f)
    }

    /** Called for crashes: speed and sideways motion die, visuals relax. */
    fun relax(dt: Float) {
        steerS += (0f - steerS) * min(1f, dt * 10f)
        leanDeg += (0f - leanDeg) * min(1f, dt * 8f)
        pitchDeg += (0f - pitchDeg) * min(1f, dt * 8f)
        throttle = 0f
        brakeAmt = 0f
        rpm += (phys.idleRpm - rpm) * min(1f, dt * 6f)
    }
}
