package com.nexusracing.game.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import com.nexusracing.game.R
import com.nexusracing.game.data.*
import com.nexusracing.game.gameplay.Progression
import com.nexusracing.game.gameplay.Upgrades
import com.nexusracing.game.graphics.BikePreviewView
import com.nexusracing.game.persistence.Save
import com.nexusracing.game.ui.Ui.ACCENT
import com.nexusracing.game.ui.Ui.CYAN
import com.nexusracing.game.ui.Ui.DIM
import com.nexusracing.game.ui.Ui.GOLD
import com.nexusracing.game.ui.Ui.GREEN
import com.nexusracing.game.ui.Ui.MATCH
import com.nexusracing.game.ui.Ui.WRAP
import com.nexusracing.game.ui.Ui.bar
import com.nexusracing.game.ui.Ui.button
import com.nexusracing.game.ui.Ui.card
import com.nexusracing.game.ui.Ui.chips
import com.nexusracing.game.ui.Ui.dp
import com.nexusracing.game.ui.Ui.hbox
import com.nexusracing.game.ui.Ui.header
import com.nexusracing.game.ui.Ui.lp
import com.nexusracing.game.ui.Ui.scroll
import com.nexusracing.game.ui.Ui.text
import com.nexusracing.game.ui.Ui.toast
import com.nexusracing.game.ui.Ui.vbox

class MainMenuScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val bike = Bikes.byId(d.selected)
        val root = hbox(c)

        val left = vbox(c)
        left.addView(text(c, "NEXUS RACING", 26f, ACCENT, true))
        val prof = card(c)
        prof.addView(text(c, "RIDER  •  LEVEL ${d.level}", 16f, Ui.TEXT, true))
        val lo = Progression.xpAtLevel(d.level)
        val hi = Progression.xpAtLevel(d.level + 1)
        prof.addView(bar(c, (d.xp - lo).toFloat() / (hi - lo), CYAN), lp(MATCH, dp(c, 6), 0f, dp(c, 4)))
        prof.addView(text(c, "XP ${d.xp - lo}/${hi - lo}   •   COINS ${d.coins}", 13f, GOLD, true))
        prof.addView(text(c, "Career ${d.completed.size}/${Career.events.size} events", 13f, DIM))
        left.addView(prof, lp(MATCH, WRAP, 0f, dp(c, 4)))
        val pv = BikePreviewView(c)
        pv.setBike(bike, d.cust(bike.id))
        left.addView(pv, lp(MATCH, 0, 1f))
        left.addView(text(c, bike.name.uppercase(), 15f, DIM, true))
        left.addView(button(c, c.getString(R.string.menu_play), true) { nav.push(PlayScreen()) }, lp(MATCH, WRAP, 0f, dp(c, 4)))
        root.addView(left, lp(0, MATCH, 1f, dp(c, 4)))

        val grid = vbox(c)
        fun item(label: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(label, f)
        val items: List<Pair<String, () -> Unit>> = listOf(
            item(c.getString(R.string.menu_career)) { nav.push(CareerScreen()) },
            item(c.getString(R.string.menu_quick)) {
                nav.startRace(RaceConfig(Mode.ONE_WAY, d.env, d.night, 0, 1f, 1, 0f, Obj.DISTANCE, 2500f, title = "Quick Race"))
            },
            item(c.getString(R.string.menu_multiplayer)) { nav.push(MultiplayerScreen()) },
            item(c.getString(R.string.menu_garage)) { nav.push(GarageScreen()) },
            item(c.getString(R.string.menu_upgrades)) { nav.push(UpgradesScreen()) },
            item(c.getString(R.string.menu_custom)) { nav.push(CustomizationScreen()) },
            item(c.getString(R.string.menu_daily)) { nav.push(DailyScreen()) },
            item(c.getString(R.string.menu_missions)) { nav.push(MissionsScreen()) },
            item(c.getString(R.string.menu_settings)) { nav.push(SettingsScreen()) },
            item(c.getString(R.string.menu_stats)) { nav.push(StatsScreen()) },
            item(c.getString(R.string.menu_about)) { nav.push(AboutScreen()) }
        )
        var i = 0
        while (i < items.size) {
            val row = hbox(c)
            for (k in 0..1) {
                if (i + k < items.size) {
                    val itm = items[i + k]
                    row.addView(button(c, itm.first) { itm.second() }, lp(0, WRAP, 1f, dp(c, 4)))
                } else row.addView(View(c), lp(0, WRAP, 1f))
            }
            grid.addView(row, lp(MATCH, WRAP))
            i += 2
        }
        root.addView(scroll(c, grid), lp(0, MATCH, 1f, dp(c, 4)))
        return root
    }
}

class PlayScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val root = vbox(c)
        root.addView(header(c, "Play") { nav.pop() })
        val opts = hbox(c)
        opts.addView(text(c, "ENVIRONMENT ", 13f, DIM, true))
        opts.addView(chips(c, Envs.names, d.env) { d.env = it; Save.commit() })
        opts.addView(text(c, "  TIME ", 13f, DIM, true))
        opts.addView(chips(c, arrayOf("Day", "Night"), if (d.night) 1 else 0) { d.night = it == 1; Save.commit() })
        root.addView(opts, lp(MATCH, WRAP, 0f, dp(c, 4)))

        fun cfg(m: Mode, op: Boolean, obj: Obj, tgt: Float, lim: Float, start: Float, dens: Float) =
            RaceConfig(m, d.env, d.night, 0, dens, 1, start, obj, tgt, lim, op, title = m.label)

        fun mode(a: String, b: String, f: () -> Unit): Triple<String, String, () -> Unit> = Triple(a, b, f)
        val modes = listOf(
            mode("One Way", "Traffic flows with you. Ride 4000 m.") { nav.startRace(cfg(Mode.ONE_WAY, false, Obj.DISTANCE, 4000f, 0f, 0f, 1f)) },
            mode("Two Way", "Oncoming traffic in the left lanes. Ride 4000 m.") { nav.startRace(cfg(Mode.TWO_WAY, true, Obj.DISTANCE, 4000f, 0f, 40f, 1.2f)) },
            mode("Time Attack", "60 s on the clock, +12 s per checkpoint. Go as far as you can.") { nav.startRace(cfg(Mode.TIME_ATTACK, false, Obj.NONE, 0f, 60f, 40f, 1f)) },
            mode("Free Ride", "No finish line. Pause and end the session any time.") { nav.startRace(cfg(Mode.FREE_RIDE, false, Obj.NONE, 0f, 0f, 0f, 0.8f)) },
            mode("Escape", "Outrun the police for 90 s. Beware roadblocks.") { nav.startRace(cfg(Mode.ESCAPE, false, Obj.SURVIVE, 90f, 0f, 90f, 1f)) },
            mode("Private Race", "Choose weather, traffic, duration, difficulty and more.") { nav.push(PrivateRaceScreen()) }
        )
        val grid = vbox(c)
        var i = 0
        while (i < modes.size) {
            val row = hbox(c)
            for (k in 0..1) {
                val m = modes[i + k]
                val cd = card(c)
                cd.addView(text(c, m.first.uppercase(), 18f, Ui.TEXT, true))
                cd.addView(text(c, m.second, 13f, DIM))
                cd.addView(button(c, "Start", i + k == 0) { m.third() }, lp(MATCH, WRAP, 0f, dp(c, 3)))
                row.addView(cd, lp(0, WRAP, 1f, dp(c, 4)))
            }
            grid.addView(row, lp(MATCH, WRAP))
            i += 2
        }
        root.addView(scroll(c, grid), lp(MATCH, 0, 1f))
        return root
    }
}

class PrivateRaceScreen : Screen() {
    private var env = Save.d.env
    private var night = Save.d.night
    private var weather = 0
    private var dens = 1
    private var dur = 1
    private var diff = 1
    private var start = 0
    private var two = false

    override fun create(c: Context): View {
        val root = vbox(c)
        root.addView(header(c, "Private Race") { nav.pop() })
        val col = vbox(c)
        fun row(label: String, v: View) {
            val r = hbox(c); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(text(c, label, 13f, DIM, true), lp(dp(c, 110), WRAP))
            r.addView(v, lp(0, WRAP, 1f))
            col.addView(r, lp(MATCH, WRAP, 0f, dp(c, 2)))
        }
        row("ENVIRONMENT", chips(c, Envs.names, env) { env = it })
        row("TIME OF DAY", chips(c, arrayOf("Day", "Night"), if (night) 1 else 0) { night = it == 1 })
        row("WEATHER", chips(c, Envs.weather, weather) { weather = it })
        row("TRAFFIC", chips(c, arrayOf("Light", "Normal", "Heavy", "Extreme"), dens) { dens = it })
        row("DIRECTION", chips(c, arrayOf("One way", "Two way"), if (two) 1 else 0) { two = it == 1 })
        row("DURATION", chips(c, arrayOf("Free", "60 s", "120 s", "300 s"), dur) { dur = it })
        row("DIFFICULTY", chips(c, arrayOf("Easy", "Normal", "Hard"), diff) { diff = it })
        row("START SPEED", chips(c, arrayOf("0", "60", "100", "140 km/h"), start) { start = it })
        col.addView(button(c, "Start race", true) {
            val durs = floatArrayOf(0f, 60f, 120f, 300f)
            val dn = floatArrayOf(0.5f, 1f, 1.6f, 2.2f)
            val sp = floatArrayOf(0f, 60f, 100f, 140f)
            nav.startRace(
                RaceConfig(
                    Mode.PRIVATE, env, night, weather, dn[dens], diff, sp[start],
                    if (dur == 0) Obj.NONE else Obj.SURVIVE, durs[dur], 0f, two, title = "Private Race"
                )
            )
        }, lp(MATCH, WRAP, 0f, dp(c, 6)))
        root.addView(scroll(c, col), lp(MATCH, 0, 1f))
        return root
    }
}

class CareerScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val root = vbox(c)
        root.addView(header(c, "Career  ${d.completed.size}/${Career.events.size}") { nav.pop() })
        val list = vbox(c)
        var prevDone = true
        for ((i, ev) in Career.events.withIndex()) {
            val done = d.completed.contains(ev.id)
            val open = prevDone
            val cd = card(c)
            val row = hbox(c); row.gravity = Gravity.CENTER_VERTICAL
            val info = vbox(c)
            info.addView(text(c, "${i + 1}. ${ev.title.uppercase()}" + if (done) "  ✓" else "", 17f, if (done) GREEN else Ui.TEXT, true))
            info.addView(text(c, ev.desc + "  [" + ev.config.objectiveLabel() + "]", 13f, DIM))
            info.addView(text(c, "${Envs.all[ev.config.env].name} • ${if (ev.config.night) "Night" else "Day"} • Reward ${ev.rewardCoins} coins, ${ev.rewardXp} XP", 12f, GOLD))
            row.addView(info, lp(0, WRAP, 1f))
            row.addView(button(c, if (!open) "Locked" else if (done) "Replay" else "Start", open && !done, open) {
                if (open) nav.startRace(ev.config) else toast(c, "Complete the previous event first")
            }, lp(dp(c, 110), WRAP))
            cd.addView(row)
            list.addView(cd, lp(MATCH, WRAP, 0f, dp(c, 3)))
            prevDone = done
        }
        root.addView(scroll(c, list), lp(MATCH, 0, 1f))
        return root
    }
}

class GarageScreen : Screen() {
    private var viewId = Save.d.selected

    override fun create(c: Context): View {
        val d = Save.d
        val b = Bikes.byId(viewId)
        val owned = d.unlocked.contains(b.id)
        val root = hbox(c)

        val left = vbox(c)
        val pv = BikePreviewView(c)
        pv.setBike(b, d.cust(b.id))
        left.addView(pv, lp(MATCH, 0, 1f))
        left.addView(text(c, b.name.uppercase(), 22f, Ui.TEXT, true))
        root.addView(left, lp(0, MATCH, 1f, dp(c, 4)))

        val right = vbox(c)
        right.addView(header(c, "Garage") { nav.pop() })
        val idx = Bikes.all.indexOfFirst { it.id == b.id }.coerceAtLeast(0)
        right.addView(chips(c, Bikes.all.map { it.name }.toTypedArray(), idx) { i -> viewId = Bikes.all[i].id; nav.refresh() })
        val p = Upgrades.perfFor(b)
        val st = vbox(c)
        fun stat(label: String, v: String, f: Float) {
            val r = hbox(c); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(text(c, label, 13f, DIM, true), lp(dp(c, 90), WRAP))
            r.addView(bar(c, f), lp(0, dp(c, 8), 1f, dp(c, 4)))
            r.addView(text(c, v, 13f, Ui.TEXT, true), lp(dp(c, 80), WRAP))
            st.addView(r, lp(MATCH, WRAP, 0f, dp(c, 2)))
        }
        stat("TOP SPEED", "${p.topKmh.toInt()} km/h", p.topKmh / 430f)
        stat("ACCEL", "%.1f m/s²".format(p.accel), p.accel / 24f)
        stat("HANDLING", "%.2f".format(p.handling), p.handling / 1.2f)
        stat("BRAKING", "%.1f m/s²".format(p.braking), p.braking / 36f)
        val sc = card(c)
        sc.addView(st)
        right.addView(sc, lp(MATCH, WRAP, 0f, dp(c, 6)))
        if (b.klass.isNotEmpty()) right.addView(text(c, "CLASS  ${b.klass.uppercase()}", 13f, Ui.CYAN, true))
        val ownerGranted = d.ownerGranted.contains(b.id)
        right.addView(text(c, if (owned) (if (ownerGranted) "OWNED (owner unlock)" else "OWNED") else "Price ${com.nexusracing.game.gameplay.Shop.fmt(b.price)} coins • unlocks at level ${b.unlockLevel}", 14f, if (owned) GREEN else GOLD, true))

        val selected = d.selected == b.id
        val label = when {
            owned && selected -> "Selected"
            owned -> "Select"
            d.level < b.unlockLevel -> "Locked – level ${b.unlockLevel}"
            else -> "Buy – ${com.nexusracing.game.gameplay.Shop.fmt(b.price)}"
        }
        right.addView(button(c, label, !selected, !(owned && selected) && !(!owned && d.level < b.unlockLevel)) {
            if (owned) { d.selected = b.id; Save.commit(); nav.refresh() }
            else {
                // single, guarded purchase path: checks ownership, level and balance; deducts once
                val res = com.nexusracing.game.gameplay.Shop.purchase(b)
                toast(c, res.message)
                if (res.ok) nav.refresh()
            }
        }, lp(MATCH, WRAP, 0f, dp(c, 6)))
        root.addView(right, lp(0, MATCH, 1f, dp(c, 4)))
        return root
    }
}

class UpgradesScreen : Screen() {
    override fun create(c: Context): View {
        val b = Bikes.byId(Save.d.selected)
        val root = vbox(c)
        root.addView(header(c, "Upgrades – ${b.name}") { nav.pop() })
        val list = vbox(c)
        val now = Upgrades.perfFor(b)
        for (cat in 0..4) {
            val lv = Upgrades.level(b.id, cat)
            val max = lv >= Upgrades.MAX
            val nxt = Upgrades.perfFor(b, cat)
            val cd = card(c)
            val row = hbox(c); row.gravity = Gravity.CENTER_VERTICAL
            val info = vbox(c)
            info.addView(text(c, "${Upgrades.names[cat].uppercase()}   LV $lv/${Upgrades.MAX}", 16f, Ui.TEXT, true))
            info.addView(text(c, Upgrades.descs[cat], 12f, DIM))
            val unit = Upgrades.units[cat]
            info.addView(text(c, "%.2f → %.2f %s".format(now.of(cat), if (max) now.of(cat) else nxt.of(cat), unit), 13f, CYAN, true))
            info.addView(bar(c, lv / Upgrades.MAX.toFloat(), GREEN), lp(MATCH, dp(c, 6), 0f, dp(c, 3)))
            row.addView(info, lp(0, WRAP, 1f))
            val cost = Upgrades.cost(lv, cat)
            row.addView(button(c, if (max) "Maxed" else "Buy $cost", !max, !max) {
                val err = Upgrades.buy(b, cat)
                if (err != null) toast(c, err) else nav.refresh()
            }, lp(dp(c, 120), WRAP))
            cd.addView(row)
            list.addView(cd, lp(MATCH, WRAP, 0f, dp(c, 3)))
        }
        root.addView(scroll(c, list), lp(MATCH, 0, 1f))
        return root
    }
}

class CustomizationScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val b = Bikes.byId(d.selected)
        val cu = d.cust(b.id)
        val root = hbox(c)
        val left = vbox(c)
        val pv = BikePreviewView(c)
        pv.setBike(b, cu)
        left.addView(pv, lp(MATCH, 0, 1f))
        left.addView(text(c, b.name.uppercase(), 20f, Ui.TEXT, true))
        root.addView(left, lp(0, MATCH, 1f, dp(c, 4)))

        val right = vbox(c)
        right.addView(header(c, "Customization") { nav.pop() })
        val col = vbox(c)
        fun apply() { d.setCust(b.id, cu); Save.commit(); pv.setBike(b, cu) }
        col.addView(text(c, "PAINT", 13f, DIM, true))
        col.addView(Ui.swatches(c, Palette.paints, cu.paint) { cu.paint = it; apply() })
        col.addView(text(c, "WHEELS / RIMS", 13f, DIM, true))
        col.addView(Ui.swatches(c, Palette.rims, cu.rim) { cu.rim = it; apply() })
        col.addView(text(c, "DECALS", 13f, DIM, true))
        col.addView(chips(c, Palette.decals, cu.decal) { cu.decal = it; apply() })
        col.addView(text(c, "ACCESSORIES", 13f, DIM, true))
        col.addView(chips(c, Palette.accessories, cu.acc) { cu.acc = it; apply() })
        col.addView(text(c, "Changes apply to the selected bike and are saved instantly.", 12f, DIM))
        right.addView(scroll(c, col), lp(MATCH, 0, 1f))
        root.addView(right, lp(0, MATCH, 1f, dp(c, 4)))
        return root
    }
}
