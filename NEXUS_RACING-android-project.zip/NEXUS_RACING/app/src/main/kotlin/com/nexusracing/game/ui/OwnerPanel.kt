package com.nexusracing.game.ui

import android.app.Activity
import android.app.AlertDialog
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import com.nexusracing.game.owner.OwnerAccess
import com.nexusracing.game.persistence.Save

/** Small PIN dialog for the development Owner Panel. The PIN is never shown, logged or pre-filled. */
object OwnerPanel {
    fun show(activity: Activity, onChanged: () -> Unit) {
        val input = EditText(activity)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.filters = arrayOf(InputFilter.LengthFilter(12))
        input.hint = "PIN"
        val msg = if (Save.d.ownerUnlocked) "Owner access is active. Enter the PIN to unlock bikes added since."
        else "Enter the owner PIN to unlock every bike for testing."
        AlertDialog.Builder(activity)
            .setTitle("Owner Panel")
            .setMessage(msg)
            .setView(input)
            .setPositiveButton("Verify") { _, _ ->
                when (OwnerAccess.verify(input.text.toString())) {
                    OwnerAccess.Result.OK -> {
                        val n = OwnerAccess.grantAll()
                        Ui.toast(activity, if (n > 0) "Owner verified: $n bike(s) unlocked" else "Owner verified: all bikes already unlocked")
                        onChanged()
                    }
                    OwnerAccess.Result.WRONG -> Ui.toast(activity, "Incorrect PIN")
                    OwnerAccess.Result.LOCKED -> Ui.toast(activity, "Too many attempts. Try again in ${OwnerAccess.lockedSeconds()} s")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
