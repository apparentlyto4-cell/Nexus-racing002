package com.nexusracing.game.graphics

import android.opengl.GLES20
import android.opengl.Matrix
import com.nexusracing.game.data.*
import com.nexusracing.game.gameplay.RaceSim
import com.nexusracing.game.gameplay.VType
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the whole 3D world for one frame: sky, road, markings, scenery for the four environments,
 * traffic, coins, the player bike, weather. World z = -distance. All sizes depend on GfxPreset.
 */
class SceneDrawer(
    private val kit: GlKit, private val models: Models,
    private val cfg: RaceConfig, private val gfx: GfxPreset
) {
    private val env = Envs.all[cfg.env.coerceIn(0, Envs.all.size - 1)]
    private val night = cfg.night
    private val sky: Int                 // horizon colour (also the fog colour, so distance dissolves into the sky)
    private val skyTop: Int
    private val sunCol: Int
    private val cloudCol: Int
    private val cloudCover: Float
    private val skyKit = SkyKit()
    private val fogBase: Float
    private var fogK = 0f
    private val roadShadow: Int
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val ident = FloatArray(16)
    private val base = FloatArray(16)

    private val cityCols = intArrayOf(0xFF6F7A8C.toInt(), 0xFF8C8F96.toInt(), 0xFF5B6B80.toInt(), 0xFF9A8F86.toInt())
    private val CH = 24f

    init {
        var hz = mixColor(env.sky, 0xFFFFFFFF.toInt(), 0.35f)                 // bright, hazy horizon
        var top = mixColor(env.sky, 0xFF2A62C8.toInt(), 0.6f)                  // deeper blue overhead
        var cloud = 0xFFFFFFFF.toInt()
        var cover = if (gfx.details) 0.55f else 0f                             // clouds only on MEDIUM / HIGH
        when (cfg.weather) {
            1 -> { hz = mixColor(hz, 0xFF6A7480.toInt(), 0.7f); top = mixColor(top, 0xFF4B5461.toInt(), 0.75f); cloud = 0xFF8A929C.toInt(); if (gfx.details) cover = 0.9f }
            2 -> { hz = mixColor(hz, 0xFFC9D1DA.toInt(), 0.65f); top = mixColor(top, 0xFF9AA6B3.toInt(), 0.7f); cloud = 0xFFDDE3EA.toInt(); if (gfx.details) cover = 0.85f }
            3 -> { hz = mixColor(hz, 0xFFB9BFC5.toInt(), 0.9f); top = mixColor(top, 0xFFB0B7BE.toInt(), 0.85f); cover = 0f }
        }
        if (night) { hz = mixColor(hz, 0xFF0C1630.toInt(), 0.93f); top = 0xFF02040C.toInt(); cloud = 0xFF1B2540.toInt() }
        sky = hz; skyTop = top; cloudCol = cloud; cloudCover = cover
        sunCol = if (night) 0xFFBFD0FF.toInt() else if (cfg.weather == 0) 0xFFFFE9A8.toInt() else 0xFF8C8A80.toInt()
        fogBase = 1.9f / gfx.viewDist * when (cfg.weather) { 1 -> 1.4f; 2 -> 1.6f; 3 -> 2.6f; else -> 1f }
        fogK = fogBase
        skyKit.init()
        roadShadow = shadeColor(env.road, 0.5f)
        Matrix.setIdentityM(ident, 0)
    }

    private fun b(px: Float, py: Float, pz: Float, sx: Float, sy: Float, sz: Float, col: Int, lit: Boolean = true) =
        kit.draw(kit.cube, ident, px, py, pz, 0f, 0f, 0f, sx, sy, sz, col, lit)

    private fun hash(a: Int): Int {
        var x = a * -1640531535
        x = x xor (x ushr 16)
        x *= 0x45d9f3b
        x = x xor (x ushr 16)
        return x and 0x7fffffff
    }

    fun render(
        sim: RaceSim, spec: BikeSpec, cust: Cust, eye: FloatArray, look: FloatArray,
        fov: Float, aspect: Float, t: Float, camMode: Int, debug: Boolean, rollDeg: Float = 0f
    ) {
        val vd = sim.viewDistEff
        fogK = fogBase * gfx.viewDist / vd      // the view range stretches with speed, fog follows it
        val rr = Math.toRadians(rollDeg.toDouble())
        val upX = sin(rr).toFloat()
        val upY = kotlin.math.cos(rr).toFloat()
        GLES20.glClearColor(((sky shr 16) and 255) / 255f, ((sky shr 8) and 255) / 255f, (sky and 255) / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        skyKit.draw(eye, look, upX, upY, fov, aspect, t, skyTop, sky, sunCol, cloudCol, cloudCover, night)
        Matrix.perspectiveM(proj, 0, fov, aspect, 0.5f, vd + 80f)
        Matrix.setLookAtM(view, 0, eye[0], eye[1], eye[2], look[0], look[1], look[2], upX, upY, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        val inten = (if (night) 0.42f else 1f) * (if (cfg.weather == 1 || cfg.weather == 3) 0.85f else 1f)
        val fr = ((sky shr 16) and 255) / 255f
        val fg = ((sky shr 8) and 255) / 255f
        val fb = (sky and 255) / 255f
        if (night) kit.begin(vp, -0.3f, 1f, 0.3f, 0.5f, inten, fr, fg, fb, fogK)
        else kit.begin(vp, 0.45f, 1f, 0.55f, 0.55f, inten, fr, fg, fb, fogK)
        kit.setEye(eye[0], eye[1], eye[2])

        val dist = sim.dist
        val pz = -dist
        drawBackdrop(eye, vd)
        drawRoad(dist, pz, vd)
        drawScenery(dist, vd)
        drawLights(dist, vd)
        // coins
        for (c in sim.coinPool) {
            if (!c.active) continue
            kit.draw(kit.cyl, ident, c.x, 0.9f, -c.z, 0f, t * 200f, 90f, 0.7f, 0.12f, 0.7f, 0xFFFFC542.toInt(), false)
        }
        // traffic
        for (v in sim.vehicles) {
            if (!v.active) continue
            if (gfx.blobShadows) b(v.x, 0.02f, -v.z, 2f * v.halfW + 0.5f, 0.02f, 2f * v.halfL + 0.4f, roadShadow)
            Matrix.setIdentityM(base, 0)
            Matrix.translateM(base, 0, v.x, 0f, -v.z)
            if (v.oncoming) Matrix.rotateM(base, 0, 180f, 0f, 1f, 0f)
            models.vehicle(base, v.type, v.color, t)
        }
        // police chase car (Escape mode)
        if (cfg.mode == Mode.ESCAPE && sim.policeGap < 120f) {
            val pzz = -(dist - sim.policeGap)
            if (gfx.blobShadows) b(sim.x, 0.02f, pzz, 2.3f, 0.02f, 4.6f, roadShadow)
            Matrix.setIdentityM(base, 0)
            Matrix.translateM(base, 0, sim.x, 0f, pzz)
            models.vehicle(base, VType.POLICE, 0, t)
        }
        // player bike: yaw into the turn; smoothed lean and suspension pitch come from the bike's physics profile
        if (gfx.blobShadows) b(sim.x, 0.02f, pz, 0.9f, 0.02f, spec.wheelBase + 0.9f, roadShadow)
        Matrix.setIdentityM(base, 0)
        Matrix.translateM(base, 0, sim.x, 0f, pz)
        Matrix.rotateM(base, 0, -sim.vx * 1.2f, 0f, 1f, 0f)
        if (sim.pitchDeg != 0f) Matrix.rotateM(base, 0, sim.pitchDeg, 1f, 0f, 0f)
        Matrix.rotateM(base, 0, sim.leanDeg, 0f, 0f, 1f)
        models.bike(base, spec, cust, sim.wheelDeg, camMode != 2, sim.braking)
        kit.useProgram()
        drawWeather(eye, t)
        if (debug) drawDebug(sim)
    }

    fun release() { skyKit.release() }

    /** Distant mountains / skyline that follow the camera, partly fogged so they read as far away. */
    private fun drawBackdrop(eye: FloatArray, vd: Float) {
        val far = vd * 0.92f
        kit.setFog(fogK * 0.3f)
        val count = if (gfx.details) 10 else 6
        for (i in 0 until count) {
            val h = hash(i * 7919 + env.kind * 131 + 5)
            val r1 = (h and 255) / 255f
            val r2 = ((h shr 8) and 255) / 255f
            val x = -(count - 1) * 55f + i * 110f + (r1 - 0.5f) * 40f + eye[0] * 0.05f
            val z = eye[2] - far - r2 * 30f
            when (env.kind) {
                0 -> {   // city skyline
                    val w = 40f + r1 * 40f
                    val hh = 30f + r2 * 70f
                    b(x, hh / 2f, z, w, hh, 30f, mixColor(0xFF4A5568.toInt(), sky, if (night) 0.1f else 0.3f), false)
                }
                1 -> {   // desert mesas
                    val w = 110f + r1 * 90f
                    val hh = 28f + r2 * 40f
                    b(x, hh / 2f, z, w, hh, 60f, mixColor(0xFF9C6B45.toInt(), sky, 0.35f), false)
                }
                else -> {   // hills / snowy peaks
                    val w = 140f + r1 * 120f
                    val hh = 45f + r2 * 70f
                    val c = if (env.kind == 3) mixColor(0xFFDDE6EE.toInt(), sky, 0.25f) else mixColor(0xFF3F6B45.toInt(), sky, 0.4f)
                    kit.draw(kit.cone, ident, x, hh / 2f, z, 0f, 0f, 0f, w, hh, w * 0.6f, if (night) shadeColor(c, 0.35f) else c, false)
                }
            }
        }
        kit.setFog(fogK)
    }

    private fun drawRoad(dist: Float, pz: Float, vd: Float) {
        val len = vd + 120f
        val cz = pz - (vd + 20f) / 2f
        val half = RaceSim.ROAD_HALF
        b(0f, -0.35f, cz, 400f, 0.5f, len, env.ground)
        b(0f, -0.1f, cz, half * 2f, 0.2f, len, env.road)
        val white = 0xFFE8E8E8.toInt()
        // darker wheel tracks in every lane: cheap surface detail and a strong perspective cue
        if (gfx.details) {
            val track = shadeColor(env.road, 0.8f)
            for (l in 0..3) {
                val lx = RaceSim.laneX(l)
                b(lx - 0.6f, 0.006f, cz, 0.5f, 0.012f, len, track)
                b(lx + 0.6f, 0.006f, cz, 0.5f, 0.012f, len, track)
            }
        }
        b(half - 0.45f, 0.012f, cz, 0.18f, 0.02f, len, white)
        b(-(half - 0.45f), 0.012f, cz, 0.18f, 0.02f, len, white)
        val rail = if (env.kind == 3) 0xFFC9D2DA.toInt() else 0xFF9AA3AD.toInt()
        b(half + 0.35f, 0.35f, cz, 0.18f, 0.7f, len, rail)
        b(-(half + 0.35f), 0.35f, cz, 0.18f, 0.7f, len, rail)
        val lw = RaceSim.LANE_W
        if (cfg.opposing) {
            b(0.12f, 0.012f, cz, 0.1f, 0.02f, len, 0xFFE0B000.toInt())
            b(-0.12f, 0.012f, cz, 0.1f, 0.02f, len, 0xFFE0B000.toInt())
        }
        val near = min(vd, 160f)
        val i0 = floor((dist - 30f) / 12f).toInt()
        val i1 = floor((dist + near) / 12f).toInt()
        for (i in i0..i1) {
            val z = -(i * 12f + 2f)
            b(-lw, 0.012f, z, 0.15f, 0.02f, 4f, white)
            b(lw, 0.012f, z, 0.15f, 0.02f, 4f, white)
            if (!cfg.opposing) b(0f, 0.012f, z, 0.15f, 0.02f, 4f, white)
        }
        if (gfx.details) {
            // red/white rumble kerbs on both road edges (a red base strip with white blocks every 6 m)
            val kx = half - 0.1f
            val red = 0xFFC62828.toInt()
            val kLen = near + 40f
            val kz = pz - (near - 30f) / 2f
            b(kx, 0.01f, kz, 0.3f, 0.02f, kLen, red)
            b(-kx, 0.01f, kz, 0.3f, 0.02f, kLen, red)
            val k0 = floor((dist - 30f) / 6f).toInt()
            val k1 = floor((dist + near) / 6f).toInt()
            for (i in k0..k1) {
                val z = -(i * 6f + 1.5f)
                b(kx, 0.016f, z, 0.3f, 0.02f, 3f, white)
                b(-kx, 0.016f, z, 0.3f, 0.02f, 3f, white)
            }
            // guardrail posts
            val p0 = floor((dist - 30f) / 8f).toInt()
            val p1 = floor((dist + near * 0.75f) / 8f).toInt()
            for (i in p0..p1) {
                val z = -(i * 8f)
                b(half + 0.35f, 0.3f, z, 0.12f, 0.6f, 0.12f, 0xFF6A727B.toInt())
                b(-(half + 0.35f), 0.3f, z, 0.12f, 0.6f, 0.12f, 0xFF6A727B.toInt())
            }
        }
    }

    private fun drawScenery(dist: Float, vd: Float) {
        val c0 = floor((dist - 40f) / CH).toInt()
        val c1 = floor((dist + vd) / CH).toInt()
        val half = RaceSim.ROAD_HALF
        for (c in c0..c1) for (side in 0..1) {
            val sd = if (side == 0) -1f else 1f
            for (n in 0 until gfx.scenery) {
                val h = hash(c * 977 + n * 131 + side * 7919 + env.kind * 104729)
                val r1 = (h and 255) / 255f
                val r2 = ((h shr 8) and 255) / 255f
                val r3 = ((h shr 16) and 255) / 255f
                val z = -(c * CH + (n + r1) * CH / gfx.scenery)
                when (env.kind) {
                    0 -> {   // city buildings
                        val w = 7f + r2 * 6f
                        val dd = 9f + r1 * 6f
                        val hh = 12f + r3 * 34f
                        val x = sd * (half + 3.5f + w / 2f + r2 * 3f)
                        b(x, hh / 2f, z, w, hh, dd, cityCols[(h shr 24) and 3])
                        if (gfx.details) {
                            val wc = if (night) 0xFFFFD27A.toInt() else 0xFF3A5068.toInt()
                            b(x - sd * (w / 2f + 0.03f), hh * 0.5f, z, 0.06f, hh * 0.8f, dd * 0.8f, wc, false)
                        }
                    }
                    1 -> {   // desert: rocks and cacti
                        val x = sd * (half + 4f + r2 * 22f)
                        if (r3 < 0.55f) {
                            kit.draw(kit.cube, ident, x, 0.5f + r3, z, 0f, r1 * 90f, 0f, 2f + r2 * 3f, 1f + r3 * 2.2f, 2f + r1 * 3f, 0xFFA9744F.toInt(), true)
                        } else {
                            val th = 3f + r3 * 2f
                            b(x, th / 2f, z, 0.5f, th, 0.5f, 0xFF3E7B3A.toInt())
                            b(x + 0.55f, th * 0.65f, z, 0.9f, 0.35f, 0.35f, 0xFF3E7B3A.toInt())
                        }
                    }
                    2 -> {   // village: trees and houses
                        val x = sd * (half + 6f + r2 * 16f)
                        if (r3 < 0.5f) {
                            kit.draw(kit.cyl, ident, x, 1.1f, z, 0f, 0f, 0f, 0.4f, 2.2f, 0.4f, 0xFF5D4037.toInt(), true)
                            kit.draw(kit.cone, ident, x, 4.6f, z, 0f, 0f, 0f, 3f + r2 * 1.5f, 4f + r1 * 2f, 3f + r2 * 1.5f, 0xFF2F7D32.toInt(), true)
                        } else {
                            b(x, 1.8f, z, 5f, 3.6f, 6f, 0xFFEBDFC8.toInt())
                            kit.draw(kit.cube, ident, x, 2.8f, z, 0f, 0f, 45f, 3.7f, 3.7f, 6.4f, 0xFFA33B2B.toInt(), true)
                        }
                    }
                    else -> {   // winter pines with snow caps
                        val x = sd * (half + 5f + r2 * 18f)
                        val ph = 5f + r3 * 3f
                        kit.draw(kit.cyl, ident, x, 1f, z, 0f, 0f, 0f, 0.4f, 2f, 0.4f, 0xFF4E342E.toInt(), true)
                        kit.draw(kit.cone, ident, x, 2f + ph / 2f, z, 0f, 0f, 0f, 2.8f + r2 * 1.4f, ph, 2.8f + r2 * 1.4f, 0xFF1E5A3A.toInt(), true)
                        kit.draw(kit.cone, ident, x, 2f + ph * 0.85f, z, 0f, 0f, 0f, 1.5f, ph * 0.35f, 1.5f, 0xFFF4F8FB.toInt(), true)
                    }
                }
            }
        }
    }

    private fun drawLights(dist: Float, vd: Float) {
        if (!gfx.details || !(night || env.kind == 0)) return
        val half = RaceSim.ROAD_HALF
        val bulb = if (night) 0xFFFFF0B0.toInt() else 0xFFD8D8D0.toInt()
        val i0 = floor((dist - 40f) / 36f).toInt()
        val i1 = floor((dist + vd) / 36f).toInt()
        for (i in i0..i1) {
            val z = -(i * 36f)
            for (side in 0..1) {
                val sd = if (side == 0) -1f else 1f
                b(sd * (half + 0.8f), 3.5f, z, 0.18f, 7f, 0.18f, 0xFF50565E.toInt())
                b(sd * (half - 0.2f), 7f, z, 2f, 0.15f, 0.15f, 0xFF50565E.toInt())
                b(sd * (half - 1.1f), 6.85f, z, 0.5f, 0.15f, 0.5f, bulb, false)
            }
        }
    }

    /** Rain / snow particles anchored to the world so they streak past at speed. */
    private fun drawWeather(eye: FloatArray, t: Float) {
        val n = gfx.particles
        if (n == 0 || cfg.weather == 0 || cfg.weather == 3) return
        val rain = cfg.weather == 1
        val hgt = if (rain) 14f else 10f
        val fall = if (rain) 26f else 2.5f
        for (i in 0 until n) {
            val h = hash(i * 7919 + 13)
            val fx = (h and 1023) / 1023f
            val fz = ((h shr 10) and 1023) / 1023f
            val ph = ((h shr 20) and 511) / 511f
            val a = eye[2] - 3f - fz * 40f
            val zc = eye[2] - 3f - (((a % 40f) + 40f) % 40f)
            val y = hgt - ((t * fall + ph * hgt) % hgt)
            val x = eye[0] + (fx - 0.5f) * 36f
            if (rain) b(x, y, zc, 0.02f, 0.55f, 0.02f, 0xFFB8D0E8.toInt(), false)
            else b(x + sin(t * 1.3f + ph * 6.28f) * 0.6f, y, zc, 0.09f, 0.09f, 0.09f, 0xFFFFFFFF.toInt(), false)
        }
    }

    private fun box2d(cx: Float, cz: Float, hw: Float, hl: Float, col: Int) {
        b(cx - hw, 0.08f, cz, 0.06f, 0.06f, hl * 2f, col, false)
        b(cx + hw, 0.08f, cz, 0.06f, 0.06f, hl * 2f, col, false)
        b(cx, 0.08f, cz - hl, hw * 2f, 0.06f, 0.06f, col, false)
        b(cx, 0.08f, cz + hl, hw * 2f, 0.06f, 0.06f, col, false)
    }

    /** Debug option: footprints of the collision boxes (green traffic, red/yellow player). */
    private fun drawDebug(sim: RaceSim) {
        for (v in sim.vehicles) if (v.active) box2d(v.x, -v.z, v.halfW + 0.32f, v.halfL + 0.95f, 0xFF00FF66.toInt())
        box2d(sim.x, -sim.dist, 0.32f, 0.95f, if (sim.collisionFlash > 0f) 0xFFFF2020.toInt() else 0xFFFFE000.toInt())
    }
}
