package com.nexusracing.game

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.nexusracing.game.audio.EngineSynth
import com.nexusracing.game.audio.Sound
import com.nexusracing.game.camera.CameraRig
import com.nexusracing.game.controls.GameView
import com.nexusracing.game.controls.TiltSensor
import com.nexusracing.game.data.*
import com.nexusracing.game.gameplay.*
import com.nexusracing.game.graphics.RaceRenderer
import com.nexusracing.game.persistence.Save
import com.nexusracing.game.ui.Immersive
import com.nexusracing.game.ui.Ui
import com.nexusracing.game.ui.Ui.MATCH
import com.nexusracing.game.ui.Ui.WRAP
import kotlin.math.abs

/**
 * The race screen: GLSurfaceView (3D) + GameView (HUD and touch controls) + overlay (pause/results).
 * Lifecycle: onPause pauses the sim, stops the sensor, the engine sound and the GL thread.
 */
class GameActivity : Activity() {
    companion object { const val EXTRA_CFG = "cfg" }

    private lateinit var cfg: RaceConfig
    private lateinit var bike: BikeSpec
    private lateinit var gfx: GfxPreset
    private lateinit var sim: RaceSim
    private lateinit var renderer: RaceRenderer
    private lateinit var glView: GLSurfaceView
    private lateinit var hud: GameView
    private lateinit var overlay: FrameLayout
    private val input = InputState()
    private val engine = EngineSynth()
    private var tilt: TiltSensor? = null
    private var granted = false
    private var camMode = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Immersive.apply(this, true)
        val json = intent.getStringExtra(EXTRA_CFG)
        if (json == null) { finish(); return }
        try { cfg = RaceConfig.fromJson(json) } catch (e: Exception) { finish(); return }
        val d = Save.d
        bike = Bikes.byId(d.selected)
        gfx = Gfx.current()
        camMode = d.camera.coerceIn(0, 3)
        sim = newSim()

        renderer = RaceRenderer(sim, cfg, gfx, input)
        renderer.cameraMode = camMode
        renderer.fpsCap = d.fps
        renderer.debug = d.debug

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(3)
        glView.setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        // tilt falls back to buttons when the device has no accelerometer
        var scheme = d.scheme
        val ts = TiltSensor(this) { v ->
            val s = ((v - d.tiltNeutral) / 0.45f) * (if (d.tiltReverse) -1f else 1f) * (d.sens / 100f)
            input.steer = if (abs(s) < 0.04f) 0f else s.coerceIn(-1f, 1f)
        }
        if (scheme == 3) { if (ts.available) tilt = ts else scheme = 0 }

        hud = GameView(this, input)
        hud.scheme = scheme
        hud.sensitivity = d.sens / 100f
        hud.gfx = gfx
        hud.debug = d.debug
        hud.sim = sim
        hud.fpsProvider = { renderer.fps }
        hud.camName = { CameraRig.NAMES[camMode] }
        hud.onPause = { showPause() }
        hud.onCamera = { camMode = (camMode + 1) % 4; renderer.cameraMode = camMode; d.camera = camMode; Save.commit() }
        hud.onHaptic = { vibrate() }
        hud.onEngine = { r, t, wd -> engine.rpm = r; engine.throttle = t; engine.wind = wd }
        // engine character comes from the selected bike's profile
        engine.hzIdle = bike.phys.engineHzIdle
        engine.hzSpan = bike.phys.engineHzSpan
        engine.whine = bike.phys.whine
        // start loading the bike's 3D model in the background (no-op for procedural bikes / when already cached)
        bike.modelPath?.let { com.nexusracing.game.graphics.GlbAssets.preload(this, it) }

        overlay = FrameLayout(this)
        overlay.visibility = View.GONE
        overlay.setBackgroundColor(0xCC05070B.toInt())
        overlay.isClickable = true

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        root.addView(glView, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(hud, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        // resolution scale comes from the graphics preset (LOW renders fewer pixels)
        root.post {
            if (gfx.renderScale < 1f && root.width > 0) {
                glView.holder.setFixedSize((root.width * gfx.renderScale).toInt(), (root.height * gfx.renderScale).toInt())
            }
        }
    }

    private fun newSim(): RaceSim {
        val s = RaceSim(cfg, bike, gfx)
        s.onEnd = { res -> runOnUiThread { if (!isFinishing) showResults(res) } }
        return s
    }

    private fun vibrate() {
        if (!Save.d.vibration) return
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        Immersive.apply(this, true)
        if (!::glView.isInitialized) return
        glView.onResume()
        tilt?.start()
        if (overlay.visibility != View.VISIBLE) engine.start()
    }

    override fun onPause() {
        if (::glView.isInitialized) {
            if (sim.state != RaceSim.State.ENDED && overlay.visibility != View.VISIBLE) showPause()
            tilt?.stop()
            engine.stop()
            hud.releaseAll()
            glView.onPause()
        }
        super.onPause()
    }

    override fun onDestroy() {
        if (::glView.isInitialized) {
            engine.stop()
            glView.queueEvent { renderer.releaseGpu() }     // free GLB buffers / textures / sky shader
        }
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Immersive.apply(this, true)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay.visibility == View.VISIBLE) { if (sim.state != RaceSim.State.ENDED) resume() else exit() } else showPause()
    }

    // ------------------------------------------------------------------ overlays
    private fun panel(title: String, tc: Int): LinearLayout {
        overlay.removeAllViews()
        val card = Ui.card(this)
        card.addView(Ui.text(this, title, 26f, tc, true))
        val sv = Ui.scroll(this, card)
        overlay.addView(sv, FrameLayout.LayoutParams(Ui.dp(this, 420), WRAP, Gravity.CENTER))
        overlay.visibility = View.VISIBLE
        return card
    }

    private fun showPause() {
        if (sim.state == RaceSim.State.ENDED) return
        renderer.paused = true
        engine.stop()
        hud.releaseAll()
        val c = panel("PAUSED", Ui.TEXT)
        c.addView(Ui.button(this, "Resume", true) { resume() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
        c.addView(Ui.button(this, "Restart") { restart() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
        if (cfg.mode == Mode.FREE_RIDE) c.addView(Ui.button(this, "End session") { resume(); sim.endSession() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
        c.addView(Ui.text(this, "SOUND", 12f, Ui.DIM, true))
        c.addView(Ui.slider(this, 0, 100, Save.d.sfx) { Save.d.sfx = it })
        c.addView(Ui.text(this, "CAMERA", 12f, Ui.DIM, true))
        c.addView(Ui.chips(this, CameraRig.NAMES, camMode) { camMode = it; renderer.cameraMode = it; Save.d.camera = it; Save.commit() })
        c.addView(Ui.button(this, "Exit to menu") { exit() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
    }

    private fun resume() {
        overlay.visibility = View.GONE
        renderer.paused = false
        engine.start()
    }

    private fun restart() {
        overlay.visibility = View.GONE
        granted = false
        input.steer = 0f
        sim = newSim()
        hud.sim = sim
        renderer.sim = sim
        renderer.paused = false
        engine.start()
    }

    private fun exit() { finish() }

    private fun showResults(res: RaceResult) {
        engine.stop()
        renderer.paused = false
        val reward = if (!granted) { granted = true; Progression.grantRace(cfg, res) } else null
        val c = panel(if (res.success) "RACE COMPLETE" else res.reason.uppercase(), if (res.success) Ui.GREEN else Ui.ACCENT)
        fun line(k: String, v: String) {
            val r = Ui.hbox(this)
            r.addView(Ui.text(this, k, 14f, Ui.DIM, true), Ui.lp(0, WRAP, 1f))
            r.addView(Ui.text(this, v, 14f, Ui.TEXT, true))
            c.addView(r)
        }
        line("REASON", res.reason)
        line("DISTANCE", "${res.distance.toInt()} m")
        line("TIME", "%d:%02d".format(res.time.toInt() / 60, res.time.toInt() % 60))
        line("TOP SPEED", "${res.topSpeedKmh.toInt()} km/h")
        line("COINS / NEAR MISSES", "${res.coins} / ${res.nearMisses}")
        line("SCORE", "${res.score}")
        if (reward != null) {
            c.addView(Ui.text(this, "+${reward.coins} coins   +${reward.xp} XP" + (if (reward.levelUp) "   LEVEL UP!" else "") + (if (reward.newBest) "   NEW BEST" else ""), 16f, Ui.GOLD, true))
            if (reward.note.isNotEmpty()) c.addView(Ui.text(this, reward.note, 13f, Ui.DIM))
        }
        val next = if (res.success && cfg.careerId.isNotEmpty()) Career.next(cfg.careerId) else null
        if (next != null) c.addView(Ui.button(this, "Next event: ${next.title}", true) {
            startActivity(Intent(this, GameActivity::class.java).putExtra(EXTRA_CFG, next.config.toJson()))
            finish()
        }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
        c.addView(Ui.button(this, "Restart", next == null) { restart() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
        c.addView(Ui.button(this, "Back to menu") { exit() }, Ui.lp(MATCH, WRAP, 0f, Ui.dp(this, 3)))
    }
}
