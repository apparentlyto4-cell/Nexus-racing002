package com.nexusracing.game.gameplay

/**
 * All traffic spacing / spawn parameters in one place (previously scattered literals in RaceSim).
 * Distances are bumper-to-bumper gaps in metres. Lower gaps = denser, more challenging traffic.
 */
object TrafficTuning {
    const val POOL = 32                 // maximum simultaneously active vehicles (object pool size)
    const val INITIAL = 16              // vehicles placed on the road at race start
    const val SPAWN_INTERVAL = 0.8f     // seconds between spawns at density 1 and low speed (was 1.1)
    const val SPEED_SPAWN_BOOST = 18f   // spawn timer runs faster by 1 + (speed-25)/this above 25 m/s, keeping spacing per metre constant
    const val MIN_GAP_SAME_LANE = 9f    // spawn: minimum gap to any vehicle in the same lane (was 16)
    const val MIN_GAP_OTHER_LANE = 3.5f // spawn: minimum gap to vehicles whose lane overlaps laterally (no clipping)
    const val OPEN_LANE_WINDOW = 14f    // at least one same-direction lane stays free within this distance of a new vehicle
    const val LANE_CHANGE_CLEAR = 8f    // gap required in the target lane before a lane change (was 12)
    const val LANE_CHANGE_CHANCE = 0.35f
    const val FOLLOW_GAP = 8f           // start slowing for a slower leader inside this gap (plus 0.25 s of headway)
    const val FOLLOW_BRAKE = 9f         // m/s^2 used to match the leader's speed (smooth, no teleport-braking)
    const val HARD_MATCH_GAP = 1.5f     // closer than this: speed is matched immediately
    const val MIN_SEPARATION = 0.3f     // emergency separation if two vehicles ever touch
}
