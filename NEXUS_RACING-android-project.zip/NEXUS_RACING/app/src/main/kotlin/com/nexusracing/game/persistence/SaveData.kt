package com.nexusracing.game.persistence

import com.nexusracing.game.data.Cust
import org.json.JSONArray
import org.json.JSONObject

/**
 * All persistent player data. Serialised to JSON by Save.
 * `version` is the schema version: bump it and add a step in migrate() when fields change.
 */
class SaveData {
    var version = CURRENT_VERSION
    var xp = 0
    var level = 1
    var coins = 500
    val unlocked = HashSet<String>()
    var selected = "street_runner"
    val upgrades = HashMap<String, Int>()      // "bikeId:category" -> level
    val custom = HashMap<String, String>()     // bikeId -> "paint,rim,decal,acc"
    val completed = HashSet<String>()          // completed career events
    var bestDistance = 0f
    var bestScore = 0
    var gfx = 1
    var sfx = 80
    var music = 60
    var scheme = 0                              // 0 buttons, 1 wheel, 2 joystick, 3 tilt
    var sens = 100
    var tiltReverse = false
    var tiltNeutral = 0f
    var camera = 0
    var vibration = true
    var fps = 60
    var lang = "en"
    var debug = false
    var env = 0
    var night = false
    var totalDistance = 0.0
    var totalCoins = 0
    var races = 0
    var wins = 0
    var crashes = 0
    var topSpeed = 0f
    var totalTime = 0.0
    val missionsClaimed = HashSet<String>()
    var dailyLast = -1L
    var dailyStreak = 0

    var ownerUnlocked = false                  // set once by the Owner Panel; owners also get future catalogue bikes
    val ownerGranted = HashSet<String>()       // bikes unlocked by the owner (not bought): excluded from the "own bikes" mission

    init { unlocked.add("street_runner") }

    fun cust(id: String): Cust = Cust.dec(custom[id])
    fun setCust(id: String, c: Cust) { custom[id] = c.enc() }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("version", version); o.put("xp", xp); o.put("level", level); o.put("coins", coins)
        o.put("unlocked", JSONArray(unlocked.toList())); o.put("selected", selected)
        o.put("upgrades", JSONObject(upgrades as Map<*, *>)); o.put("custom", JSONObject(custom as Map<*, *>))
        o.put("completed", JSONArray(completed.toList()))
        o.put("bestDistance", bestDistance.toDouble()); o.put("bestScore", bestScore)
        o.put("gfx", gfx); o.put("sfx", sfx); o.put("music", music); o.put("scheme", scheme); o.put("sens", sens)
        o.put("tiltReverse", tiltReverse); o.put("tiltNeutral", tiltNeutral.toDouble())
        o.put("camera", camera); o.put("vibration", vibration); o.put("fps", fps); o.put("lang", lang)
        o.put("debug", debug); o.put("env", env); o.put("night", night)
        o.put("totalDistance", totalDistance); o.put("totalCoins", totalCoins); o.put("races", races)
        o.put("wins", wins); o.put("crashes", crashes); o.put("topSpeed", topSpeed.toDouble()); o.put("totalTime", totalTime)
        o.put("missionsClaimed", JSONArray(missionsClaimed.toList()))
        o.put("dailyLast", dailyLast); o.put("dailyStreak", dailyStreak)
        o.put("ownerUnlocked", ownerUnlocked); o.put("ownerGranted", JSONArray(ownerGranted.toList()))
        return o
    }

    companion object {
        const val CURRENT_VERSION = 1

        /** Tolerant parser: missing or out-of-range fields fall back to safe defaults. */
        fun fromJson(o: JSONObject): SaveData {
            val s = SaveData()
            s.version = o.optInt("version", 1)
            migrate(s)
            s.xp = o.optInt("xp", 0).coerceAtLeast(0)
            s.level = o.optInt("level", 1).coerceAtLeast(1)
            s.coins = o.optInt("coins", 500).coerceAtLeast(0)
            readSet(o.optJSONArray("unlocked"), s.unlocked)
            s.unlocked.add("street_runner")
            s.selected = o.optString("selected", "street_runner")
            val up = o.optJSONObject("upgrades")
            if (up != null) for (k in up.keys()) s.upgrades[k] = up.optInt(k, 0).coerceIn(0, 5)
            val cu = o.optJSONObject("custom")
            if (cu != null) for (k in cu.keys()) s.custom[k] = cu.optString(k, "0,0,0,0")
            readSet(o.optJSONArray("completed"), s.completed)
            s.bestDistance = o.optDouble("bestDistance", 0.0).toFloat().coerceAtLeast(0f)
            s.bestScore = o.optInt("bestScore", 0).coerceAtLeast(0)
            s.gfx = o.optInt("gfx", 1).coerceIn(0, 2)
            s.sfx = o.optInt("sfx", 80).coerceIn(0, 100)
            s.music = o.optInt("music", 60).coerceIn(0, 100)
            s.scheme = o.optInt("scheme", 0).coerceIn(0, 3)
            s.sens = o.optInt("sens", 100).coerceIn(50, 150)
            s.tiltReverse = o.optBoolean("tiltReverse", false)
            s.tiltNeutral = o.optDouble("tiltNeutral", 0.0).toFloat().coerceIn(-1f, 1f)
            s.camera = o.optInt("camera", 0).coerceIn(0, 3)
            s.vibration = o.optBoolean("vibration", true)
            s.fps = if (o.optInt("fps", 60) <= 30) 30 else 60
            s.lang = o.optString("lang", "en")
            s.debug = o.optBoolean("debug", false)
            s.env = o.optInt("env", 0).coerceIn(0, 3)
            s.night = o.optBoolean("night", false)
            s.totalDistance = o.optDouble("totalDistance", 0.0).coerceAtLeast(0.0)
            s.totalCoins = o.optInt("totalCoins", 0).coerceAtLeast(0)
            s.races = o.optInt("races", 0).coerceAtLeast(0)
            s.wins = o.optInt("wins", 0).coerceAtLeast(0)
            s.crashes = o.optInt("crashes", 0).coerceAtLeast(0)
            s.topSpeed = o.optDouble("topSpeed", 0.0).toFloat().coerceAtLeast(0f)
            s.totalTime = o.optDouble("totalTime", 0.0).coerceAtLeast(0.0)
            readSet(o.optJSONArray("missionsClaimed"), s.missionsClaimed)
            s.dailyLast = o.optLong("dailyLast", -1L)
            s.dailyStreak = o.optInt("dailyStreak", 0).coerceIn(0, 7)
            s.ownerUnlocked = o.optBoolean("ownerUnlocked", false)
            readSet(o.optJSONArray("ownerGranted"), s.ownerGranted)
            return s
        }

        private fun readSet(a: JSONArray?, out: MutableSet<String>) {
            if (a == null) return
            for (i in 0 until a.length()) out.add(a.optString(i))
        }

        /** Upgrade old saves here when CURRENT_VERSION increases. */
        private fun migrate(s: SaveData) {
            // version 1 is the first schema: nothing to migrate yet.
            s.version = CURRENT_VERSION
        }
    }
}
