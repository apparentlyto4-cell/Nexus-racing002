package com.nexusracing.game.owner

import android.os.SystemClock
import com.nexusracing.game.data.Bikes
import com.nexusracing.game.persistence.Save
import java.security.MessageDigest

/**
 * DEVELOPMENT-ONLY owner verification for this local test build.
 *
 * The PIN is stored only as a salted SHA-256 hash (never as plain text, never logged, never shown).
 * This still is NOT secure authorization: a 6-digit PIN can be brute-forced offline by anyone who
 * extracts the APK, and the check can be patched out. Replace verify() with a server-side check before
 * shipping. Everything that touches the PIN is isolated in this file for that reason.
 */
object OwnerAccess {
    private const val SALT = "nexus-racing-dev-v1|"
    private const val PIN_SHA256 = "8fb481cf51c42acc35fb1890337a906a44a3ae572059082866e193f3043c98f7"
    private const val MAX_FAILS = 5
    private const val LOCK_MS = 30_000L

    enum class Result { OK, WRONG, LOCKED }

    private var fails = 0
    private var lockUntil = 0L

    fun lockedSeconds(): Int {
        val left = lockUntil - SystemClock.elapsedRealtime()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    private fun sha(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest((SALT + s).toByteArray(Charsets.UTF_8))

    private fun hex(h: String): ByteArray = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    /** Checks the PIN. Five wrong attempts lock the check for 30 seconds. */
    fun verify(pin: String): Result {
        if (lockedSeconds() > 0) return Result.LOCKED
        val ok = MessageDigest.isEqual(sha(pin.trim()), hex(PIN_SHA256))
        if (ok) { fails = 0; return Result.OK }
        fails++
        if (fails >= MAX_FAILS) { fails = 0; lockUntil = SystemClock.elapsedRealtime() + LOCK_MS }
        return Result.WRONG
    }

    /**
     * Unlocks every bike in the current catalogue (including bikes added later: Save.init() calls this
     * again for owners). Idempotent: bikes already owned are untouched, nothing is charged, no stats
     * or progress change. Returns how many bikes were newly unlocked.
     */
    fun grantAll(): Int {
        val d = Save.d
        var n = 0
        for (b in Bikes.all) {
            if (d.unlocked.add(b.id)) { d.ownerGranted.add(b.id); n++ }
        }
        if (!d.ownerUnlocked) { d.ownerUnlocked = true; n = n.coerceAtLeast(0) }
        Save.commit()
        return n
    }

    /** Called after loading a save: owners also get bikes that were added to the catalogue since. */
    fun regrantIfOwner() {
        if (!Save.d.ownerUnlocked) return
        for (b in Bikes.all) if (Save.d.unlocked.add(b.id)) Save.d.ownerGranted.add(b.id)
    }
}
