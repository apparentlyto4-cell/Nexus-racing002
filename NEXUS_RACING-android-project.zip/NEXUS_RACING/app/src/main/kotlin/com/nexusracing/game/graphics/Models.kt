package com.nexusracing.game.graphics

import com.nexusracing.game.data.BikeSpec
import com.nexusracing.game.data.Cust
import com.nexusracing.game.data.Gfx
import com.nexusracing.game.data.Palette
import com.nexusracing.game.gameplay.VType

/**
 * Original procedural models (boxes, cylinders, cones). Bikes face -Z, vehicles face -Z too
 * (oncoming vehicles are drawn with a 180 degree rotation in the base matrix).
 * Bike shape parameters come from BikeSpec so every bike looks different.
 */
class Models(private val kit: GlKit) {
    private val dark = 0xFF15171B.toInt()
    private val glass = 0xFF1D2A36.toInt()
    private val metal = 0xFFB0B5BC.toInt()

    private fun b(
        base: FloatArray, px: Float, py: Float, pz: Float, sx: Float, sy: Float, sz: Float,
        col: Int, lit: Boolean = true, rx: Float = 0f, rz: Float = 0f
    ) = kit.draw(kit.cube, base, px, py, pz, rx, 0f, rz, sx, sy, sz, col, lit)

    private fun cy(
        base: FloatArray, px: Float, py: Float, pz: Float, rx: Float, rz: Float,
        sx: Float, sy: Float, sz: Float, col: Int
    ) = kit.draw(kit.cyl, base, px, py, pz, rx, 0f, rz, sx, sy, sz, col, true)

    // ------------------------------------------------------------------ bike
    private fun wheel(base: FloatArray, z: Float, r: Float, rim: Int, deg: Float) {
        cy(base, 0f, r, z, 0f, 90f, 2f * r, 0.16f, 2f * r, 0xFF16181C.toInt())          // tyre
        cy(base, 0f, r, z, 0f, 90f, 1.3f * r, 0.18f, 1.3f * r, rim)                      // rim
        b(base, 0f, r, z, 0.19f, 0.04f, 2f * r * 0.8f, 0xFF30343A.toInt(), true, deg)    // spokes (rotate with speed)
        b(base, 0f, r, z, 0.19f, 0.04f, 2f * r * 0.8f, 0xFF30343A.toInt(), true, deg + 90f)
    }

    // one GPU copy of each GLB model per GL context, uploaded progressively
    private val glbGpus = HashMap<String, GlbGpu>()

    /** Returns the ready GLB renderer for this bike, or null (not loaded yet / failed) -> procedural bike is drawn. */
    private fun glbFor(s: BikeSpec): GlbGpu? {
        val path = s.modelPath ?: return null
        var g = glbGpus[path]
        if (g == null) {
            val asset = GlbAssets.get(path) ?: return null
            g = GlbGpu(asset, Gfx.current().let { Gfx.presets.indexOf(it).coerceAtLeast(0) })
            glbGpus[path] = g
        }
        if (g.failed) return null
        if (!g.ready) g.step()
        return if (g.ready) g else null
    }

    /** Frees GPU memory of GLB models (call on the GL thread when the renderer is torn down). */
    fun release() { for (g in glbGpus.values) g.release(); glbGpus.clear() }

    fun bike(base: FloatArray, s: BikeSpec, c: Cust, wheelDeg: Float, rider: Boolean, braking: Boolean) {
        val g = glbFor(s)
        if (g != null) {
            g.setViewProjection(kit.vpMatrix())
            g.draw(kit, base)
            if (rider) drawRider(base, s)
            return
        }
        procBike(base, s, c, wheelDeg, rider, braking)
    }

    private fun procBike(base: FloatArray, s: BikeSpec, c: Cust, wheelDeg: Float, rider: Boolean, braking: Boolean) {
        val body = Palette.paints[c.paint]
        val rim = Palette.rims[c.rim]
        val wb = s.wheelBase
        val r = s.wheelR
        val hz = wb / 2f
        val sy = s.seatY
        wheel(base, -hz, r, rim, wheelDeg)
        wheel(base, hz, r, rim, wheelDeg)
        b(base, 0f, r + 0.15f, 0.05f, 0.28f, 0.32f, 0.7f, 0xFF3B3F46.toInt())               // engine block
        val tankW = 0.34f
        b(base, 0f, r + 0.52f, -0.18f, tankW, 0.26f, 0.55f * s.tank, body)                  // tank
        b(base, 0f, r + 0.43f + sy, 0.42f, 0.30f, 0.10f, 0.62f, 0xFF202226.toInt())          // seat
        b(base, 0f, r + 0.54f + sy, hz - 0.3f, 0.26f, 0.16f, 0.4f, body)                     // tail cowl
        b(base, 0.09f, r + 0.40f, -hz + 0.18f, 0.05f, 0.8f, 0.06f, metal, true, 18f)         // fork L
        b(base, -0.09f, r + 0.40f, -hz + 0.18f, 0.05f, 0.8f, 0.06f, metal, true, 18f)        // fork R
        b(base, 0f, r + 0.86f, -hz + 0.38f, 0.7f, 0.05f, 0.05f, dark)                        // handlebar
        b(base, 0f, r + 0.72f, -hz + 0.02f, 0.22f, 0.18f, 0.12f, 0xFFFFF4C8.toInt(), false)  // headlight
        if (s.fairing >= 1) {
            b(base, 0f, r + 0.70f, -hz + 0.40f, 0.40f, 0.34f, 0.5f, body)
            b(base, 0f, r + 1.0f, -hz + 0.48f, 0.3f, 0.25f, 0.03f, 0xFF8FB8D8.toInt(), true, -30f)
        }
        if (s.fairing >= 2) b(base, 0f, r + 0.45f, -0.05f, 0.46f, 0.3f, 0.9f, body)
        b(base, 0f, r + 0.55f + sy, hz - 0.08f, 0.18f, 0.06f, 0.04f,
            if (braking) 0xFFFF2020.toInt() else 0xFFA01010.toInt(), false)                    // tail light
        cy(base, 0.2f, r + 0.1f, hz - 0.4f, 90f, 0f, 0.1f, 0.7f, 0.1f, metal)                // exhaust
        // decals
        when (c.decal) {
            1 -> b(base, 0f, r + 0.657f, -0.18f, 0.07f, 0.012f, 0.58f * s.tank, 0xFFFFFFFF.toInt())
            2 -> for (sd in 0..1) {
                val x = if (sd == 0) 0.172f else -0.172f
                b(base, x, r + 0.52f, -0.18f, 0.01f, 0.12f, 0.3f, 0xFFFF7A00.toInt())
                b(base, x, r + 0.50f, -0.12f, 0.012f, 0.06f, 0.16f, 0xFFFFD000.toInt())
            }
            3 -> for (sd in 0..1) {
                val x = if (sd == 0) 0.132f else -0.132f
                b(base, x, r + 0.54f + sy, hz - 0.3f, 0.01f, 0.14f, 0.2f, 0xFFFFFFFF.toInt())
                b(base, x, r + 0.54f + sy, hz - 0.3f, 0.012f, 0.08f, 0.1f, 0xFF101010.toInt())
            }
        }
        // accessories
        when (c.acc) {
            1 -> b(base, 0f, r + 0.72f + sy, hz - 0.05f, 0.34f, 0.26f, 0.4f, 0xFF2B2F36.toInt())
            2 -> for (sd in 0..1) b(base, if (sd == 0) 0.3f else -0.3f, r + 0.3f, hz - 0.2f, 0.16f, 0.22f, 0.4f, 0xFF2B2F36.toInt())
            3 -> b(base, 0f, r + 1.12f, -hz + 0.5f, 0.34f, 0.4f, 0.03f, 0xFF9CC9E8.toInt(), true, -25f)
        }
        if (rider) drawRider(base, s)
    }

    /** The rider figure (used by procedural bikes and on top of GLB models). */
    private fun drawRider(base: FloatArray, s: BikeSpec) {
        val r = s.wheelR
        val sy = s.seatY
        run {
            b(base, 0f, r + 0.95f + sy, 0.18f, 0.36f, 0.5f, 0.22f, 0xFF23262D.toInt(), true, -28f)   // torso
            b(base, 0f, r + 1.40f + sy, -0.05f, 0.26f, 0.26f, 0.28f, 0xFFEEEEEE.toInt())            // helmet
            b(base, 0f, r + 1.40f + sy, -0.19f, 0.2f, 0.1f, 0.04f, glass)                           // visor
            b(base, 0.23f, r + 1.0f + sy, -0.25f, 0.09f, 0.09f, 0.6f, 0xFF23262D.toInt())           // arms
            b(base, -0.23f, r + 1.0f + sy, -0.25f, 0.09f, 0.09f, 0.6f, 0xFF23262D.toInt())
            b(base, 0.2f, r + 0.45f, 0.25f, 0.12f, 0.5f, 0.15f, 0xFF2A3342.toInt())                 // legs
            b(base, -0.2f, r + 0.45f, 0.25f, 0.12f, 0.5f, 0.15f, 0xFF2A3342.toInt())
        }
    }

    // ------------------------------------------------------------------ traffic
    private fun wheelAt(base: FloatArray, x: Float, r: Float, z: Float) =
        cy(base, x, r, z, 0f, 90f, 2f * r, 0.3f, 2f * r, dark)

    fun vehicle(base: FloatArray, type: Int, color: Int, t: Float) {
        val hw = VType.halfW[type]
        val hl = VType.halfL[type]
        val tail = 0xFFE01818.toInt()
        val head = 0xFFFFF2C0.toInt()
        when (type) {
            VType.CAR -> {
                b(base, 0f, 0.6f, 0f, 1.8f, 0.55f, 4.2f, color)
                b(base, 0f, 1.1f, 0.25f, 1.6f, 0.5f, 2.2f, glass)
                b(base, 0f, 1.38f, 0.25f, 1.5f, 0.06f, 1.8f, color)
                for (sx in 0..1) for (sz in 0..1) wheelAt(base, if (sx == 0) hw - 0.05f else -hw + 0.05f, 0.34f, if (sz == 0) -1.3f else 1.3f)
            }
            VType.SUV -> {
                b(base, 0f, 0.8f, 0f, 2.0f, 0.9f, 4.8f, color)
                b(base, 0f, 1.5f, 0.3f, 1.85f, 0.6f, 3.2f, glass)
                b(base, 0f, 1.82f, 0.3f, 1.8f, 0.06f, 3.0f, color)
                for (sx in 0..1) for (sz in 0..1) wheelAt(base, if (sx == 0) hw - 0.05f else -hw + 0.05f, 0.4f, if (sz == 0) -1.5f else 1.5f)
            }
            VType.VAN -> {
                b(base, 0f, 1.15f, 0f, 2.0f, 1.7f, 5.0f, color)
                b(base, 0f, 1.45f, -2.3f, 1.9f, 0.6f, 0.08f, glass)
                for (sx in 0..1) for (sz in 0..1) wheelAt(base, if (sx == 0) hw - 0.05f else -hw + 0.05f, 0.38f, if (sz == 0) -1.6f else 1.6f)
            }
            VType.TRUCK -> {
                b(base, 0f, 0.5f, 0f, 2.2f, 0.4f, 9.0f, dark)                                    // chassis
                b(base, 0f, 1.6f, -3.4f, 2.4f, 2.2f, 2.2f, color)                                // cab
                b(base, 0f, 2.0f, -4.48f, 2.2f, 0.9f, 0.06f, glass)
                b(base, 0f, 2.1f, 1.4f, 2.5f, 3.2f, 6.2f, 0xFFD9DDE1.toInt())                  // cargo box
                for (sx in 0..1) for (zz in 0..2) wheelAt(base, if (sx == 0) 1.1f else -1.1f, 0.5f, -3.2f + zz * 3.6f)
            }
            VType.BUS -> {
                b(base, 0f, 1.7f, 0f, 2.5f, 2.9f, 11.0f, color)
                b(base, 1.27f, 2.1f, 0f, 0.03f, 0.9f, 9.6f, glass)
                b(base, -1.27f, 2.1f, 0f, 0.03f, 0.9f, 9.6f, glass)
                b(base, 0f, 2.2f, -5.52f, 2.3f, 1.2f, 0.06f, glass)
                for (sx in 0..1) for (zz in 0..1) wheelAt(base, if (sx == 0) 1.1f else -1.1f, 0.5f, if (zz == 0) -3.6f else 3.4f)
            }
            else -> { // police car (also used for the roadblock and the chasing patrol)
                b(base, 0f, 0.6f, 0f, 1.8f, 0.55f, 4.2f, 0xFFF2F2F2.toInt())
                b(base, 0f, 0.45f, 0f, 1.82f, 0.18f, 4.22f, 0xFF16206B.toInt())
                b(base, 0f, 1.1f, 0.25f, 1.6f, 0.5f, 2.2f, glass)
                b(base, 0f, 1.38f, 0.25f, 1.5f, 0.06f, 1.8f, 0xFFF2F2F2.toInt())
                val f = ((t * 6f).toInt() and 1) == 0
                b(base, 0.4f, 1.5f, 0.25f, 0.5f, 0.12f, 0.3f, if (f) 0xFFFF2020.toInt() else 0xFF300808.toInt(), false)
                b(base, -0.4f, 1.5f, 0.25f, 0.5f, 0.12f, 0.3f, if (f) 0xFF101840.toInt() else 0xFF2040FF.toInt(), false)
                for (sx in 0..1) for (sz in 0..1) wheelAt(base, if (sx == 0) hw - 0.05f else -hw + 0.05f, 0.34f, if (sz == 0) -1.3f else 1.3f)
            }
        }
        // lights: tail (rear = +z) and head (front = -z)
        b(base, hw - 0.4f, 0.75f, hl, 0.4f, 0.12f, 0.05f, tail, false)
        b(base, -hw + 0.4f, 0.75f, hl, 0.4f, 0.12f, 0.05f, tail, false)
        b(base, hw - 0.4f, 0.75f, -hl, 0.4f, 0.12f, 0.05f, head, false)
        b(base, -hw + 0.4f, 0.75f, -hl, 0.4f, 0.12f, 0.05f, head, false)
    }
}
