package com.nexusracing.game.graphics

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.nexusracing.game.camera.CameraRig
import com.nexusracing.game.data.*
import com.nexusracing.game.gameplay.InputState
import com.nexusracing.game.gameplay.RaceSim
import com.nexusracing.game.persistence.Save
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/** Runs the fixed-step simulation and draws it. Lives on the GLSurfaceView render thread. */
class RaceRenderer(
    @Volatile var sim: RaceSim,
    private val cfg: RaceConfig,
    private val gfx: GfxPreset,
    private val input: InputState
) : GLSurfaceView.Renderer {
    companion object { const val STEP = 1f / 60f }

    @Volatile var cameraMode = 0
    @Volatile var paused = false
    @Volatile var debug = false
    @Volatile var fpsCap = 60
    @Volatile var fps = 0f

    private var kit: GlKit? = null
    private var models: Models? = null
    private var scene: SceneDrawer? = null
    private val camera = CameraRig()
    private var aspect = 1.7f
    private var last = 0L
    private var acc = 0f
    private var clock = 0f
    private var frames = 0
    private var fpsT = 0f
    private val spec = Bikes.byId(Save.d.selected)
    private val cust = Save.d.cust(spec.id)

    /** Frees GPU memory (GLB textures/buffers, sky shader). Run on the GL thread, e.g. via GLSurfaceView.queueEvent. */
    fun releaseGpu() {
        models?.release()
        scene?.release()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // a new GL context was created: objects of the old one are already gone, just drop the references
        models = null; scene = null
        val k = GlKit()
        k.init()
        kit = k
        val m = Models(k)
        models = m
        scene = SceneDrawer(k, m, cfg, gfx)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        aspect = w.toFloat() / max(1, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val sc = scene ?: return
        val now = System.nanoTime()
        var dt = (now - last) / 1e9f
        last = now
        if (dt > 0.1f) dt = 0.1f
        val s = sim
        if (!paused) {
            acc += dt
            var n = 0
            while (acc >= STEP && n < 5) { s.update(STEP, input); acc -= STEP; n++ }
            if (n == 5) acc = 0f
            clock += dt
        }
        frames++
        fpsT += dt
        if (fpsT >= 0.5f) { fps = frames / fpsT; frames = 0; fpsT = 0f }

        camera.update(cameraMode, s.x, -s.dist, (s.speed / s.vmax).coerceIn(0f, 1.3f), dt, clock, s.bike.phys, s.leanDeg)
        sc.render(s, spec, cust, camera.eye, camera.look, camera.fov, aspect, clock, cameraMode, debug, camera.roll)

        val cap = fpsCap
        if (cap in 1..59) {
            val target = 1_000_000_000L / cap
            val spent = System.nanoTime() - now
            if (spent < target) Thread.sleep((target - spent) / 1_000_000L)
        }
    }
}
