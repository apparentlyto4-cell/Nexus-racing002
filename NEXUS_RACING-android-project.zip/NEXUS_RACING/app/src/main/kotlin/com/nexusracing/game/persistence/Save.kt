package com.nexusracing.game.persistence

import android.content.Context
import android.content.SharedPreferences
import com.nexusracing.game.data.Bikes
import org.json.JSONObject

/**
 * Local save store. The JSON is written to SharedPreferences with a single commit() that updates
 * both the main slot and a backup slot. If the main slot is corrupt we fall back to the backup,
 * and finally to fresh defaults, so a damaged save never crashes the game.
 */
object Save {
    private const val PREFS = "nexus_save"
    private const val K_MAIN = "main"
    private const val K_BAK = "backup"
    private lateinit var prefs: SharedPreferences
    lateinit var d: SaveData

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        d = load()
        validate()
    }

    private fun load(): SaveData {
        for (k in arrayOf(K_MAIN, K_BAK)) {
            val s = prefs.getString(k, null) ?: continue
            try {
                return SaveData.fromJson(JSONObject(s))
            } catch (e: Exception) {
                // try next slot
            }
        }
        return SaveData()
    }

    /** Make sure bike ids in the save still exist in bikes.json. */
    private fun validate() {
        val first = Bikes.all[0].id
        d.unlocked.add(first)
        val ids = Bikes.all.map { it.id }.toSet()
        d.unlocked.retainAll(ids)
        d.ownerGranted.retainAll(ids)
        com.nexusracing.game.owner.OwnerAccess.regrantIfOwner()     // owners also receive bikes added to the catalogue later
        if (!d.unlocked.contains(d.selected)) d.selected = first
    }

    fun commit() {
        val s = d.toJson().toString()
        prefs.edit().putString(K_BAK, prefs.getString(K_MAIN, s)).putString(K_MAIN, s).commit()
    }

    fun reset() {
        d = SaveData()
        validate()
        commit()
    }
}
