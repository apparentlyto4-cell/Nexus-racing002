package com.nexusracing.game.camera

import com.nexusracing.game.data.BikePhys
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin

/**
 * Four camera modes. Offsets and the look-at point are smoothed (exponential easing), so switching
 * modes glides instead of snapping. Smoothing is applied to the *offset* from the bike, not to the
 * world position, so the camera never lags behind the bike along the road at high speed.
 */
class CameraRig {
    companion object {
        val NAMES = arrayOf("Chase", "Close chase", "Rider view", "Elevated")
        private val UP = floatArrayOf(3.0f, 1.9f, 1.55f, 13f)
        private val BACK = floatArrayOf(7.0f, 4.2f, -0.1f, 10f)
        private val LOOK_Y = floatArrayOf(1.0f, 1.0f, 1.35f, 0f)
        private val AHEAD = floatArrayOf(12f, 10f, 30f, 14f)
        private val FOV = floatArrayOf(62f, 66f, 74f, 58f)
        private val FOLLOW = floatArrayOf(0.85f, 0.9f, 1f, 0.8f)
        private val KX = floatArrayOf(9f, 9f, 22f, 9f)
    }

    val eye = FloatArray(3)
    val look = FloatArray(3)
    var fov = 62f
    /** Camera roll in degrees (a fraction of the bike's lean; 0 for bikes without camRoll). */
    var roll = 0f
    private var offY = 3f
    private var offZ = 7f
    private var lookY = 1f
    private var ahead = 12f
    private var cx = 0f
    private var lx = 0f
    private var ready = false

    /** bx = bike x, bz = bike world z (= -distance). */
    fun update(
        mode: Int, bx: Float, bz: Float, speedRatio: Float, dt: Float, t: Float,
        tune: BikePhys = BikePhys.DEFAULT, leanDeg: Float = 0f
    ) {
        val m = mode.coerceIn(0, 3)
        val tFov = FOV[m] + tune.fovGain * speedRatio
        // fast bikes pull the chase camera back a little at speed (not in rider view)
        val back = BACK[m] + (if (m == 2) 0f else tune.camPullback * speedRatio.coerceAtMost(1f))
        if (!ready) {
            offY = UP[m]; offZ = back; lookY = LOOK_Y[m]; ahead = AHEAD[m]; fov = tFov
            cx = bx * FOLLOW[m]; lx = bx
            ready = true
        } else {
            val k = 1f - exp(-4f * dt)
            offY += (UP[m] - offY) * k
            offZ += (back - offZ) * k
            lookY += (LOOK_Y[m] - lookY) * k
            ahead += (AHEAD[m] - ahead) * k
            fov += (tFov - fov) * k
            val kx = 1f - exp(-KX[m] * dt)
            cx += (bx * FOLLOW[m] - cx) * kx
            lx += (bx - lx) * kx
        }
        roll += (leanDeg * tune.camRoll - roll) * (1f - exp(-6f * dt))
        val shake = max(0f, speedRatio - 0.7f) * 0.06f * tune.camShake
        eye[0] = cx + sin(t * 41f + 1f) * shake
        eye[1] = offY + sin(t * 53f) * shake
        eye[2] = bz + offZ
        look[0] = lx
        look[1] = lookY
        look[2] = bz - ahead
    }
}
