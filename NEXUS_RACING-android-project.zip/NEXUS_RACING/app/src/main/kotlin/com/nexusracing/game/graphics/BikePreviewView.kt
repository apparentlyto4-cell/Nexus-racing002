package com.nexusracing.game.graphics

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.nexusracing.game.data.BikeSpec
import com.nexusracing.game.data.Bikes
import com.nexusracing.game.data.Cust
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/** Rotating 3D showroom view used by the main menu, garage and customization screens. */
class BikePreviewView(ctx: Context) : GLSurfaceView(ctx) {
    @Volatile private var spec: BikeSpec = Bikes.all[0]
    @Volatile private var cust: Cust = Cust()

    fun setBike(s: BikeSpec, c: Cust) { spec = s; cust = c }

    private val r = object : Renderer {
        private var kit: GlKit? = null
        private var models: Models? = null
        private var aspect = 1.5f
        private var last = 0L
        private var angle = 25f
        private val proj = FloatArray(16)
        private val view = FloatArray(16)
        private val vp = FloatArray(16)
        private val ident = FloatArray(16)
        private val base = FloatArray(16)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            val k = GlKit(); k.init(); kit = k; models = Models(k)    // fresh context: old GPU objects are already gone
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)
            Matrix.setIdentityM(ident, 0)
            last = System.nanoTime()
        }

        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
            GLES20.glViewport(0, 0, w, h); aspect = w.toFloat() / max(1, h)
        }

        fun release() { models?.release() }

        override fun onDrawFrame(gl: GL10?) {
            val k = kit ?: return
            val m = models ?: return
            val now = System.nanoTime()
            val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
            last = now
            angle = (angle + dt * 30f) % 360f
            GLES20.glClearColor(0.055f, 0.07f, 0.1f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            Matrix.perspectiveM(proj, 0, 38f, aspect, 0.5f, 60f)
            Matrix.setLookAtM(view, 0, 0f, 1.7f, 4.2f, 0f, 0.75f, 0f, 0f, 1f, 0f)
            Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
            k.begin(vp, 0.4f, 1f, 0.7f, 0.5f, 1f, 0.055f, 0.07f, 0.1f, 0f)
            k.setEye(0f, 1.7f, 4.2f)
            // the model may still be loading in the background: keep asking for it until it exists
            val sp = spec
            if (sp.modelPath != null && GlbAssets.get(sp.modelPath) == null && !GlbAssets.hasFailed(sp.modelPath)) GlbAssets.preload(context, sp.modelPath)
            k.draw(k.cyl, ident, 0f, -0.06f, 0f, 0f, 0f, 0f, 3.8f, 0.1f, 3.8f, 0xFF1B2230.toInt(), true)
            k.draw(k.cyl, ident, 0f, -0.1f, 0f, 0f, 0f, 0f, 4.1f, 0.06f, 4.1f, 0xFF19D3FF.toInt(), false)
            Matrix.setIdentityM(base, 0)
            Matrix.rotateM(base, 0, angle, 0f, 1f, 0f)
            m.bike(base, spec, cust, angle * 3f, true, false)
        }
    }

    /** Frees the GLB GPU copy; call from the owner's onDestroy if the view is discarded. */
    fun releaseGpu() { queueEvent { r.release() } }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(r)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
