package com.nexusracing.game.data

import android.content.Context
import com.nexusracing.game.persistence.Save
import org.json.JSONArray

/** One motorcycle. Loaded from assets/config/bikes.json so it can be edited without touching code. */
class BikeSpec(
    val id: String, val name: String,
    val topSpeedKmh: Float, val accel: Float, val handling: Float, val braking: Float,
    val price: Int, val unlockLevel: Int,
    // procedural-model parameters
    val wheelBase: Float, val wheelR: Float, val fairing: Int, val tank: Float, val seatY: Float,
    // optional extras (all have defaults so legacy catalogue entries keep working)
    val klass: String = "",                 // shown in the garage, e.g. "Legendary / SSS"
    val modelPath: String? = null,          // assets path of a .glb model; null = procedural bike
    val phys: BikePhys = BikePhys.DEFAULT   // per-bike physics / handling profile
)

object Bikes {
    var all: List<BikeSpec> = emptyList()
        private set

    fun load(ctx: Context) {
        val list = ArrayList<BikeSpec>()
        try {
            val txt = ctx.assets.open("config/bikes.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(txt)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    BikeSpec(
                        o.getString("id"), o.getString("name"),
                        o.getDouble("topSpeedKmh").toFloat(), o.getDouble("accel").toFloat(),
                        o.getDouble("handling").toFloat(), o.getDouble("braking").toFloat(),
                        o.getInt("price"), o.getInt("unlockLevel"),
                        o.getDouble("wheelBase").toFloat(), o.getDouble("wheelR").toFloat(),
                        o.getInt("fairing"), o.getDouble("tank").toFloat(), o.getDouble("seatY").toFloat(),
                        o.optString("klass", ""),
                        o.optJSONObject("model")?.optString("glb", "")?.takeIf { it.isNotEmpty() },
                        BikePhys.fromJson(o.optJSONObject("phys"))
                    )
                )
            }
        } catch (e: Exception) {
            list.clear()
        }
        if (list.isEmpty()) {
            list.add(BikeSpec("street_runner", "Street Runner", 180f, 9f, 0.7f, 14f, 0, 1, 1.35f, 0.33f, 0, 1f, 0f))
        }
        all = list
    }

    fun byId(id: String): BikeSpec = all.firstOrNull { it.id == id } ?: all[0]
}

/** Paint / rim / decal / accessory options (all rendered by the procedural bike model). */
object Palette {
    val paints = intArrayOf(
        0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFDD835.toInt(),
        0xFF8E24AA.toInt(), 0xFFFB8C00.toInt(), 0xFFECEFF1.toInt(), 0xFF212121.toInt()
    )
    val rims = intArrayOf(0xFFB0BEC5.toInt(), 0xFFFFD54F.toInt(), 0xFFFF5252.toInt(), 0xFF40C4FF.toInt(), 0xFF69F0AE.toInt())
    val decals = arrayOf("None", "Racing stripe", "Flames", "Number plate")
    val accessories = arrayOf("None", "Top case", "Side bags", "Tall screen")
}

class Cust(var paint: Int = 0, var rim: Int = 0, var decal: Int = 0, var acc: Int = 0) {
    fun enc(): String = "$paint,$rim,$decal,$acc"

    companion object {
        fun dec(s: String?): Cust {
            val p = (s ?: "").split(",")
            fun at(i: Int, max: Int): Int = (p.getOrNull(i)?.toIntOrNull() ?: 0).coerceIn(0, max - 1)
            return Cust(at(0, Palette.paints.size), at(1, Palette.rims.size), at(2, Palette.decals.size), at(3, Palette.accessories.size))
        }
    }
}

/** Graphics presets. These values really drive the renderer (see graphics/). */
class GfxPreset(
    val name: String, val viewDist: Float, val scenery: Int, val trafficCap: Int,
    val blobShadows: Boolean, val particles: Int, val renderScale: Float,
    val speedFx: Boolean, val details: Boolean
)

object Gfx {
    val presets = listOf(
        GfxPreset("LOW", 150f, 1, 10, false, 0, 0.6f, false, false),
        GfxPreset("MEDIUM", 230f, 2, 18, true, 90, 0.8f, true, true),
        GfxPreset("HIGH", 320f, 3, 26, true, 200, 1f, true, true)
    )
    fun current(): GfxPreset = presets[Save.d.gfx.coerceIn(0, presets.size - 1)]
}

/** kind: 0 city, 1 desert, 2 village, 3 winter (selects the procedural scenery set). */
class EnvSpec(val name: String, val sky: Int, val ground: Int, val road: Int, val kind: Int)

object Envs {
    val all = listOf(
        EnvSpec("City", 0xFF8EC5FF.toInt(), 0xFF4A4F57.toInt(), 0xFF2A2C31.toInt(), 0),
        EnvSpec("Desert Highway", 0xFFB5DCFF.toInt(), 0xFFD9B26F.toInt(), 0xFF3A3735.toInt(), 1),
        EnvSpec("Village", 0xFF9ED0FF.toInt(), 0xFF4F8F3A.toInt(), 0xFF2E3033.toInt(), 2),
        EnvSpec("Winter Road", 0xFFC4D2E0.toInt(), 0xFFEEF3F8.toInt(), 0xFF3A3C40.toInt(), 3)
    )
    val names: Array<String> get() = all.map { it.name }.toTypedArray()
    val weather = arrayOf("Clear", "Rain", "Snow", "Fog")
}
