package com.nexusracing.game.gameplay

import com.nexusracing.game.data.BikeSpec
import com.nexusracing.game.persistence.Save
import java.util.Locale

/** The one place where bikes are bought. Never lets coins go negative and never charges twice. */
object Shop {
    class Result(val ok: Boolean, val message: String)

    fun fmt(n: Int): String = String.format(Locale.US, "%,d", n)

    fun purchase(b: BikeSpec): Result {
        val d = Save.d
        if (d.unlocked.contains(b.id)) return Result(false, "You already own ${b.name}")
        if (d.level < b.unlockLevel) return Result(false, "Reach level ${b.unlockLevel} first")
        if (b.price < 0) return Result(false, "Invalid price")
        if (d.coins < b.price) return Result(false, "Not enough coins: need ${fmt(b.price)}, you have ${fmt(d.coins)}")
        if (!Progression.spend(b.price)) return Result(false, "Purchase failed")
        d.unlocked.add(b.id)
        d.selected = b.id
        Save.commit()
        return Result(true, "Purchased ${b.name}")
    }
}
