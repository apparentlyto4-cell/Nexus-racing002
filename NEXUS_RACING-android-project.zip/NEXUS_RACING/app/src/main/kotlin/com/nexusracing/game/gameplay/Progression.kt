package com.nexusracing.game.gameplay

import com.nexusracing.game.data.*
import com.nexusracing.game.persistence.Save
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.sqrt

class RaceResult(
    val success: Boolean, val reason: String, val distance: Float, val time: Float,
    val coins: Int, val score: Int, val topSpeedKmh: Float, val nearMisses: Int
)

class Reward(val coins: Int, val xp: Int, val levelUp: Boolean, val newBest: Boolean, val note: String)

/** XP, levels, coins, rewards, missions and daily rewards. All rewards are granted from one place. */
object Progression {
    const val COIN_VALUE = 5   // currency per collected coin pickup

    fun levelFor(xp: Int): Int = 1 + floor(sqrt(xp / 120.0)).toInt()
    fun xpAtLevel(level: Int): Int = 120 * (level - 1) * (level - 1)

    fun addCoins(n: Int) {
        if (n <= 0) return
        Save.d.coins = (Save.d.coins.toLong() + n).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    }

    fun spend(n: Int): Boolean {
        if (n < 0 || Save.d.coins < n) return false
        Save.d.coins -= n
        return true
    }

    private fun addXp(n: Int): Boolean {
        val d = Save.d
        val old = d.level
        d.xp = (d.xp.toLong() + n.coerceAtLeast(0)).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        d.level = levelFor(d.xp)
        return d.level > old
    }

    /** Called exactly once per finished race by GameActivity. */
    fun grantRace(cfg: RaceConfig, r: RaceResult): Reward {
        val d = Save.d
        var bonus = 0
        var xp = (r.distance / 40f).toInt() + r.coins * 2 + r.nearMisses
        var note = ""
        if (r.success) {
            val ev = if (cfg.careerId.isNotEmpty()) Career.byId(cfg.careerId) else null
            if (ev != null) {
                val first = d.completed.add(ev.id)   // true only the first time
                bonus += if (first) ev.rewardCoins else ev.rewardCoins / 5
                xp += if (first) ev.rewardXp else ev.rewardXp / 5
                note = if (first) "First completion bonus!" else "Repeat reward (20%)"
            } else {
                bonus += (r.distance / 100f).toInt() + (if (cfg.mode == Mode.ESCAPE) 200 else 0)
            }
        } else {
            bonus += (r.distance / 250f).toInt()
        }
        val coins = r.coins * COIN_VALUE + bonus
        addCoins(coins)
        val up = addXp(xp)
        d.totalDistance += r.distance
        d.totalCoins += r.coins
        d.races += 1
        if (r.success) d.wins += 1
        if (!r.success && r.reason.contains("Crash", true)) d.crashes += 1
        if (r.topSpeedKmh > d.topSpeed) d.topSpeed = r.topSpeedKmh
        d.totalTime += r.time
        val best = r.distance > d.bestDistance || r.score > d.bestScore
        if (r.distance > d.bestDistance) d.bestDistance = r.distance
        if (r.score > d.bestScore) d.bestScore = r.score
        Save.commit()
        return Reward(coins, xp, up, best, note)
    }

    fun missionProgress(m: Mission): Float {
        val d = Save.d
        return when (m.kind) {
            "distance" -> d.totalDistance.toFloat()
            "coins" -> d.totalCoins.toFloat()
            "wins" -> d.wins.toFloat()
            "speed" -> d.topSpeed
            "career" -> d.completed.size.toFloat()
            "bikes" -> (d.unlocked.size - d.ownerGranted.size).coerceAtLeast(0).toFloat()   // owner-granted bikes do not count
            else -> 0f
        }
    }

    /** Returns null on success or an error text. Each mission can be claimed once. */
    fun claimMission(m: Mission): String? {
        val d = Save.d
        if (d.missionsClaimed.contains(m.id)) return "Already claimed"
        if (missionProgress(m) < m.target) return "Mission not complete"
        d.missionsClaimed.add(m.id)
        addCoins(m.reward)
        Save.commit()
        return null
    }

    // ---- Daily rewards (local only: the device clock can be changed, so this is not cheat-proof) ----
    val dailyRewards = intArrayOf(200, 300, 400, 500, 700, 900, 1500)

    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    fun dailyClaimed(): Boolean = Save.d.dailyLast == today()

    /** Index (0..6) of the reward that would be claimed next. */
    fun dailyIndex(): Int {
        val d = Save.d
        return if (d.dailyLast == today() - 1L || d.dailyLast == today()) d.dailyStreak % 7 else 0
    }

    fun claimDaily(): String? {
        if (dailyClaimed()) return "Already claimed today"
        val idx = dailyIndex()
        addCoins(dailyRewards[idx])
        Save.d.dailyLast = today()
        Save.d.dailyStreak = idx + 1
        Save.commit()
        return null
    }
}
