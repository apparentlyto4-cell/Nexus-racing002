package com.nexusracing.game.ui

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import com.nexusracing.game.camera.CameraRig
import com.nexusracing.game.controls.TiltSensor
import com.nexusracing.game.data.*
import com.nexusracing.game.audio.Music
import com.nexusracing.game.gameplay.Progression
import com.nexusracing.game.multiplayer.Backend
import com.nexusracing.game.multiplayer.RoomRules
import com.nexusracing.game.persistence.Save
import com.nexusracing.game.ui.Ui.DIM
import com.nexusracing.game.ui.Ui.GOLD
import com.nexusracing.game.ui.Ui.GREEN
import com.nexusracing.game.ui.Ui.MATCH
import com.nexusracing.game.ui.Ui.WRAP
import com.nexusracing.game.ui.Ui.bar
import com.nexusracing.game.ui.Ui.button
import com.nexusracing.game.ui.Ui.card
import com.nexusracing.game.ui.Ui.chips
import com.nexusracing.game.ui.Ui.dp
import com.nexusracing.game.ui.Ui.hbox
import com.nexusracing.game.ui.Ui.header
import com.nexusracing.game.ui.Ui.lp
import com.nexusracing.game.ui.Ui.scroll
import com.nexusracing.game.ui.Ui.text
import com.nexusracing.game.ui.Ui.toast
import com.nexusracing.game.ui.Ui.vbox

class DailyScreen : Screen() {
    override fun create(c: Context): View {
        val root = vbox(c)
        root.addView(header(c, "Daily Rewards") { nav.pop() })
        val claimed = Progression.dailyClaimed()
        val idx = Progression.dailyIndex()
        val shownClaimed = if (claimed) (Save.d.dailyStreak - 1).coerceAtLeast(0) else idx - 1
        val row = hbox(c)
        for (i in 0..6) {
            val cd = card(c)
            val done = i <= shownClaimed && (claimed || i < idx)
            cd.addView(text(c, "DAY ${i + 1}", 13f, DIM, true))
            cd.addView(text(c, "${Progression.dailyRewards[i]}", 18f, if (done) GREEN else GOLD, true))
            if (done) cd.addView(text(c, "✓", 16f, GREEN, true))
            else if (i == idx && !claimed) cd.addView(text(c, "TODAY", 12f, Ui.ACCENT, true))
            row.addView(cd, lp(0, WRAP, 1f, dp(c, 3)))
        }
        root.addView(row, lp(MATCH, WRAP, 0f, dp(c, 4)))
        root.addView(button(c, if (claimed) "Come back tomorrow" else "Claim ${Progression.dailyRewards[idx]} coins", !claimed, !claimed) {
            val err = Progression.claimDaily()
            if (err != null) toast(c, err) else { toast(c, "Reward claimed!"); nav.refresh() }
        }, lp(MATCH, WRAP, 0f, dp(c, 6)))
        root.addView(text(c, "Missing a day restarts the 7-day cycle. Note: daily rewards use the device clock, so they are not protected against clock changes (local-only, no server).", 12f, DIM))
        return root
    }
}

class MissionsScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val root = vbox(c)
        root.addView(header(c, "Missions") { nav.pop() })
        val list = vbox(c)
        for (m in Missions.list) {
            val prog = Progression.missionProgress(m)
            val done = prog >= m.target
            val claimed = d.missionsClaimed.contains(m.id)
            val cd = card(c)
            val row = hbox(c); row.gravity = Gravity.CENTER_VERTICAL
            val info = vbox(c)
            info.addView(text(c, m.title.uppercase(), 16f, if (claimed) GREEN else Ui.TEXT, true))
            info.addView(text(c, m.desc + "  (${prog.coerceAtMost(m.target).toInt()}/${m.target.toInt()})", 12f, DIM))
            info.addView(bar(c, prog / m.target, GREEN), lp(MATCH, dp(c, 6), 0f, dp(c, 3)))
            row.addView(info, lp(0, WRAP, 1f))
            row.addView(button(c, if (claimed) "Claimed" else "Claim ${m.reward}", done && !claimed, done && !claimed) {
                val err = Progression.claimMission(m)
                if (err != null) toast(c, err) else { toast(c, "+${m.reward} coins"); nav.refresh() }
            }, lp(dp(c, 130), WRAP))
            cd.addView(row)
            list.addView(cd, lp(MATCH, WRAP, 0f, dp(c, 3)))
        }
        root.addView(scroll(c, list), lp(MATCH, 0, 1f))
        return root
    }
}

class StatsScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val root = vbox(c)
        root.addView(header(c, "Statistics") { nav.pop() })
        val cd = card(c)
        fun line(k: String, v: String) {
            val r = hbox(c)
            r.addView(text(c, k, 15f, DIM, true), lp(0, WRAP, 1f))
            r.addView(text(c, v, 15f, Ui.TEXT, true))
            cd.addView(r, lp(MATCH, WRAP, 0f, dp(c, 2)))
        }
        line("LEVEL / XP", "${d.level} / ${d.xp}")
        line("RACES (WON)", "${d.races} (${d.wins})")
        line("CRASHES", "${d.crashes}")
        line("TOTAL DISTANCE", "%.1f km".format(d.totalDistance / 1000.0))
        line("TOTAL RIDE TIME", "${(d.totalTime / 60.0).toInt()} min")
        line("COINS COLLECTED", "${d.totalCoins}")
        line("TOP SPEED", "${d.topSpeed.toInt()} km/h")
        line("BEST DISTANCE", "${d.bestDistance.toInt()} m")
        line("BEST SCORE", "${d.bestScore}")
        line("CAREER", "${d.completed.size}/${Career.events.size}")
        line("BIKES OWNED", "${d.unlocked.size}/${Bikes.all.size}")
        root.addView(scroll(c, cd), lp(MATCH, 0, 1f))
        return root
    }
}

class AboutScreen : Screen() {
    override fun create(c: Context): View {
        val ver = try { c.packageManager.getPackageInfo(c.packageName, 0).versionName } catch (e: PackageManager.NameNotFoundException) { "1.0" }
        val root = vbox(c)
        root.addView(header(c, "About") { nav.pop() })
        val cd = card(c)
        cd.addView(text(c, "NEXUS RACING  v$ver", 20f, Ui.TEXT, true))
        cd.addView(text(c, "An original arcade motorcycle racing game for Android (Kotlin + OpenGL ES 3.0).", 14f, DIM))
        cd.addView(text(c, "Most 3D models are generated procedurally in code and all sounds are synthesised in code.", 14f, DIM))
        cd.addView(text(c, "Motorcycle model \"Kawasaki zx10r\" by FREEZLER (https://sketchfab.com/FREEZLER), licensed CC-BY 4.0 (http://creativecommons.org/licenses/by/4.0/). Source: https://sketchfab.com/3d-models/kawasaki-zx10r-cdf6ae10048544d9b069f89fe5be245d. The model was repacked (textures resized, tangents removed, re-oriented) without changing its geometry.", 13f, DIM))
        cd.addView(text(c, "Local daily rewards are not secure against clock changes. Online multiplayer requires a backend (see Multiplayer).", 13f, GOLD))
        root.addView(scroll(c, cd), lp(MATCH, 0, 1f))
        return root
    }
}

class MultiplayerScreen : Screen() {
    override fun create(c: Context): View {
        val root = vbox(c)
        root.addView(header(c, "Multiplayer") { nav.pop() })
        val cd = card(c)
        val ok = Backend.current.configured
        cd.addView(text(c, if (ok) "BACKEND URL SET" else "ONLINE MULTIPLAYER NEEDS BACKEND SETUP", 18f, if (ok) GOLD else Ui.ACCENT, true))
        cd.addView(text(c, Backend.current.description, 13f, DIM))
        cd.addView(text(c,
            "Online racing needs a real-time game server, which is not bundled in the APK. " +
            "This build contains the room model and room rules (rooms of up to 4 players, public/private, 5-character codes " +
            "such as ${RoomRules.newCode()}, ready states, host migration, timeouts), but the network client and race server are NOT implemented yet. " +
            "No fake online players are ever shown.", 13f, Ui.TEXT))
        cd.addView(text(c, "Setup: deploy the server described in backend/README.md, then build with -PNEXUS_BACKEND_URL=<your url>. Until the client protocol is implemented, rooms cannot be created from the app.", 13f, DIM))
        root.addView(scroll(c, cd), lp(MATCH, 0, 1f))
        return root
    }
}

class SettingsScreen : Screen() {
    override fun create(c: Context): View {
        val d = Save.d
        val root = vbox(c)
        root.addView(header(c, "Settings") { nav.pop() })
        val col = vbox(c)
        fun row(label: String, v: View) {
            val r = hbox(c); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(text(c, label, 13f, DIM, true), lp(dp(c, 150), WRAP))
            r.addView(v, lp(0, WRAP, 1f))
            col.addView(r, lp(MATCH, WRAP, 0f, dp(c, 3)))
        }
        val onOff = arrayOf("Off", "On")
        row("GRAPHICS", chips(c, arrayOf("LOW", "MEDIUM", "HIGH"), d.gfx) { d.gfx = it; Save.commit() })
        col.addView(text(c, "LOW: 60% resolution, 1 scenery object, up to 10 vehicles, no clouds/shadows/weather, half-size bike textures. MEDIUM: 80%, 2 objects, 18 vehicles, clouds, kerbs, blob shadows. HIGH: full resolution, 3 objects, 26 vehicles, more weather.", 11f, DIM))
        row("FRAME RATE", chips(c, arrayOf("30 FPS", "60 FPS"), if (d.fps <= 30) 0 else 1) { d.fps = if (it == 0) 30 else 60; Save.commit() })
        row("CONTROLS", chips(c, arrayOf("Buttons", "Wheel", "Joystick", "Tilt"), d.scheme) { d.scheme = it; Save.commit(); nav.refresh() })
        val tilt = TiltSensor(c) {}
        if (d.scheme == 3 && !tilt.available) col.addView(text(c, "No accelerometer found: the game will fall back to button controls.", 12f, Ui.ACCENT))
        row("STEER SENSITIVITY", Ui.slider(c, 50, 150, d.sens) { d.sens = it })
        row("REVERSE TILT", chips(c, onOff, if (d.tiltReverse) 1 else 0) { d.tiltReverse = it == 1; Save.commit() })
        row("TILT CALIBRATION", button(c, "Calibrate (hold neutral)") {
            if (!tilt.available) { toast(c, "No accelerometer") } else {
                tilt.start()
                Handler(Looper.getMainLooper()).postDelayed({
                    d.tiltNeutral = tilt.raw; tilt.stop(); Save.commit(); toast(c, "Tilt calibrated")
                }, 700)
            }
        })
        row("CAMERA", chips(c, CameraRig.NAMES, d.camera) { d.camera = it; Save.commit() })
        row("SOUND VOLUME", Ui.slider(c, 0, 100, d.sfx) { d.sfx = it })
        row("MUSIC VOLUME", Ui.slider(c, 0, 100, d.music) { d.music = it; Music.setVolume() })
        row("VIBRATION", chips(c, onOff, if (d.vibration) 1 else 0) { d.vibration = it == 1; Save.commit() })
        row("DEBUG OVERLAY", chips(c, onOff, if (d.debug) 1 else 0) { d.debug = it == 1; Save.commit() })
        row("LANGUAGE", chips(c, Locales.names, Locales.codes.indexOf(d.lang).coerceAtLeast(0)) {
            d.lang = Locales.codes[it]; Save.commit(); nav.activity.recreate()
        })
        // discreet owner entry (development build)
        val owner = text(c, "Owner", 11f, DIM)
        owner.setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10))
        owner.setOnClickListener { com.nexusracing.game.ui.OwnerPanel.show(nav.activity) { nav.refresh() } }
        col.addView(owner, lp(WRAP, WRAP, 0f, dp(c, 8)))
        root.addView(scroll(c, col), lp(MATCH, 0, 1f))
        return root
    }
}
