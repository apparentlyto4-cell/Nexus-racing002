package com.nexusracing.game.gameplay

import com.nexusracing.game.data.*
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object VType {
    const val CAR = 0
    const val VAN = 1
    const val TRUCK = 2
    const val BUS = 3
    const val SUV = 4
    const val POLICE = 5
    val halfW = floatArrayOf(0.9f, 1.0f, 1.25f, 1.25f, 1.0f, 0.9f)
    val halfL = floatArrayOf(2.1f, 2.5f, 4.6f, 5.6f, 2.4f, 2.1f)
    val colors = intArrayOf(
        0xFFC62828.toInt(), 0xFF1565C0.toInt(), 0xFFEEEEEE.toInt(), 0xFF2E7D32.toInt(),
        0xFFF9A825.toInt(), 0xFF6D4C41.toInt(), 0xFF455A64.toInt(), 0xFF7B1FA2.toInt()
    )
}

/** A pooled traffic vehicle. z is the distance along the road (the player moves toward +z). */
class Vehicle {
    var active = false
    var type = 0
    var x = 0f
    var z = 0f
    var speed = 0f          // m/s along +z (negative = oncoming)
    var lane = 0
    var color = 0
    var timer = 0f
    var nearMissed = false
    var oncoming = false
    var halfW = 0.9f
    var halfL = 2f
}

class Coin {
    var active = false
    var x = 0f
    var z = 0f
}

/** Control inputs written by the UI thread and read by the simulation. */
class InputState {
    @Volatile var steer = 0f
    @Volatile var accel = false
    @Volatile var brake = false
    @Volatile var nitro = false
}

/**
 * The whole race simulation (no rendering, no Android classes). It is advanced with a fixed
 * time step by the renderer, so behaviour does not depend on the frame rate.
 *
 * Coordinates: x = lateral (right is +), z = distance along the road. Lane 0..3 sit at
 * x = (lane - 1.5) * LANE_W. In two-way mode lanes 0-1 carry oncoming traffic.
 */
class RaceSim(val cfg: RaceConfig, val bike: BikeSpec, val gfx: GfxPreset) {
    companion object {
        const val LANE_W = 3.2f
        const val ROAD_HALF = 7.3f
        const val POOL = TrafficTuning.POOL
        const val COIN_POOL = 30
        const val CHECKPOINT_BONUS = 12f
        fun laneX(l: Int): Float = (l - 1.5f) * LANE_W
    }

    enum class State { COUNTDOWN, RACING, CRASHED, ENDED }

    @Volatile var state = State.COUNTDOWN
    @Volatile var countdown = 3f

    val perf: Upgrades.Perf = Upgrades.perfFor(bike)
    /** This bike's complete physics profile (acceleration, braking, steering, lean, grip, gears...). */
    val dyn = BikeDynamics(bike.phys, perf)
    val vmax: Float = dyn.vmax
    val vehicles = Array(POOL) { Vehicle() }
    val coinPool = Array(COIN_POOL) { Coin() }

    var dist = 0f
    var x = laneX(2)
    var vx: Float
        get() = dyn.vx
        set(v) { dyn.vx = v }
    var speed: Float
        get() = dyn.speed
        set(v) { dyn.speed = v }
    var time = 0f
    var coins = 0
    var nearMisses = 0
    var topKmh = 0f
    val steerS: Float get() = dyn.steerS
    val rpm: Float get() = dyn.rpm
    val gear: Int get() = dyn.gear
    val leanDeg: Float get() = dyn.leanDeg
    val pitchDeg: Float get() = dyn.pitchDeg
    val throttleLevel: Float get() = dyn.throttle
    /** Draw / spawn distance, grows with speed so fast bikes see far enough ahead. */
    var viewDistEff = gfx.viewDist
    var wheelDeg = 0f
    var braking = false
    var boosting = false
    var nitro = perf.nitro
    var invuln = 0f
    var crashCount = 0
    var collisionFlash = 0f
    var policeGap = 130f
    var timeLeft = 0f
    var nextCheckpoint = 700f
    var checkpointMsg = 0f
    var activeVehicles = 0
    @Volatile var result: RaceResult? = null
    var onEnd: ((RaceResult) -> Unit)? = null

    private val rnd = Random(if (cfg.seed != 0L) cfg.seed else System.nanoTime())
    private var spawnTimer = 1f
    private var coinNext = 120f
    private var crashTimer = 0f
    private val diffMul = floatArrayOf(0.85f, 1f, 1.2f)[cfg.difficulty.coerceIn(0, 2)]

    init {
        x = laneX(if (cfg.opposing) 3 else 2)
        timeLeft = cfg.timeLimit
        for (i in 0 until TrafficTuning.INITIAL) spawnVehicle(60f + rnd.nextFloat() * gfx.viewDist * 0.8f)
    }

    fun update(dt: Float, inp: InputState) {
        if (collisionFlash > 0f) collisionFlash -= dt
        when (state) {
            State.COUNTDOWN -> {
                dyn.idle(dt, inp.accel)
                countdown -= dt
                if (countdown <= 0f) {
                    countdown = 0f
                    speed = cfg.startSpeedKmh / 3.6f
                    state = State.RACING
                }
            }
            State.RACING -> step(dt, inp)
            State.CRASHED -> {
                speed = max(0f, speed - 35f * dt)
                dyn.relax(dt)
                dist += speed * dt
                moveTraffic(dt)
                crashTimer -= dt
                if (crashTimer <= 0f) finish(false, "Crashed")
            }
            State.ENDED -> {}
        }
        wheelDeg = (wheelDeg + speed / bike.wheelR * dt * 57.2958f) % 360f
    }

    private fun step(dt: Float, inp: InputState) {
        time += dt
        if (invuln > 0f) invuln -= dt
        braking = inp.brake
        boosting = inp.nitro && nitro > 0.05f && speed > 3f && !inp.brake
        nitro = if (boosting) max(0f, nitro - dt) else min(perf.nitro, nitro + 0.25f * dt)

        // --- bike dynamics (longitudinal + lateral + lean + gears), all from the selected bike's profile ---
        viewDistEff = gfx.viewDist * (1f + 0.3f * min(1f, speed / 90f))
        dyn.step(dt, inp.accel, inp.brake, boosting, inp.steer)
        x += vx * dt
        val lim = ROAD_HALF - 0.55f      // the bike can never leave the road
        if (x > lim) { x = lim; if (vx > 0f) vx = 0f }
        if (x < -lim) { x = -lim; if (vx < 0f) vx = 0f }

        dist += speed * dt
        topKmh = max(topKmh, speed * 3.6f)

        moveTraffic(dt)
        spawnStep(dt)
        coinStep()
        collide()
        if (state != State.RACING) return

        if (cfg.mode == Mode.ESCAPE) {
            val pSpeed = min(vmax * 0.88f, 34f + time * 0.35f)
            policeGap = min(150f, policeGap + (speed - pSpeed) * dt)
            if (policeGap <= 3f) { finish(false, "Busted by the police"); return }
        }

        if (checkpointMsg > 0f) checkpointMsg -= dt
        if (cfg.mode == Mode.TIME_ATTACK) {
            timeLeft -= dt
            if (dist >= nextCheckpoint) { nextCheckpoint += 700f; timeLeft += CHECKPOINT_BONUS; checkpointMsg = 2f }
            if (timeLeft <= 0f) { timeLeft = 0f; finish(true, "Time up") }
        } else {
            if (objectiveMet()) { finish(true, "Objective complete"); return }
            if (cfg.timeLimit > 0f) {
                timeLeft = cfg.timeLimit - time
                if (timeLeft <= 0f) finish(false, "Out of time")
            }
        }
    }

    private fun objectiveMet(): Boolean = when (cfg.objective) {
        Obj.DISTANCE -> dist >= cfg.target
        Obj.SPEED -> speed * 3.6f >= cfg.target
        Obj.COINS -> coins >= cfg.target
        Obj.SURVIVE -> time >= cfg.target
        Obj.NONE -> false
    }

    fun objectiveFrac(): Float = when (cfg.objective) {
        Obj.DISTANCE -> dist / cfg.target
        Obj.SPEED -> speed * 3.6f / cfg.target
        Obj.COINS -> coins / cfg.target
        Obj.SURVIVE -> time / cfg.target
        Obj.NONE -> 0f
    }.coerceIn(0f, 1f)

    fun liveScore(): Int = (dist / 10f).toInt() + coins * 10 + nearMisses * 25

    // ---------------------------------------------------------------- traffic
    private fun moveToward(cur: Float, target: Float, maxDelta: Float): Float =
        if (cur < target) min(target, cur + maxDelta) else max(target, cur - maxDelta)

    private fun moveTraffic(dt: Float) {
        var n = 0
        val far = viewDistEff * 1.25f
        for (v in vehicles) {
            if (!v.active) continue
            n++
            // find the nearest leader in this vehicle's lane band
            var lead: Vehicle? = null
            var gapMin = Float.MAX_VALUE
            for (o in vehicles) {
                if (o === v || !o.active || abs(o.x - v.x) > 1.8f) continue
                val gap: Float
                if (!v.oncoming) {
                    if (o.oncoming || o.z <= v.z) continue
                    gap = o.z - v.z - o.halfL - v.halfL
                } else {
                    if (!o.oncoming || o.z >= v.z) continue
                    gap = v.z - o.z - o.halfL - v.halfL
                }
                if (gap < gapMin) { gapMin = gap; lead = o }
            }
            if (lead != null) {
                val follow = TrafficTuning.FOLLOW_GAP + abs(v.speed) * 0.25f
                if (gapMin < follow && abs(lead.speed) < abs(v.speed)) {
                    v.speed = if (gapMin < TrafficTuning.HARD_MATCH_GAP) lead.speed
                    else moveToward(v.speed, lead.speed, TrafficTuning.FOLLOW_BRAKE * dt)
                }
                if (gapMin < TrafficTuning.MIN_SEPARATION) {   // never let two vehicles stay overlapped
                    v.z = if (!v.oncoming) lead.z - lead.halfL - v.halfL - TrafficTuning.MIN_SEPARATION
                    else lead.z + lead.halfL + v.halfL + TrafficTuning.MIN_SEPARATION
                }
            }
            v.z += v.speed * dt
            v.x += (laneX(v.lane) - v.x).coerceIn(-2f * dt, 2f * dt)
            v.timer -= dt
            if (v.timer <= 0f) {
                v.timer = 6f + rnd.nextFloat() * 8f
                if (v.type != VType.POLICE && rnd.nextFloat() < TrafficTuning.LANE_CHANGE_CHANCE) tryLaneChange(v)
            }
            if (v.z < dist - 45f || v.z > dist + far) v.active = false
        }
        activeVehicles = n
    }

    private fun tryLaneChange(v: Vehicle) {
        val nl = v.lane + (if (rnd.nextBoolean()) 1 else -1)
        val lo = if (v.oncoming) 0 else if (cfg.opposing) 2 else 0
        val hi = if (v.oncoming) 1 else 3
        if (nl < lo || nl > hi) return
        for (o in vehicles) {
            if (o !== v && o.active && o.lane == nl && abs(o.z - v.z) < o.halfL + v.halfL + TrafficTuning.LANE_CHANGE_CLEAR) return
        }
        v.lane = nl
    }

    private fun spawnStep(dt: Float) {
        // the timer runs faster the faster the player goes, so traffic density per metre stays constant
        spawnTimer -= dt * (1f + max(0f, speed - 25f) / TrafficTuning.SPEED_SPAWN_BOOST)
        if (spawnTimer > 0f) return
        spawnTimer = (TrafficTuning.SPAWN_INTERVAL / (cfg.density * diffMul).coerceAtLeast(0.2f)) * (0.6f + rnd.nextFloat() * 0.8f)
        var active = 0
        for (v in vehicles) if (v.active) active++
        if (active < min(gfx.trafficCap, POOL)) spawnVehicle(dist + viewDistEff * 0.85f + rnd.nextFloat() * 20f)
    }

    private fun spawnVehicle(z: Float): Boolean {
        var v: Vehicle? = null
        for (o in vehicles) if (!o.active) { v = o; break }
        if (v == null) return false
        val oncoming = cfg.opposing && rnd.nextFloat() < 0.45f
        val lane = if (oncoming) rnd.nextInt(2) else (if (cfg.opposing) 2 + rnd.nextInt(2) else rnd.nextInt(4))
        val police = cfg.mode == Mode.ESCAPE && !oncoming && rnd.nextFloat() < 0.2f
        val r = rnd.nextFloat()
        val type = when {
            police -> VType.POLICE
            r < 0.42f -> VType.CAR
            r < 0.58f -> VType.SUV
            r < 0.74f -> VType.VAN
            r < 0.90f -> VType.TRUCK
            else -> VType.BUS
        }
        val hl = VType.halfL[type]
        val lx = laneX(lane)
        // 1) no overlap / clipping: same lane needs MIN_GAP_SAME_LANE, laterally overlapping lanes need MIN_GAP_OTHER_LANE
        for (o in vehicles) {
            if (!o.active) continue
            val dz = abs(o.z - z)
            if (o.lane == lane && dz < o.halfL + hl + TrafficTuning.MIN_GAP_SAME_LANE) return false
            if (abs(o.x - lx) < o.halfW + VType.halfW[type] + 0.4f && dz < o.halfL + hl + TrafficTuning.MIN_GAP_OTHER_LANE) return false
        }
        // 2) never wall off the whole player-side road: keep at least one same-direction lane free near this spot
        if (!oncoming) {
            val lo = if (cfg.opposing) 2 else 0
            val hi = 3
            var occupied = 0
            for (l in lo..hi) {
                var busy = l == lane
                if (!busy) for (o in vehicles) {
                    if (o.active && !o.oncoming && o.lane == l && abs(o.z - z) < o.halfL + hl + TrafficTuning.OPEN_LANE_WINDOW) { busy = true; break }
                }
                if (busy) occupied++
            }
            if (occupied > hi - lo) return false
        }
        var sp = if (police) 0f else if (oncoming) -(16f + rnd.nextFloat() * 12f) * diffMul else (12f + rnd.nextFloat() * 14f) * diffMul
        if (type == VType.TRUCK || type == VType.BUS) sp *= 0.8f
        v.active = true; v.type = type; v.lane = lane; v.x = lx; v.z = z
        v.speed = sp; v.oncoming = oncoming; v.nearMissed = false
        v.halfW = VType.halfW[type]; v.halfL = hl
        v.color = VType.colors[rnd.nextInt(VType.colors.size)]
        v.timer = 3f + rnd.nextFloat() * 8f
        return true
    }

    // ---------------------------------------------------------------- coins
    private fun coinStep() {
        if (dist + viewDistEff * 0.8f > coinNext) {
            val lane = if (cfg.opposing) 2 + rnd.nextInt(2) else rnd.nextInt(4)
            for (i in 0 until 5) {
                var c: Coin? = null
                for (o in coinPool) if (!o.active) { c = o; break }
                if (c == null) break
                c.active = true; c.x = laneX(lane); c.z = coinNext + i * 7f
            }
            coinNext += 110f + rnd.nextFloat() * 90f
        }
        for (c in coinPool) {
            if (!c.active) continue
            if (c.z < dist - 15f) c.active = false
            else if (abs(c.x - x) < 1.1f && abs(c.z - dist) < 1.6f) { c.active = false; coins++ }
        }
    }

    // ---------------------------------------------------------------- collisions
    /** Real AABB test between the bike and every active vehicle (no random crashes). */
    private fun collide() {
        for (v in vehicles) {
            if (!v.active) continue
            val dx = abs(v.x - x)
            val dz = abs(v.z - dist)
            val hw = v.halfW + 0.32f
            val hl = v.halfL + 0.95f
            if (dx < hw - 0.08f && dz < hl - 0.1f) {
                if (invuln <= 0f) crash()
                continue
            }
            if (!v.nearMissed && dz < 1.5f && dx < hw + 0.9f) { v.nearMissed = true; nearMisses++ }
        }
    }

    private fun crash() {
        collisionFlash = 0.6f
        crashCount++
        if (cfg.mode == Mode.FREE_RIDE) {
            speed *= 0.3f; vx = 0f; invuln = 2f      // free ride: stumble, then keep riding
        } else {
            state = State.CRASHED; crashTimer = 1.4f
        }
    }

    private fun finish(ok: Boolean, reason: String) {
        if (state == State.ENDED) return
        state = State.ENDED
        val r = RaceResult(ok, reason, dist, time, coins, liveScore(), topKmh, nearMisses)
        result = r
        onEnd?.invoke(r)
    }

    /** Free ride / pause menu: the player ends the session voluntarily. */
    fun endSession() { if (state == State.RACING) finish(true, "Session ended") }
}
