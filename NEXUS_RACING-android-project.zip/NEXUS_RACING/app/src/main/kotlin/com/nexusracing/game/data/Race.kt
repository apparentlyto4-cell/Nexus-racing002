package com.nexusracing.game.data

import org.json.JSONObject

enum class Mode(val label: String) {
    ONE_WAY("One Way"), TWO_WAY("Two Way"), TIME_ATTACK("Time Attack"),
    FREE_RIDE("Free Ride"), ESCAPE("Escape"), PRIVATE("Private Race")
}

enum class Obj { NONE, DISTANCE, SPEED, COINS, SURVIVE }

/** A complete description of one race. All modes, career events and private races use this one class. */
class RaceConfig(
    val mode: Mode,
    val env: Int = 0,
    val night: Boolean = false,
    val weather: Int = 0,            // 0 clear, 1 rain, 2 snow, 3 fog
    val density: Float = 1f,         // traffic density multiplier
    val difficulty: Int = 1,         // 0 easy, 1 normal, 2 hard
    val startSpeedKmh: Float = 0f,
    val objective: Obj = Obj.NONE,
    val target: Float = 0f,
    val timeLimit: Float = 0f,       // seconds (Time Attack start time, or fail limit)
    val opposing: Boolean = false,   // oncoming traffic in the two left lanes
    val careerId: String = "",
    val title: String = "",
    val seed: Long = 0L              // 0 = random; set for reproducible traffic
) {
    fun toJson(): String = JSONObject()
        .put("mode", mode.name).put("env", env).put("night", night).put("weather", weather)
        .put("density", density.toDouble()).put("difficulty", difficulty)
        .put("start", startSpeedKmh.toDouble()).put("obj", objective.name)
        .put("target", target.toDouble()).put("limit", timeLimit.toDouble())
        .put("opp", opposing).put("career", careerId).put("title", title).put("seed", seed)
        .toString()

    fun objectiveLabel(): String {
        val base = when (objective) {
            Obj.NONE -> "Ride freely"
            Obj.DISTANCE -> "Reach ${target.toInt()} m"
            Obj.SPEED -> "Reach ${target.toInt()} km/h"
            Obj.COINS -> "Collect ${target.toInt()} coins"
            Obj.SURVIVE -> "Survive ${target.toInt()} s"
        }
        return if (timeLimit > 0f && mode != Mode.TIME_ATTACK) "$base within ${timeLimit.toInt()} s" else base
    }

    companion object {
        fun fromJson(s: String): RaceConfig {
            val o = JSONObject(s)
            return RaceConfig(
                Mode.valueOf(o.getString("mode")), o.optInt("env", 0), o.optBoolean("night", false),
                o.optInt("weather", 0), o.optDouble("density", 1.0).toFloat(), o.optInt("difficulty", 1),
                o.optDouble("start", 0.0).toFloat(), Obj.valueOf(o.optString("obj", "NONE")),
                o.optDouble("target", 0.0).toFloat(), o.optDouble("limit", 0.0).toFloat(),
                o.optBoolean("opp", false), o.optString("career", ""), o.optString("title", ""),
                o.optLong("seed", 0L)
            )
        }
    }
}

class CareerEvent(
    val id: String, val title: String, val desc: String,
    val rewardCoins: Int, val rewardXp: Int, val config: RaceConfig
)

/** Ten career events, all built from the same RaceConfig. Add more by appending to the list. */
object Career {
    val events: List<CareerEvent> = listOf(
        CareerEvent("c01", "Warm-Up", "Ride 1500 m through downtown traffic.", 300, 80,
            RaceConfig(Mode.ONE_WAY, 0, false, 0, 0.8f, 0, 0f, Obj.DISTANCE, 1500f, careerId = "c01", title = "Warm-Up")),
        CareerEvent("c02", "Highway Dash", "Hit 150 km/h on the desert highway.", 400, 100,
            RaceConfig(Mode.ONE_WAY, 1, false, 0, 0.8f, 1, 0f, Obj.SPEED, 150f, careerId = "c02", title = "Highway Dash")),
        CareerEvent("c03", "Coin Run", "Collect 25 coins in the countryside.", 500, 120,
            RaceConfig(Mode.ONE_WAY, 2, false, 0, 1f, 1, 40f, Obj.COINS, 25f, careerId = "c03", title = "Coin Run")),
        CareerEvent("c04", "Rush Hour", "Dodge oncoming traffic for 2500 m at night.", 700, 160,
            RaceConfig(Mode.TWO_WAY, 0, true, 0, 1.3f, 1, 40f, Obj.DISTANCE, 2500f, opposing = true, careerId = "c04", title = "Rush Hour")),
        CareerEvent("c05", "Time Trial", "Cover 3200 m in 70 seconds.", 900, 200,
            RaceConfig(Mode.ONE_WAY, 1, false, 0, 1f, 1, 60f, Obj.DISTANCE, 3200f, timeLimit = 70f, careerId = "c05", title = "Time Trial")),
        CareerEvent("c06", "Snow Run", "Ride 3000 m through falling snow.", 1100, 240,
            RaceConfig(Mode.ONE_WAY, 3, false, 2, 1f, 1, 0f, Obj.DISTANCE, 3000f, careerId = "c06", title = "Snow Run")),
        CareerEvent("c07", "Escape", "Survive 60 s of police pursuit.", 1400, 300,
            RaceConfig(Mode.ESCAPE, 0, true, 0, 1f, 1, 90f, Obj.SURVIVE, 60f, careerId = "c07", title = "Escape")),
        CareerEvent("c08", "Oncoming Danger", "3000 m of heavy two-way traffic.", 1800, 360,
            RaceConfig(Mode.TWO_WAY, 2, false, 3, 1.5f, 2, 60f, Obj.DISTANCE, 3000f, opposing = true, careerId = "c08", title = "Oncoming Danger")),
        CareerEvent("c09", "Fast Lane", "Reach 220 km/h on the winter road.", 2200, 420,
            RaceConfig(Mode.ONE_WAY, 3, false, 0, 1f, 2, 80f, Obj.SPEED, 220f, careerId = "c09", title = "Fast Lane")),
        CareerEvent("c10", "Final Escape", "Survive 90 s of pursuit in the snow at night.", 3500, 700,
            RaceConfig(Mode.ESCAPE, 3, true, 2, 1.2f, 2, 100f, Obj.SURVIVE, 90f, careerId = "c10", title = "Final Escape"))
    )

    fun byId(id: String): CareerEvent? = events.firstOrNull { it.id == id }
    fun next(id: String): CareerEvent? {
        val i = events.indexOfFirst { it.id == id }
        return if (i >= 0 && i + 1 < events.size) events[i + 1] else null
    }
}

/** kind: distance (m, lifetime), coins, wins, speed (km/h best), career (events done), bikes (owned). */
class Mission(val id: String, val title: String, val desc: String, val kind: String, val target: Float, val reward: Int)

object Missions {
    val list = listOf(
        Mission("m1", "First Kilometres", "Ride 5 km in total.", "distance", 5000f, 300),
        Mission("m2", "Long Hauler", "Ride 50 km in total.", "distance", 50000f, 1500),
        Mission("m3", "Coin Collector", "Collect 100 coins in total.", "coins", 100f, 500),
        Mission("m4", "Winner", "Complete 5 races successfully.", "wins", 5f, 800),
        Mission("m5", "Speed Demon", "Reach 200 km/h.", "speed", 200f, 1200),
        Mission("m6", "Career Starter", "Complete 3 career events.", "career", 3f, 1000),
        Mission("m7", "Collector", "Own 3 motorcycles.", "bikes", 3f, 2000)
    )
}
