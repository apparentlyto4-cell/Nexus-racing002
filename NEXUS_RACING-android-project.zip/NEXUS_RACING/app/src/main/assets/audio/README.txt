Optional audio. The game already synthesises the engine sound and UI/race beeps in code.
To add background music, drop an OGG file named music.ogg in this folder (app/src/main/assets/audio/).
If the file is missing the game simply plays no music (no crash).
