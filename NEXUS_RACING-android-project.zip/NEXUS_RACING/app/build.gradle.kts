plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexusracing.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexusracing.game"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        val backendUrl = (project.findProperty("NEXUS_BACKEND_URL") as String?) ?: ""
        buildConfigField("String", "BACKEND_URL", "\"$backendUrl\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
    // keep .glb models uncompressed in the APK so they can be read through a file descriptor (fast, no extra copy)
    androidResources {
        noCompress += "glb"
    }
}
// No third-party dependencies: the game uses only the Android framework APIs (the GLB loader is in graphics/Glb.kt).
