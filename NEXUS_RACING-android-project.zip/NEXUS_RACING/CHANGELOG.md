# Changelog
## 1.1.0
- New premium bike "Kawasaki Ninja H2R" (Legendary / SSS, 2,000,000 coins, price configurable in `bikes.json`) rendered from a real GLB model (`assets/models/h2r.glb`) in races, garage and menu previews. Own loader (`graphics/Glb.kt`), progressive GPU upload (`graphics/GlbGpu.kt`); falls back to the procedural bike if the model cannot load.
- Per-bike physics profiles (`BikePhys`, optional `"phys"` object in `bikes.json`; legacy bikes keep their old defaults): throttle/brake response and curve, steering sensitivity and high-speed reduction, lean, traction/launch control, stability, suspension pitch, gearbox/RPM, camera and audio tuning. All control input flows through `InputState` into `BikeDynamics`.
- Redesigned compact controls (icons, glow, safe-area aware, slide between steer buttons, release on focus loss), gear + RPM HUD.
- Procedural sky (gradient, sun/moon, stars, clouds), distant backdrop, wheel tracks, kerbs, guardrail posts, speed-aware view distance.
- Denser, fairer traffic (`TrafficTuning`): smaller gaps, speed-scaled spawning, guaranteed open lane, no overlapping spawns, smooth following.
- Owner Panel (development PIN, stored hashed) and a guarded `Shop.purchase`.
- Engine audio follows RPM/gear per bike, plus wind and supercharger whine.
- Workflow reads AGP/compileSdk from the project and picks Gradle/SDK accordingly.
- Model credit: "Kawasaki zx10r" by FREEZLER, CC-BY 4.0.
## 1.0.0
- First complete version: 3D racing loop, traffic, modes, garage, upgrades, customization, career, missions, daily rewards, settings, local save, 4 environments, 3 graphics presets, English/Bengali menus.
- Multiplayer: room model and rules only (no network client yet).
