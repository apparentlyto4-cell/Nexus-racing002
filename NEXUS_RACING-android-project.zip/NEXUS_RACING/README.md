# NEXUS RACING

Original arcade motorcycle racing game for Android: Kotlin, OpenGL ES 3.0, no third-party libraries.
Package `com.nexusracing.game` · minSdk 26 (Android 8.0) · target/compile SDK 34 · Java 17 · Gradle 8.7 (chosen automatically by the workflow from the AGP version) · AGP 8.3.2 · Kotlin 1.9.23.

## Status (honest)

**Implemented**
- Real 3D riding loop (fixed 60 Hz simulation, delta-time rendering): accelerate, brake, steer, nitro, lane/road limits, real AABB collisions with traffic, near-miss bonus, coins, timer, crash handling, pause/resume, restart, results.
- Traffic: car, SUV, van, truck, bus (distinct procedural models), lane keeping, lane changes, spawning/despawning from a bounded pool, adjustable density, optional fixed seed.
- 4 camera modes (chase, close, rider view, elevated) with smooth transitions; saved in preferences.
- Controls: buttons, steering wheel, joystick, tilt (accelerometer, reverse + calibration + sensitivity, automatic fallback to buttons). Each finger is bound to one control.
- Modes: One Way, Two Way (oncoming lanes), Time Attack (checkpoints add time), Free Ride, Escape (chasing police car + roadblocks), Private Race (environment, time, weather, traffic, direction, duration, difficulty, start speed — all applied).
- 4 environments (city, desert highway, village, winter), day/night, rain/snow/fog.
- 3 graphics presets (LOW/MEDIUM/HIGH) that change resolution scale, view distance, scenery, traffic cap, blob shadows, weather particles, speed effects. Frame cap 30/60.
- Garage (6 bikes incl. the GLB-based Kawasaki Ninja H2R, buy/select via `Shop.purchase`), 5 upgrade categories x 5 levels (change real performance), customization (paint, rims, decals, accessories — rendered live), 10 career events, XP/levels, 7 missions, 7-day daily rewards.
- Saving with version field, backup slot and corruption fallback. Settings, debug overlay (FPS, speed, traffic, collision boxes), synthesised engine/UI sounds, optional music file, English + Bengali (UI architecture via `res/values-XX`).

**Not complete**
- **Online multiplayer is NOT implemented.** Only the room data model and room rules exist (`multiplayer/Rooms.kt`). The screen explains this. See `backend/README.md`.
- Only menu entries, settings labels and a few titles are translated; most other UI text is English.
- No real-time shadows (blob shadows only). Most bikes/vehicles are simple procedural shapes; the H2R is a real GLB model (see `docs/H2R_MODEL.md`): its wheels do not spin and paint customisation does not apply to it.
- Owner Panel (Settings > "Owner") uses a development PIN stored as a salted hash. It is NOT secure authorization; replace `owner/OwnerAccess.kt` with a server check before release.
- Music needs your own `assets/audio/music.ogg`.
- Daily rewards use the device clock (not cheat-proof).
- **This project was written without access to a compiler/Android SDK in the authoring environment, so the first GitHub Actions build is the first real compile.** If it fails, download the `build-log` artifact and fix the reported line.

## Build with GitHub Actions (no Android Studio)

1. Create a GitHub repository.
2. Upload `NEXUS_RACING-android-project.zip` **as-is** (do not unzip) to the repo root.
3. Upload `android-apk.yml` to `.github/workflows/android-apk.yml` (Add file → Create new file, type the path, paste the contents).
4. Open the **Actions** tab → *Build NEXUS RACING Android APK* → **Run workflow**.
5. When it finishes, open the run and download the artifact **NEXUS_RACING-debug-apk** (zip containing `app-debug.apk`). If it fails, download **build-log**.
6. Unzip, copy the APK to the phone, open it and allow "install unknown apps".

Keep only one project ZIP in the repo root; the workflow uses the newest `NEXUS_RACING*.zip`.

## Build locally
Android Studio (Hedgehog+) → *Open* the extracted folder → let it sync (it needs Gradle 8.7; or run `gradle wrapper --gradle-version 8.7` once). Or CLI: `gradle :app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## Project structure
`app/src/main/kotlin/com/nexusracing/game/`: `data` (bikes, races, career, presets) · `persistence` · `gameplay` (RaceSim, Upgrades, Progression) · `graphics` (GlKit, Models, SceneDrawer, renderers) · `camera` · `controls` (GameView HUD+touch, TiltSensor) · `audio` · `ui` (Ui toolkit, Navigator, screens) · `multiplayer` · `MainActivity` / `GameActivity`. Assets: `app/src/main/assets/config/bikes.json`.

## Customize
- **Bike stats / add a bike:** edit `assets/config/bikes.json` (add an object with the same fields). `fairing` 0/1/2, `tank`, `seatY`, `wheelBase`, `wheelR` change the model shape. Saves adapt automatically.
- **Graphics presets:** `data/Config.kt` → `Gfx.presets`.
- **Add an environment:** add an `EnvSpec` in `Envs.all` (`data/Config.kt`) and a scenery branch for its `kind` in `graphics/SceneDrawer.kt` `drawScenery`.
- **Career events / missions:** `data/Race.kt` (`Career.events`, `Missions.list`).
- **Colors / UI text:** colors in `ui/Ui.kt`; menu strings in `res/values/strings.xml` (+ `values-bn`). Add a language: new `res/values-XX/strings.xml` and an entry in `Locales`.
- **Upgrades formulas:** `gameplay/Upgrades.kt`.

## Multiplayer configuration
Build with `-PNEXUS_BACKEND_URL=https://your.server` (or set it in `gradle.properties`). No secrets belong in the app. Read `backend/README.md`.

## Troubleshooting
- *No ZIP found / several ZIPs*: keep exactly one `NEXUS_RACING*.zip` in the repo root.
- *Build fails*: open the run summary or the `build-log` artifact; look for lines starting with `e:`.
- *Black screen on a device*: the game needs OpenGL ES 3.0; try graphics LOW.
- *Tilt does nothing*: calibrate in Settings, or use "Reverse tilt"; devices without an accelerometer fall back to buttons.

## Licenses
All code, models and sounds are original and generated in code. No third-party assets or libraries.
