// AGP 8.3.2 needs Gradle 8.4+ (we use 8.7). Kotlin 1.9.23 is compatible with AGP 8.3.
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
}
